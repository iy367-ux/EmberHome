# EmberHome v1.1 – Android TV launcher

Four home styles you can switch in **Settings**: Ember Dock, Cinema Rail (VIDAA-style expanding sidebar), Glass (tvOS-style) and Google TV.
Long-press OK on an app to rearrange, hide/show apps, wallpaper gallery, aerial screensaver. Android 4.4.4 (API 19) compatible, no libraries, no Android Studio.

## Build it on GitHub (no PC tools needed)
1. Create a new GitHub repository and upload everything in this folder (keep the `.github` folder and the `app` folder).
2. Open the **Actions** tab -> **Build EmberHome APK** -> wait for the green tick (or click **Run workflow**).
3. Open the finished run, download the **EmberHome-debug-apk** artifact, unzip it to get `app-debug.apk`.
4. Install it on the TV (USB drive, or `adb install -r app-debug.apk`). Press Home and choose EmberHome as the default launcher.

If the build fails, open the red run, copy the first error lines and send them to me.

## Wallpapers, profile and your own images
- Sunsets, Nature and Cities are illustrated scenes drawn in code (no image files). To use real photos instead, put JPEGs
  (1280x720 or 1920x1080, under ~300 KB) in `app/src/main/res/drawable-nodpi/` named `wp_sunsets_1.jpg` ... `wp_sunsets_4.jpg`,
  `wp_nature_1.jpg` ... `wp_nature_4.jpg`, `wp_cities_1.jpg` ... `wp_cities_4.jpg`. They replace the drawn scene of the same number.
  Use photos you have the right to use (Unsplash, Pexels and Pixabay allow free use).
- **My Wallpapers / profile picture:** copy any pictures to `Pictures/EmberHome` on the TV. They appear in the wallpaper gallery
  under My Wallpapers, and Settings -> Profile lets you cycle through them as your picture.
- Settings -> Profile sets your name (shown on Google TV and as a greeting on Ember Dock).
- Settings -> Glass dock layout: "Apps below dock" (8 apps in the dock, the rest under it) or "Scrolling dock".
