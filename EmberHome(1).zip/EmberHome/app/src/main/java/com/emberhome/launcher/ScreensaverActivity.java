package com.emberhome.launcher;

import android.animation.ObjectAnimator;
import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextClock;
import android.widget.TextView;

/** Slow zoom + crossfade between your wallpaper scenes/photos. Any key wakes it. */
public class ScreensaverActivity extends Activity {
    private static final int[][] SCENES = {{1, 0}, {3, 1}, {2, 0}, {1, 2}, {3, 3}};
    private static final String[] CAP = {"Coastline at dusk", "City after dark", "Mountains at dawn", "Harbour at sunset", "Skyline in the haze"};
    private static final long HOLD = 14000, FADE = 2500;
    private final Handler h = new Handler();
    private FrameLayout layers;
    private final ImageView[] v = new ImageView[2];
    private TextView caption;
    private int scene = -1, front = 0;
    private final Runnable next = new Runnable() {
        @Override public void run() { show(); h.postDelayed(this, HOLD); }
    };

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN | WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);
        layers = new FrameLayout(this);
        root.addView(layers, new FrameLayout.LayoutParams(-1, -1));
        for (int i = 0; i < 2; i++) { v[i] = new ImageView(this); layers.addView(v[i], new FrameLayout.LayoutParams(-1, -1)); }
        float d = getResources().getDisplayMetrics().density;
        TextClock clock = new TextClock(this);
        clock.setFormat12Hour("h:mm"); clock.setFormat24Hour("HH:mm");
        clock.setTextColor(Color.WHITE); clock.setTextSize(72);
        FrameLayout.LayoutParams cp = new FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM | Gravity.LEFT);
        cp.setMargins((int) (56 * d), 0, 0, (int) (48 * d));
        root.addView(clock, cp);
        caption = new TextView(this);
        caption.setTextColor(Color.WHITE); caption.setTextSize(18);
        FrameLayout.LayoutParams tp = new FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM | Gravity.RIGHT);
        tp.setMargins(0, 0, (int) (56 * d), (int) (56 * d));
        root.addView(caption, tp);
        setContentView(root);
    }

    @Override protected void onResume() {
        super.onResume();
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
        h.post(next);
    }

    @Override protected void onPause() { super.onPause(); h.removeCallbacks(next); }

    private void show() {
        scene = (scene + 1) % SCENES.length;
        ImageView in = v[1 - front];
        in.setBackgroundDrawable(Wallpapers.get(this, SCENES[scene][0], SCENES[scene][1]));
        in.setScaleX(1f); in.setScaleY(1f); in.setAlpha(0f);
        in.bringToFront();
        ObjectAnimator.ofFloat(in, "alpha", 0f, 1f).setDuration(FADE).start();
        in.animate().scaleX(1.08f).scaleY(1.08f).setDuration(HOLD + FADE).start();
        caption.setText(CAP[scene]);
        front = 1 - front;
    }

    @Override public boolean dispatchKeyEvent(KeyEvent e) { if (e.getAction() == KeyEvent.ACTION_UP) finish(); return true; }
    @Override public boolean onTouchEvent(MotionEvent e) { finish(); return true; }
}
