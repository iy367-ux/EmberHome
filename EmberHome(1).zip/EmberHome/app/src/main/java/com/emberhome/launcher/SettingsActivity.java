package com.emberhome.launcher;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

/** Simple Google TV / tvOS style settings: one plain list, white highlight, sub-lists for style and screensaver. */
public class SettingsActivity extends Activity {
    private static final int[] MINUTES = {1, 5, 10, 15};
    private LinearLayout list;
    private TextView title;
    private int menu, focusIdx;      // menu: 0 main, 1 home style, 2 screensaver
    private float d;

    private int dp(int v) { return (int) (v * d + 0.5f); }

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        d = getResources().getDisplayMetrics().density;
        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(0xFF0D0F14);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setPadding(dp(40), dp(48), dp(40), dp(32));
        sv.addView(root, new ViewGroup.LayoutParams(-1, -2));
        title = new TextView(this);
        title.setTextColor(Color.WHITE); title.setTextSize(32); title.setTypeface(Typeface.DEFAULT_BOLD);
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(dp(640), -2);
        tp.bottomMargin = dp(20);
        root.addView(title, tp);
        list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        root.addView(list, new LinearLayout.LayoutParams(dp(640), -2));
        setContentView(sv);
        show(0, 0);
    }

    @Override protected void onResume() { super.onResume(); show(menu, focusIdx); }

    @Override public void onBackPressed() {
        if (menu != 0) show(0, menu == 1 ? 1 : 5); else super.onBackPressed();
    }

    private void add(String label, String value, final Runnable act) {
        final int index = list.getChildCount();
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(22), dp(14), dp(22), dp(14));
        row.setFocusable(true);
        row.setClickable(true);
        final TextView l = new TextView(this), v = new TextView(this);
        l.setText(label); l.setTextSize(20); l.setTypeface(Typeface.DEFAULT_BOLD); l.setTextColor(Color.WHITE);
        v.setText(value); v.setTextSize(18); v.setTextColor(0xB3FFFFFF);
        row.addView(l, new LinearLayout.LayoutParams(0, -2, 1f));
        row.addView(v);
        paint(row, l, v, false);
        row.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override public void onFocusChange(View view, boolean f) { if (f) focusIdx = index; paint((LinearLayout) view, l, v, f); }
        });
        row.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View view) { act.run(); } });
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = dp(6);
        list.addView(row, lp);
    }

    private void paint(LinearLayout row, TextView l, TextView v, boolean f) {
        GradientDrawable g = new GradientDrawable();
        g.setCornerRadius(dp(14));
        g.setColor(f ? Color.WHITE : 0x00000000);
        row.setBackgroundDrawable(g);
        l.setTextColor(f ? 0xFF111111 : Color.WHITE);
        v.setTextColor(f ? 0xFF555555 : 0xB3FFFFFF);
    }

    private void show(int m, int idx) {
        menu = m; focusIdx = idx;
        list.removeAllViews();
        final SettingsActivity a = this;
        if (m == 0) {
            title.setText("Settings");
            String pn = Prefs.profileName(a);
            add("Profile", (pn.length() == 0 ? "Set up" : pn) + "  ›", new Runnable() { public void run() { startActivity(new Intent(a, ProfileActivity.class)); } });
            add("Home style", Prefs.style(a).label + "  ›", new Runnable() { public void run() { show(1, 1); } });
            add("Glass dock layout", Prefs.glassLayout(a) == 1 ? "Apps below dock" : "Scrolling dock", new Runnable() { public void run() {
                Prefs.setGlassLayout(a, Prefs.glassLayout(a) == 1 ? 0 : 1); show(0, 2); } });
            String w = Prefs.wall(a);
            add("Wallpaper", (w.length() == 0 ? "Style default" : "Custom") + "  ›", new Runnable() { public void run() { startActivity(new Intent(a, WallpaperActivity.class)); } });
            int hidden = 0;
            for (AppEntry e : AppRepo.all(a)) if (Prefs.isHidden(a, e.pkg)) hidden++;
            add("Manage apps", hidden + " hidden  ›", new Runnable() { public void run() { startActivity(new Intent(a, AppsActivity.class)); } });
            add("Screensaver", (Prefs.saverOn(a) ? "On" : "Off") + "  ›", new Runnable() { public void run() { show(2, 0); } });
            add("Reset layout", "", new Runnable() { public void run() {
                Prefs.resetLayout(a);
                Toast.makeText(a, "Layout, hidden apps and wallpaper reset", Toast.LENGTH_SHORT).show();
                show(0, 6); } });
        } else if (m == 1) {
            title.setText("Home style");
            final HomeStyle[] st = HomeStyle.values();
            for (int i = 0; i < st.length; i++) {
                final HomeStyle s = st[i];
                final int at = i;
                add(s.label, Prefs.style(a) == s ? "✓" : "", new Runnable() { public void run() {
                    Prefs.setStyle(a, s);
                    Toast.makeText(a, s.label + " applied", Toast.LENGTH_SHORT).show();
                    show(1, at); } });
            }
        } else {
            title.setText("Screensaver");
            add("Aerial screensaver", Prefs.saverOn(a) ? "On" : "Off", new Runnable() { public void run() { Prefs.setSaverOn(a, !Prefs.saverOn(a)); show(2, 0); } });
            add("Start after", Prefs.idleMin(a) + " min", new Runnable() { public void run() {
                int cur = Prefs.idleMin(a), nx = MINUTES[0];
                for (int i = 0; i < MINUTES.length; i++) if (MINUTES[i] == cur) nx = MINUTES[(i + 1) % MINUTES.length];
                Prefs.setIdleMin(a, nx); show(2, 1); } });
            add("Preview now", "", new Runnable() { public void run() { startActivity(new Intent(a, ScreensaverActivity.class)); } });
        }
        View f = list.getChildAt(Math.min(idx, list.getChildCount() - 1));
        if (f != null) f.requestFocus();
    }
}
