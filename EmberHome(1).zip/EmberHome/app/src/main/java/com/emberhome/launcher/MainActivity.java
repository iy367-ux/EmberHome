package com.emberhome.launcher;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.view.WindowManager;
import android.widget.Toast;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity implements HomeView.Host {
    private HomeView hv;
    private IdleTimer idle;
    private final Handler handler = new Handler();
    private boolean receiverOn;

    private final Runnable tick = new Runnable() {
        @Override public void run() { updateClock(); handler.postDelayed(this, 20000); }
    };
    private final BroadcastReceiver pkgs = new BroadcastReceiver() {
        @Override public void onReceive(Context c, Intent i) { AppRepo.invalidate(); reload(); }
    };

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
        hv = new HomeView(this);
        hv.setHost(this);
        setContentView(hv);
        idle = new IdleTimer(this);
        IntentFilter f = new IntentFilter();
        f.addAction(Intent.ACTION_PACKAGE_ADDED);
        f.addAction(Intent.ACTION_PACKAGE_REMOVED);
        f.addAction(Intent.ACTION_PACKAGE_CHANGED);
        f.addDataScheme("package");
        registerReceiver(pkgs, f);
        receiverOn = true;
    }

    @Override protected void onResume() {
        super.onResume();
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN
                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | (android.os.Build.VERSION.SDK_INT >= 19 ? View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY : 0));
        reload();
        handler.post(tick);
        idle.reset();
        hv.requestFocus();
    }

    @Override protected void onPause() {
        super.onPause();
        idle.stop();
        handler.removeCallbacks(tick);
    }

    @Override protected void onDestroy() {
        super.onDestroy();
        if (receiverOn) unregisterReceiver(pkgs);
    }

    @Override protected void onNewIntent(Intent i) {          // Home button pressed again
        super.onNewIntent(i);
        reload();
    }

    @Override public void onUserInteraction() { idle.reset(); }

    private void reload() {
        Drawable w = Wallpapers.byKey(this, Prefs.wall(this));
        hv.setData(Prefs.style(this), new ArrayList<AppEntry>(AppRepo.visible(this)), w);
        hv.setGlassLayout(Prefs.glassLayout(this));
        String ap = Prefs.avatarPath(this);
        hv.setProfile(Prefs.profileName(this), ap.length() > 0 ? Wallpapers.avatar(ap) : null, ProfileActivity.COLORS[Prefs.avatarColor(this) % ProfileActivity.COLORS.length]);
        updateClock();
    }

    private void updateClock() {
        Date d = new Date();
        hv.setTime(new SimpleDateFormat("h:mm", Locale.getDefault()).format(d),
                new SimpleDateFormat("EEEE, d MMMM", Locale.getDefault()).format(d));
    }

    @Override public void launch(AppEntry a) {
        try { startActivity(a.intent); }
        catch (Exception e) { Toast.makeText(this, "Can't open " + a.label, Toast.LENGTH_SHORT).show(); }
    }

    @Override public void action(int k) {
        if (k == 0) startActivity(new Intent(this, WallpaperActivity.class));
        else if (k == 1) startActivity(new Intent(this, AppsActivity.class));
        else if (k == 2) startActivity(new Intent(this, SettingsActivity.class));
        else if (k == 4) startActivity(new Intent(this, SearchActivity.class));
        else startActivity(new Intent(this, ScreensaverActivity.class));
    }

    @Override public void orderChanged(List<AppEntry> list) {
        List<String> o = new ArrayList<String>();
        for (AppEntry a : list) o.add(a.pkg);
        for (AppEntry a : AppRepo.all(this)) if (!o.contains(a.pkg)) o.add(a.pkg);
        Prefs.setOrder(this, o);
    }
}
