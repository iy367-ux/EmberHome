package com.emberhome.launcher;

import android.content.Context;
import android.content.SharedPreferences;
import java.util.ArrayList;
import java.util.List;

public final class Prefs {
    private Prefs() {}
    private static SharedPreferences sp(Context c) { return c.getSharedPreferences("emberhome", Context.MODE_PRIVATE); }

    public static HomeStyle style(Context c) { return HomeStyle.fromKey(sp(c).getString("style", "ember")); }
    public static void setStyle(Context c, HomeStyle s) { sp(c).edit().putString("style", s.key).apply(); }

    private static List<String> csv(Context c, String key) {
        String s = sp(c).getString(key, "");
        List<String> l = new ArrayList<String>();
        if (s.length() > 0) for (String x : s.split(",")) l.add(x);
        return l;
    }
    private static void setCsv(Context c, String key, List<String> l) {
        StringBuilder b = new StringBuilder();
        for (String x : l) { if (b.length() > 0) b.append(','); b.append(x); }
        sp(c).edit().putString(key, b.toString()).apply();
    }
    public static List<String> order(Context c) { return csv(c, "order"); }
    public static void setOrder(Context c, List<String> l) { setCsv(c, "order", l); }
    public static boolean isHidden(Context c, String pkg) { return csv(c, "hidden").contains(pkg); }
    public static void setHidden(Context c, String pkg, boolean hide) {
        List<String> l = csv(c, "hidden");
        l.remove(pkg);
        if (hide) l.add(pkg);
        setCsv(c, "hidden", l);
    }
    /** "c:cat:idx" for built-in wallpapers, "f:/path" for your own pictures, "" for style default. */
    public static String wall(Context c) { return sp(c).getString("wall", ""); }
    public static void setWall(Context c, String k) { sp(c).edit().putString("wall", k).apply(); }
    public static boolean saverOn(Context c) { return sp(c).getBoolean("saver", true); }
    public static void setSaverOn(Context c, boolean b) { sp(c).edit().putBoolean("saver", b).apply(); }
    public static int idleMin(Context c) { return sp(c).getInt("idle", 5); }
    public static void setIdleMin(Context c, int m) { sp(c).edit().putInt("idle", m).apply(); }
    public static String profileName(Context c) { return sp(c).getString("pname", ""); }
    public static void setProfileName(Context c, String n) { sp(c).edit().putString("pname", n).apply(); }
    public static int avatarColor(Context c) { return sp(c).getInt("pcolor", 0); }
    public static void setAvatarColor(Context c, int i) { sp(c).edit().putInt("pcolor", i).apply(); }
    public static String avatarPath(Context c) { return sp(c).getString("ppath", ""); }
    public static void setAvatarPath(Context c, String p) { sp(c).edit().putString("ppath", p).apply(); }
    /** 0 = one scrolling dock, 1 = 8-app dock with the rest of the apps under it. */
    public static int glassLayout(Context c) { return sp(c).getInt("glass", 1); }
    public static void setGlassLayout(Context c, int v) { sp(c).edit().putInt("glass", v).apply(); }
    public static void resetLayout(Context c) { sp(c).edit().remove("order").remove("hidden").remove("wall").apply(); }
}
