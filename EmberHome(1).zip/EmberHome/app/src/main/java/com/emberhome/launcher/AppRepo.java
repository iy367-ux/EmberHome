package com.emberhome.launcher;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.drawable.Drawable;
import android.os.Build;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public final class AppRepo {
    private AppRepo() {}
    private static List<AppEntry> cache;

    public static synchronized void invalidate() { cache = null; }

    /** All launchable apps (including hidden), in the saved order. */
    public static synchronized List<AppEntry> all(Context ctx) {
        Context c = ctx.getApplicationContext();
        if (cache == null) cache = load(c);
        List<AppEntry> copy = new ArrayList<AppEntry>(cache);
        final Map<String, Integer> idx = new HashMap<String, Integer>();
        List<String> ord = Prefs.order(c);
        for (int i = 0; i < ord.size(); i++) idx.put(ord.get(i), i);
        Collections.sort(copy, new Comparator<AppEntry>() {
            @Override public int compare(AppEntry a, AppEntry b) {
                Integer ia = idx.get(a.pkg), ib = idx.get(b.pkg);
                int x = ia == null ? 100000 : ia, y = ib == null ? 100000 : ib;
                if (x != y) return x < y ? -1 : 1;
                return a.label.compareToIgnoreCase(b.label);
            }
        });
        return copy;
    }

    public static List<AppEntry> visible(Context c) {
        List<AppEntry> out = new ArrayList<AppEntry>();
        for (AppEntry a : all(c)) if (!Prefs.isHidden(c, a.pkg)) out.add(a);
        return out;
    }

    private static List<AppEntry> load(Context c) {
        PackageManager pm = c.getPackageManager();
        List<AppEntry> out = new ArrayList<AppEntry>();
        Set<String> seen = new HashSet<String>();
        String[] cats = {"android.intent.category.LEANBACK_LAUNCHER", Intent.CATEGORY_LAUNCHER};
        for (String cat : cats) {
            Intent q = new Intent(Intent.ACTION_MAIN);
            q.addCategory(cat);
            List<ResolveInfo> list = pm.queryIntentActivities(q, 0);
            for (ResolveInfo ri : list) {
                String pkg = ri.activityInfo.packageName;
                if (pkg.equals(c.getPackageName()) || !seen.add(pkg)) continue;
                AppEntry a = new AppEntry();
                a.pkg = pkg;
                a.label = String.valueOf(ri.loadLabel(pm));
                Drawable d = null;
                if (Build.VERSION.SDK_INT >= 21) {
                    try { d = ri.activityInfo.loadBanner(pm); } catch (Throwable t) { d = null; }
                }
                if (d == null) d = ri.loadIcon(pm);
                a.icon = d;
                Intent li = new Intent(Intent.ACTION_MAIN);
                li.addCategory(cat);
                li.setComponent(new ComponentName(pkg, ri.activityInfo.name));
                li.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED);
                a.intent = li;
                a.computeColor();
                out.add(a);
            }
        }
        return out;
    }
}
