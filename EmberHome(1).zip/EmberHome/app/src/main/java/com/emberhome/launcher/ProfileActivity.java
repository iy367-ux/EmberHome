package com.emberhome.launcher;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.io.File;
import java.util.List;

/** Profile name and picture (shown on the Google TV top bar and as a greeting on Ember Dock). */
public class ProfileActivity extends Activity {
    public static final int[] COLORS = {0xFF7F5AF0, 0xFFE0562F, 0xFF2A7F62, 0xFF2F6FD1, 0xFFC2417A, 0xFFC58A1D};
    private static final String[] NAMES = {"Violet", "Ember", "Green", "Blue", "Pink", "Gold"};
    private EditText name;
    private TextView colorRow, picRow;
    private float d;
    private int dp(int v) { return (int) (v * d + 0.5f); }

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        d = getResources().getDisplayMetrics().density;
        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(0xFF0D0F14);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setPadding(dp(40), dp(48), dp(40), dp(32));
        sv.addView(root, new ViewGroup.LayoutParams(-1, -2));
        TextView title = new TextView(this);
        title.setText("Profile"); title.setTextSize(32); title.setTextColor(Color.WHITE); title.setTypeface(Typeface.DEFAULT_BOLD);
        root.addView(title, new LinearLayout.LayoutParams(dp(640), -2));
        name = new EditText(this);
        name.setHint("Your name"); name.setHintTextColor(0x80FFFFFF); name.setTextColor(Color.WHITE); name.setTextSize(22);
        name.setSingleLine(true); name.setText(Prefs.profileName(this));
        LinearLayout.LayoutParams np = new LinearLayout.LayoutParams(dp(640), -2);
        np.topMargin = dp(16); np.bottomMargin = dp(10);
        root.addView(name, np);
        colorRow = row(root);
        colorRow.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) {
            Prefs.setAvatarColor(ProfileActivity.this, (Prefs.avatarColor(ProfileActivity.this) + 1) % COLORS.length);
            Prefs.setAvatarPath(ProfileActivity.this, "");
            refresh(); } });
        picRow = row(root);
        picRow.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) {
            List<File> fs = Wallpapers.userFiles();
            String cur = Prefs.avatarPath(ProfileActivity.this), next = "";
            if (cur.length() == 0) { if (!fs.isEmpty()) next = fs.get(0).getAbsolutePath(); }
            else for (int i = 0; i < fs.size(); i++) if (fs.get(i).getAbsolutePath().equals(cur)) next = i + 1 < fs.size() ? fs.get(i + 1).getAbsolutePath() : "";
            Prefs.setAvatarPath(ProfileActivity.this, next);
            refresh(); } });
        TextView help = new TextView(this);
        help.setText("To use your own picture: copy images to  Pictures/EmberHome  on the TV, then press OK on 'Profile picture' to cycle through them. The same folder feeds My Wallpapers.");
        help.setTextColor(0x99FFFFFF); help.setTextSize(14);
        LinearLayout.LayoutParams hp = new LinearLayout.LayoutParams(dp(640), -2);
        hp.topMargin = dp(18);
        root.addView(help, hp);
        setContentView(sv);
        refresh();
    }

    @Override protected void onPause() {
        super.onPause();
        Prefs.setProfileName(this, name.getText().toString().trim());
    }

    private TextView row(LinearLayout root) {
        final TextView t = new TextView(this);
        t.setTextSize(20); t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setPadding(dp(22), dp(14), dp(22), dp(14));
        t.setFocusable(true); t.setClickable(true);
        paint(t, false);
        t.setOnFocusChangeListener(new View.OnFocusChangeListener() { @Override public void onFocusChange(View v, boolean f) { paint(t, f); } });
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(640), -2);
        lp.topMargin = dp(6);
        root.addView(t, lp);
        return t;
    }

    private void paint(TextView t, boolean f) {
        GradientDrawable g = new GradientDrawable();
        g.setCornerRadius(dp(14));
        g.setColor(f ? Color.WHITE : 0xFF161922);
        t.setBackgroundDrawable(g);
        t.setTextColor(f ? 0xFF111111 : Color.WHITE);
    }

    private void refresh() {
        int ci = Prefs.avatarColor(this) % COLORS.length;
        colorRow.setText("Picture colour:  " + NAMES[ci] + "   (OK to change)");
        String p = Prefs.avatarPath(this);
        picRow.setText("Profile picture:  " + (p.length() == 0 ? "None (uses colour)" : new File(p).getName()) + "   (OK to change)");
    }
}
