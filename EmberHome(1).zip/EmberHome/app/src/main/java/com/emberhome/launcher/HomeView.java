package com.emberhome.launcher;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapShader;
import android.graphics.Matrix;
import java.util.Calendar;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.os.SystemClock;
import android.view.KeyEvent;
import android.view.View;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Draws the whole home screen on a 1280x720 virtual canvas (scaled to the real screen)
 * so the four styles match the web preview exactly, and handles the remote control itself.
 */
public class HomeView extends View {
    public interface Host {
        void launch(AppEntry a);
        void action(int dock);                // 0 wallpapers, 1 manage apps, 2 settings, 3 screensaver
        void orderChanged(List<AppEntry> l);
    }

    private static final int W = 1280, H = 720, WHITE = 0xFFFFFFFF;
    private static final String[] DKN = {"Wallpapers", "Manage apps", "Settings", "Screensaver", "Search"};

    private Host host;
    private HomeStyle style = HomeStyle.EMBER;
    private List<AppEntry> apps = new ArrayList<AppEntry>();
    private Drawable wall, defGlass;
    private int ti, di;
    private boolean dockFocus, edit, moving, heroFocus;
    private int tab, glassLayout = 1, avatarColor = 0xFF7F5AF0;
    private String profName = "";
    private Bitmap avatar;
    private final float[] sc = new float[2];
    private float railW = 104;
    private String time = "", date = "";
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF rf = new RectF();

    public HomeView(Context c) {
        super(c);
        setFocusable(true);
        setFocusableInTouchMode(true);
    }

    public void setHost(Host h) { host = h; }
    public void setTime(String t, String d) { time = t; date = d; invalidate(); }
    public void setGlassLayout(int v) { glassLayout = v; invalidate(); }
    public void setProfile(String name, Bitmap pic, int color) { profName = name == null ? "" : name; avatar = pic; avatarColor = color; invalidate(); }

    private String greeting() {
        if (profName.length() == 0) return "";
        int h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY);
        return "  ·  " + (h < 12 ? "Good morning" : h < 18 ? "Good afternoon" : "Good evening") + ", " + profName;
    }

    private void drawAvatar(Canvas c, float cx, float cy, float r) {
        if (avatar != null) {
            BitmapShader sh = new BitmapShader(avatar, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP);
            Matrix m = new Matrix();
            float k = 2 * r / avatar.getWidth();
            m.setScale(k, k); m.postTranslate(cx - r, cy - r);
            sh.setLocalMatrix(m);
            p.setStyle(Paint.Style.FILL); p.setShader(sh);
            c.drawCircle(cx, cy, r, p);
            p.setShader(null);
        } else {
            p.setShader(null); p.setStyle(Paint.Style.FILL); p.setColor(avatarColor);
            c.drawCircle(cx, cy, r, p);
            String ini = profName.length() > 0 ? profName.substring(0, 1).toUpperCase() : "?";
            txt(c, ini, cx, cy + r * 0.36f, r * 1.0f, WHITE, true, Paint.Align.CENTER);
        }
    }

    public void setData(HomeStyle s, List<AppEntry> list, Drawable w) {
        if (s != style) { dockFocus = false; edit = false; heroFocus = false; tab = 0; di = 0; sc[0] = sc[1] = 0; }
        style = s; apps = list; wall = w;
        if (s == HomeStyle.GLASS && w == null && defGlass == null) defGlass = Wallpapers.get(getContext(), 2, 1);
        if (ti >= apps.size()) ti = Math.max(0, apps.size() - 1);
        invalidate();
    }

    // ---------- drawing helpers ----------
    private void txt(Canvas c, String s, float x, float y, float size, int color, boolean bold, Paint.Align al) {
        p.setShader(null); p.setStyle(Paint.Style.FILL); p.setTextSize(size); p.setColor(color);
        p.setTypeface(bold ? Typeface.DEFAULT_BOLD : Typeface.DEFAULT); p.setTextAlign(al);
        c.drawText(s, x, y, p);
    }
    private void rr(Canvas c, float x, float y, float w, float h, float r, int color) {
        p.setShader(null); p.setStyle(Paint.Style.FILL); p.setColor(color);
        rf.set(x, y, x + w, y + h); c.drawRoundRect(rf, r, r, p);
    }
    private void ring(Canvas c, float x, float y, float w, float h, float r, float sw, int color) {
        p.setShader(null); p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(sw); p.setColor(color);
        rf.set(x, y, x + w, y + h); c.drawRoundRect(rf, r, r, p);
        p.setStyle(Paint.Style.FILL);
    }
    private String fit(String s, float maxW, float size) {
        p.setTextSize(size); p.setTypeface(Typeface.DEFAULT_BOLD);
        if (p.measureText(s) <= maxW) return s;
        while (s.length() > 1 && p.measureText(s + "…") > maxW) s = s.substring(0, s.length() - 1);
        return s + "…";
    }
    private float ease(float cur, float tgt) {
        float d = tgt - cur;
        if (Math.abs(d) < 0.6f) return tgt;
        moving = true;
        return cur + d * 0.25f;
    }
    private AppEntry cur() { return apps.isEmpty() ? null : apps.get(Math.min(ti, apps.size() - 1)); }

    private void dockIcon(Canvas c, int k, float cx, float cy, float s) {
        float a = s / 2;
        p.setShader(null); p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(Math.max(2f, s * 0.08f));
        p.setStrokeCap(Paint.Cap.ROUND); p.setColor(WHITE);
        if (k == 0) {
            rf.set(cx - a, cy - a * .75f, cx + a, cy + a * .75f); c.drawRoundRect(rf, 4, 4, p);
            c.drawCircle(cx - a * .4f, cy - a * .2f, a * .18f, p);
            Path m = new Path(); m.moveTo(cx - a, cy + a * .45f); m.lineTo(cx - a * .2f, cy - a * .05f);
            m.lineTo(cx + a * .2f, cy + a * .3f); m.lineTo(cx + a * .5f, cy + a * .1f); m.lineTo(cx + a, cy + a * .5f);
            c.drawPath(m, p);
        } else if (k == 1) {
            float q = a * .8f;
            for (int i = 0; i < 2; i++) for (int j = 0; j < 2; j++)
                c.drawRect(cx - q + i * q * 1.1f, cy - q + j * q * 1.1f, cx - q + i * q * 1.1f + q * .9f, cy - q + j * q * 1.1f + q * .9f, p);
        } else if (k == 2) {
            Path g = new Path();
            float outer = a * .98f, inner = a * .74f, half = (float) Math.PI / 8;
            for (int i = 0; i < 8; i++) {
                double a0 = i * Math.PI / 4;
                float[][] pts = {{(float) (a0 - half * .62), inner}, {(float) (a0 - half * .38), outer}, {(float) (a0 + half * .38), outer}, {(float) (a0 + half * .62), inner}};
                for (int j = 0; j < 4; j++) {
                    float px = cx + (float) Math.cos(pts[j][0]) * pts[j][1], py = cy + (float) Math.sin(pts[j][0]) * pts[j][1];
                    if (i == 0 && j == 0) g.moveTo(px, py); else g.lineTo(px, py);
                }
            }
            g.close();
            c.drawPath(g, p);
            c.drawCircle(cx, cy, a * .3f, p);
        } else if (k == 4) {
            c.drawCircle(cx - a * .15f, cy - a * .15f, a * .55f, p);
            c.drawLine(cx + a * .25f, cy + a * .25f, cx + a * .85f, cy + a * .85f, p);
        } else {
            Path A = new Path(), B = new Path();
            A.addCircle(cx, cy, a * .85f, Path.Direction.CW);
            B.addCircle(cx + a * .45f, cy - a * .3f, a * .75f, Path.Direction.CW);
            A.op(B, Path.Op.DIFFERENCE);
            p.setStyle(Paint.Style.FILL); c.drawPath(A, p);
        }
        p.setStyle(Paint.Style.FILL);
    }

    /** Round dock/quick-access button. cap: 0 = caption above, 1 = caption below. */
    private void circleBtn(Canvas c, int k, float cx, float cy, float r, boolean f, int cap) {
        c.save();
        if (f) c.scale(1.15f, 1.15f, cx, cy);
        p.setShader(null); p.setStyle(Paint.Style.FILL); p.setColor(f ? 0x59FFFFFF : 0x33FFFFFF);
        c.drawCircle(cx, cy, r, p);
        if (f) { p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(3); p.setColor(WHITE); c.drawCircle(cx, cy, r, p); }
        dockIcon(c, k, cx, cy, r * 0.95f);
        c.restore();
        if (f) {
            String s = DKN[k]; p.setTextSize(15); p.setTypeface(Typeface.DEFAULT_BOLD);
            float tw = p.measureText(s), by = cap == 0 ? cy - r - 52 : cy + r + 16;
            rr(c, cx - tw / 2 - 12, by, tw + 24, 30, 10, 0xB3000000);
            txt(c, s, cx, by + 21, 15, WHITE, true, Paint.Align.CENTER);
        }
    }

    private void tile(Canvas c, AppEntry a, float x, float y, float w, float h, float r, boolean f, boolean glass, int mode) {
        float cx = x + w / 2, cy = y + h / 2;
        c.save();
        if (f) c.scale(1.12f, 1.12f, cx, cy);
        if (f && edit) c.rotate((float) Math.sin(SystemClock.uptimeMillis() / 60.0) * 2.5f, cx, cy);
        if (f) rr(c, x + 4, y + 14, w, h, r, 0x44000000);
        rr(c, x, y, w, h, r, glass ? 0x40FFFFFF : a.color);
        Drawable d = a.icon;
        if (d != null) {
            int iw = d.getIntrinsicWidth(), ih = d.getIntrinsicHeight();
            float ar = (iw > 0 && ih > 0) ? (float) iw / ih : 1f, tw, th;
            if (ar > 1.4f) { tw = Math.min(w * .94f, h * .92f * ar); th = tw / ar; }
            else { th = Math.min(h * .62f, w * .62f / ar); tw = th * ar; }
            int l = (int) (cx - tw / 2), t = (int) (cy - th / 2 - ((mode & 4) != 0 ? 10 : 0));
            d.setBounds(l, t, l + (int) tw, t + (int) th);
            d.draw(c);
        }
        if (f) ring(c, x, y, w, h, r, 4, edit ? 0xFFFFB36B : WHITE);
        if ((mode & 4) != 0) txt(c, fit(a.label, w - 24, 15), x + 12, y + h - 12, 15, WHITE, true, Paint.Align.LEFT);
        c.restore();
        if ((mode & 8) != 0 && f) {
            String s = fit(a.label, 260, 16);
            p.setTextSize(16); p.setTypeface(Typeface.DEFAULT_BOLD);
            float tw = p.measureText(s);
            rr(c, cx - tw / 2 - 14, y - 58, tw + 28, 34, 12, 0xCC000000);
            txt(c, s, cx, y - 35, 16, WHITE, true, Paint.Align.CENTER);
        }
        if ((mode & 1) != 0 || ((mode & 2) != 0 && f))
            txt(c, fit(a.label, w + 20, 18), cx, y + h + (f ? 34 : 30), f ? 20 : 18, WHITE, true, Paint.Align.CENTER);
    }

    private void row(Canvas c, int from, int to, float w, float h, float gap, float x0, float y, int id, int k, float r, boolean glass, int mode) {
        int pos = (tilesFocus() && ti >= from && ti < to) ? ti - from : 0;
        sc[id] = ease(sc[id], Math.max(0, pos - k) * (w + gap));
        for (int pass = 0; pass < 2; pass++)
            for (int i = from; i < to; i++) {
                boolean f = tilesFocus() && i == ti;
                if ((pass == 1) != f) continue;
                float x = x0 + (i - from) * (w + gap) - sc[id];
                if (x > W + 40 || x + w < -40) continue;
                tile(c, apps.get(i), x, y, w, h, r, f, glass, mode);
            }
    }

    // ---------- main draw ----------
    @Override protected void onDraw(Canvas c) {
        moving = false;
        c.save();
        c.scale(getWidth() / (float) W, getHeight() / (float) H);
        drawBackground(c);
        if (apps.isEmpty()) txt(c, "No apps found", W / 2f, H / 2f, 36, WHITE, true, Paint.Align.CENTER);
        else switch (style) {
            case EMBER: drawEmber(c); break;
            case CINEMA: drawCinema(c); break;
            case GLASS: drawGlass(c); break;
            default: drawGtv(c); break;
        }
        c.restore();
        if (moving || edit) postInvalidateOnAnimation();
    }

    private void drawBackground(Canvas c) {
        Drawable w = wall != null ? wall : (style == HomeStyle.GLASS ? defGlass : null);
        if (w != null) {
            w.setBounds(0, 0, W, H); w.draw(c);
            p.setShader(new LinearGradient(0, 0, 0, H, new int[]{0x66000000, 0x14000000, 0x99000000}, null, Shader.TileMode.CLAMP));
            c.drawRect(0, 0, W, H, p); p.setShader(null);
        } else if (style == HomeStyle.EMBER) {
            p.setShader(new LinearGradient(0, 0, W * .35f, H, new int[]{0xFF1C1030, 0xFF7B2D3C, 0xFFF0873A}, new float[]{0, .55f, 1}, Shader.TileMode.CLAMP));
            c.drawRect(0, 0, W, H, p); p.setShader(null);
        } else c.drawColor(style == HomeStyle.CINEMA ? 0xFF0D0F14 : 0xFF0B0C10);
    }

    private void drawEmber(Canvas c) {
        txt(c, time, 72, 120, 72, WHITE, true, Paint.Align.LEFT);
        txt(c, date + greeting(), 72, 156, 22, 0xD9FFFFFF, false, Paint.Align.LEFT);
        if (!dockFocus) txt(c, fit(cur().label, 1100, 36), 72, 290, 36, WHITE, true, Paint.Align.LEFT);
        row(c, 0, apps.size(), 168, 168, 28, 72, 326, 0, 5, 28, false, 0);
        float pw = 4 * 62 + 3 * 16 + 44, px = (W - pw) / 2, py = 600;
        rr(c, px, py, pw, 86, 43, 0x29FFFFFF);
        for (int i = 0; i < 4; i++) circleBtn(c, i, px + 22 + 31 + i * 78, py + 43, 31, dockFocus && di == i, 0);
    }

    private void drawCinema(Canvas c) {
        railW = ease(railW, dockFocus ? 300 : 104);
        boolean open = railW > 200;
        AppEntry fa = cur();
        c.save();
        c.clipRect(railW, 0, W, H);
        float hx = railW + 48, hw = W - railW - 88;
        rr(c, hx, 44, hw, 330, 24, fa.color);
        p.setShader(new LinearGradient(hx, 0, hx + hw, 0, 0x99000000, 0x00000000, Shader.TileMode.CLAMP));
        rf.set(hx, 44, hx + hw, 374); c.drawRoundRect(rf, 24, 24, p); p.setShader(null);
        if (fa.icon != null) {
            int iw = fa.icon.getIntrinsicWidth(), ih = fa.icon.getIntrinsicHeight();
            float ar = (iw > 0 && ih > 0) ? (float) iw / ih : 1f, th = 170, tw = th * ar;
            if (tw > 360) { tw = 360; th = tw / ar; }
            int l = (int) (hx + hw - 48 - tw), t = (int) (374 - 44 - th);
            fa.icon.setBounds(l, t, l + (int) tw, t + (int) th); fa.icon.draw(c);
        }
        txt(c, time, hx + hw - 48, 108, 40, WHITE, true, Paint.Align.RIGHT);
        txt(c, "Selected", hx + 36, 240, 20, 0xD9FFFFFF, false, Paint.Align.LEFT);
        txt(c, fit(fa.label, hw - 420, 54), hx + 36, 300, 54, WHITE, true, Paint.Align.LEFT);
        txt(c, "Press OK to open · hold OK to rearrange", hx + 36, 340, 17, 0xCCFFFFFF, false, Paint.Align.LEFT);
        row(c, 0, apps.size(), 140, 140, 22, hx, 434, 0, 5, 22, false, 1);
        if (open) { p.setShader(null); p.setColor(0x990D0F14); c.drawRect(railW, 0, W, H, p); }
        c.restore();
        p.setShader(null); p.setColor(0xFF161922); p.setStyle(Paint.Style.FILL);
        c.drawRect(0, 0, railW, H, p);
        float y0 = (H - (4 * 68 + 3 * 12)) / 2f;
        for (int i = 0; i < 4; i++) {
            float y = y0 + i * 80;
            if (open && dockFocus && di == i) rr(c, 20, y, railW - 40, 68, 34, 0x38FFFFFF);
            p.setColor(0x33FFFFFF); c.drawCircle(55, y + 34, 26, p);
            dockIcon(c, i, 55, y + 34, 26);
            if (open) txt(c, DKN[i], 104, y + 42, 21, WHITE, true, Paint.Align.LEFT);
        }
    }

    private boolean tilesFocus() { return !dockFocus && !heroFocus; }

    /** Top / dock button ids: 0 wallpapers, 1 manage apps, 2 settings, 3 screensaver, 4 search, -1 "For you", -2 "Apps" tab. */
    private int[] ids() {
        if (style == HomeStyle.GLASS) return new int[]{4, 3, 2};
        if (style == HomeStyle.GTV) return new int[]{4, -1, -2, 3, 2};
        return new int[]{0, 1, 2, 3};
    }

    private void drawGlass(Canvas c) {
        int[] ids = ids();
        txt(c, time, 1232, 62, 30, WHITE, true, Paint.Align.RIGHT);
        float tw = p.measureText(time), base = 1232 - tw - 40;
        for (int i = 0; i < ids.length; i++) circleBtn(c, ids[i], base - 22 - (ids.length - 1 - i) * 58, 52, 22, dockFocus && di == i, 1);
        int n = apps.size();
        boolean shelf = glassLayout == 1;
        int nd = shelf ? Math.min(8, n) : n;
        float iw = 128, ih = 96, gap = 18, dx = 40, dw = 1200, dy0 = 530;
        boolean inShelf = shelf && tilesFocus() && ti >= 8;
        float target = inShelf ? 420 + Math.max(0, (ti - 8) / 8 - 1) * 136 : 0;
        sc[1] = ease(sc[1], target);
        float off = sc[1], dy = dy0 - off;
        rr(c, dx, dy, dw, 136, 40, 0x38FFFFFF);
        ring(c, dx, dy, dw, 136, 40, 1.5f, 0x59FFFFFF);
        if (!shelf) sc[0] = ease(sc[0], Math.max(0, (tilesFocus() ? ti : 0) - 7) * (iw + gap));
        c.save();
        c.clipRect(dx + 6, 0, dx + dw - 6, H);
        for (int pass = 0; pass < 2; pass++)
            for (int i = 0; i < nd; i++) {
                boolean f = tilesFocus() && i == ti;
                if ((pass == 1) != f) continue;
                float x = dx + 28 + i * (iw + gap) - (shelf ? 0 : sc[0]);
                if (x > dx + dw || x + iw < dx) continue;
                tile(c, apps.get(i), x, dy + 20, iw, ih, 26, f, false, 8);
            }
        c.restore();
        if (shelf && n > 8) {
            float gy = dy0 + 290 - off;
            txt(c, "All apps", 60, gy - 24, 22, WHITE, true, Paint.Align.LEFT);
            for (int pass = 0; pass < 2; pass++)
                for (int i = 8; i < n; i++) {
                    boolean f = tilesFocus() && i == ti;
                    if ((pass == 1) != f) continue;
                    float x = 60 + ((i - 8) % 8) * 146, y = gy + ((i - 8) / 8) * 136;
                    if (y > H + 20 || y + ih < -40) continue;
                    tile(c, apps.get(i), x, y, iw, ih, 26, f, false, 2);
                }
        }
    }

    private void drawGtv(Canvas c) {
        AppEntry fa = cur();
        boolean grid = tab == 1;
        int tint = fa.color & 0xFFFFFF;
        p.setShader(new LinearGradient(0, 0, 0, H, new int[]{tint | 0xDD000000, 0xFF0B0C10, 0xFF0B0C10, tint | 0x55000000},
                new float[]{0, .55f, .7f, 1}, Shader.TileMode.CLAMP));
        c.drawRect(0, 0, W, H, p);
        p.setShader(new LinearGradient(0, 0, W, 0, new int[]{0xF50B0C10, 0xF50B0C10, 0x260B0C10}, new float[]{0, .28f, 1}, Shader.TileMode.CLAMP));
        c.drawRect(0, 0, W, H, p);
        p.setShader(null);
        if (!grid && fa.icon != null) {
            fa.icon.setAlpha(90); fa.icon.setBounds(W - 350, 120, W - 90, 380); fa.icon.draw(c); fa.icon.setAlpha(255);
        }
        // top bar: Search, For you, Apps, Screensaver, Settings
        int[] ids = ids();
        float x = 40;
        for (int i = 0; i < ids.length; i++) {
            int id = ids[i];
            String label = id == 4 ? "Search" : id == -1 ? "For you" : id == -2 ? "Apps" : DKN[id];
            p.setTextSize(20); p.setTypeface(Typeface.DEFAULT_BOLD);
            float bw = p.measureText(label) + (id == 4 ? 34 : 0) + 40;
            boolean f = dockFocus && di == i, act = (id == -1 && !grid) || (id == -2 && grid);
            if (id == 4) rr(c, x, 22, bw, 46, 23, 0x59000000);
            if (f) { rr(c, x, 22, bw, 46, 23, 0x4DFFFFFF); ring(c, x, 22, bw, 46, 23, 3, WHITE); }
            float tx = x + 20;
            if (id == 4) {
                p.setShader(null); p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(2); p.setColor(WHITE);
                c.drawCircle(x + 28, 43, 7, p); c.drawLine(x + 33, 48, x + 38, 53, p);
                tx = x + 48;
            }
            txt(c, label, tx, 52, 20, (act || f || id == 4) ? WHITE : 0xBFFFFFFF, true, Paint.Align.LEFT);
            if (act && !f) rr(c, x + 20, 64, bw - 40, 3, 1.5f, WHITE);
            x += bw + 8;
        }
        float rx = W - 100;
        if (profName.length() > 0) {
            txt(c, profName, rx, 58, 18, 0xE6FFFFFF, true, Paint.Align.RIGHT);
            rx -= p.measureText(profName) + 24;
        }
        txt(c, time, rx, 60, 26, WHITE, true, Paint.Align.RIGHT);
        drawAvatar(c, W - 68, 52, 20);
        if (grid) {
            txt(c, "Apps", 48, 122, 26, WHITE, true, Paint.Align.LEFT);
            int n = apps.size();
            float pitch = 146;
            sc[1] = ease(sc[1], Math.max(0, ti / 5 - 2) * pitch);
            c.save();
            c.clipRect(0, 140, W, H);
            for (int pass = 0; pass < 2; pass++)
                for (int i = 0; i < n; i++) {
                    boolean f = tilesFocus() && i == ti;
                    if ((pass == 1) != f) continue;
                    float tx = 48 + (i % 5) * 220, ty = 160 - sc[1] + (i / 5) * pitch;
                    if (ty > H || ty + 112 < 140) continue;
                    tile(c, apps.get(i), tx, ty, 200, 112, 16, f, false, 4);
                }
            c.restore();
            return;
        }
        txt(c, "YOUR APP", 64, 176, 18, 0xCCFFFFFF, true, Paint.Align.LEFT);
        txt(c, fit(fa.label, 640, 56), 64, 244, 56, WHITE, true, Paint.Align.LEFT);
        txt(c, "Open " + fa.label + " to pick up where you left off.", 64, 286, 19, 0xD9FFFFFF, false, Paint.Align.LEFT);
        c.save();
        if (heroFocus) c.scale(1.07f, 1.07f, 139, 336);
        rr(c, 64, 312, 150, 48, 24, heroFocus ? WHITE : 0x47FFFFFF);
        if (heroFocus) ring(c, 64, 312, 150, 48, 24, 3, 0xFF7F5AF0);
        txt(c, "▶  Open", 139, 343, 20, heroFocus ? 0xFF111111 : WHITE, true, Paint.Align.CENTER);
        c.restore();
        txt(c, "Your apps", 48, 466, 22, WHITE, true, Paint.Align.LEFT);
        row(c, 0, apps.size(), 200, 112, 20, 48, 502, 0, 5, 16, false, 4);
    }

    // ---------- remote control ----------
    @Override public boolean onKeyDown(int code, KeyEvent e) {
        switch (code) {
            case KeyEvent.KEYCODE_DPAD_LEFT: dir(0); return true;
            case KeyEvent.KEYCODE_DPAD_RIGHT: dir(1); return true;
            case KeyEvent.KEYCODE_DPAD_UP: dir(2); return true;
            case KeyEvent.KEYCODE_DPAD_DOWN: dir(3); return true;
            case KeyEvent.KEYCODE_DPAD_CENTER:
            case KeyEvent.KEYCODE_ENTER:
            case KeyEvent.KEYCODE_NUMPAD_ENTER:
                e.startTracking(); return true;
            case KeyEvent.KEYCODE_BACK:
                if (edit) { edit = false; if (host != null) host.orderChanged(apps); }
                else if (style == HomeStyle.GTV && tab == 1) { tab = 0; ti = 0; }
                invalidate();
                return true;                       // a launcher never "goes back"
        }
        return super.onKeyDown(code, e);
    }

    @Override public boolean onKeyUp(int code, KeyEvent e) {
        if (code == KeyEvent.KEYCODE_DPAD_CENTER || code == KeyEvent.KEYCODE_ENTER || code == KeyEvent.KEYCODE_NUMPAD_ENTER) {
            if (e.isTracking() && !e.isCanceled()) ok();
            return true;
        }
        return super.onKeyUp(code, e);
    }

    @Override public boolean onKeyLongPress(int code, KeyEvent e) {
        if (code == KeyEvent.KEYCODE_DPAD_CENTER || code == KeyEvent.KEYCODE_ENTER || code == KeyEvent.KEYCODE_NUMPAD_ENTER) {
            if (tilesFocus() && !apps.isEmpty() && !edit) { edit = true; invalidate(); }
            return true;
        }
        return super.onKeyLongPress(code, e);
    }

    private void ok() {
        if (edit) { edit = false; if (host != null) host.orderChanged(apps); }
        else if (heroFocus) { if (host != null && !apps.isEmpty()) host.launch(cur()); }
        else if (dockFocus) {
            int id = ids()[di];
            if (id >= 0) { if (host != null) host.action(id); }
            else if (id == -1) { tab = 0; dockFocus = false; heroFocus = true; }
            else { tab = 1; dockFocus = false; ti = 0; }
        }
        else if (!apps.isEmpty() && host != null) host.launch(apps.get(ti));
        invalidate();
    }

    private void move(int d) {
        int j = ti + d;
        if (j < 0 || j >= apps.size()) return;
        Collections.swap(apps, ti, j);
        ti = j;
        if (host != null) host.orderChanged(apps);
    }

    private static int shelfRow(int i) { return i < 8 ? -1 : (i - 8) / 8; }

    private void dir(int d) {            // 0 left, 1 right, 2 up, 3 down
        int n = apps.size(), nd = ids().length;
        boolean gl = style == HomeStyle.GLASS, cin = style == HomeStyle.CINEMA, tv = style == HomeStyle.GTV, em = style == HomeStyle.EMBER;
        boolean sh = gl && glassLayout == 1;
        if (tilesFocus()) {
            if (n == 0) return;
            if (d == 0) { if (edit) move(-1); else if (ti > 0 && !(sh && ti >= 8 && ti % 8 == 0)) ti--; else if (cin) dockFocus = true; }
            else if (d == 1) { if (edit) move(1); else ti = Math.min(sh && ti < 8 ? Math.min(7, n - 1) : n - 1, ti + 1); }
            else if (d == 3 && !edit) {
                if (em) dockFocus = true;
                else if (sh && n > 8) { int nx = ti + 8; if (nx <= n - 1) ti = nx; else if (shelfRow(n - 1) > shelfRow(ti)) ti = n - 1; }
                else if (tv && tab == 1) ti = Math.min(n - 1, ti + 5);
            } else if (d == 2 && !edit) {
                if (gl) { if (sh && ti >= 8) ti -= 8; else dockFocus = true; }
                else if (tv) { if (tab == 1) { if (ti >= 5) ti -= 5; else dockFocus = true; } else heroFocus = true; }
            }
        } else if (heroFocus) {
            if (d == 2) { heroFocus = false; dockFocus = true; }
            if (d == 3) heroFocus = false;
        } else if (cin) {
            if (d == 2) di = Math.max(0, di - 1);
            if (d == 3) di = Math.min(nd - 1, di + 1);
            if (d == 1) dockFocus = false;
        } else {
            if (d == 0) di = Math.max(0, di - 1);
            if (d == 1) di = Math.min(nd - 1, di + 1);
            if (d == 2 && em) dockFocus = false;
            if (d == 3 && !em) {
                dockFocus = false;
                if (tv) { if (tab == 0) heroFocus = true; }
                else ti = Math.min(ti, sh ? Math.min(7, n - 1) : n - 1);
            }
        }
        invalidate();
    }
}
