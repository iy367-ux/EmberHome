package com.emberhome.launcher;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.drawable.Drawable;

public class AppEntry {
    public String pkg, label;
    public Drawable icon;
    public Intent intent;
    public int color = 0xFF3A3F55;

    /** Average colour of the icon, darkened, used for tile and hero backgrounds. */
    public void computeColor() {
        if (icon == null) return;
        try {
            Bitmap b = Bitmap.createBitmap(16, 16, Bitmap.Config.ARGB_8888);
            icon.setBounds(0, 0, 16, 16);
            icon.draw(new Canvas(b));
            long r = 0, g = 0, bl = 0, n = 0;
            for (int x = 0; x < 16; x++) for (int y = 0; y < 16; y++) {
                int p = b.getPixel(x, y);
                if (Color.alpha(p) < 128) continue;
                r += Color.red(p); g += Color.green(p); bl += Color.blue(p); n++;
            }
            b.recycle();
            if (n == 0) return;
            float[] hsv = new float[3];
            Color.RGBToHSV((int) (r / n), (int) (g / n), (int) (bl / n), hsv);
            hsv[2] = Math.min(hsv[2], 0.65f);
            if (hsv[2] < 0.25f) hsv[2] = 0.25f;
            color = Color.HSVToColor(hsv);
        } catch (Throwable t) { /* keep default */ }
    }
}
