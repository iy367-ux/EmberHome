package com.emberhome.launcher;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.media.AudioManager;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.List;

/**
 * Two-pane settings (categories 34% / settings 66%). Every row reads and writes a real preference that the launcher uses.
 * Remote: Up/Down move, Right/OK enter the settings pane, Left/Back return to the categories, OK changes the value.
 */
public class SettingsActivity extends Activity {
    private static final String[] CATS = {"Appearance", "Screensaver", "Weather", "Clock & Date", "Home Screen", "Applications", "Accessibility", "About EmberHome"};
    private static final int[] ACC = {0xFFFFFFFF, 0xFFFFB36B, 0xFF6AA9FF, 0xFF4ADE80, 0xFFFF7AB6, 0xFFB794F6};

    // ------------------------------------------------------------ row model
    interface V { String get(); }
    abstract class It {
        String label, desc = "";
        boolean focusable = true;
        abstract String val();
        void act() {}
        boolean bar() { return false; }
        int level() { return 0; }
        int levels() { return 0; }
    }
    class Hdr extends It { Hdr(String l) { label = l; focusable = false; } String val() { return ""; } }
    class Info extends It { String v; Info(String l, String v) { label = l; this.v = v; } String val() { return v; } }
    class Tog extends It {
        String key; boolean def;
        Tog(String l, String d, String k, boolean def) { label = l; desc = d; key = k; this.def = def; }
        String val() { return Prefs.getb(SettingsActivity.this, key, def) ? "On" : "Off"; }
        void act() { Prefs.putb(SettingsActivity.this, key, !Prefs.getb(SettingsActivity.this, key, def)); }
    }
    class Ch extends It {
        String key; int def; String[] o; boolean slider; Runnable after;
        Ch(String l, String d, String k, int def, String... o) { label = l; desc = d; key = k; this.def = def; this.o = o; slider = o.length >= 3 && o.length <= 5; }
        int get() { return Math.max(0, Math.min(o.length - 1, Prefs.geti(SettingsActivity.this, key, def))); }
        void set(int v) { Prefs.puti(SettingsActivity.this, key, v); }
        String val() { return o[get()]; }
        void act() { set((get() + 1) % o.length); if (after != null) after.run(); }
        boolean bar() { return slider; }
        int level() { return get(); }
        int levels() { return o.length; }
    }
    class Act extends It {
        V v; Runnable r;
        Act(String l, String d, V v, Runnable r) { label = l; desc = d; this.v = v; this.r = r; }
        String val() { return v == null ? "›" : v.get() + "  ›"; }
        void act() { r.run(); }
    }

    // ------------------------------------------------------------ state
    private int cat, pane, cur;
    private final int[] last = new int[CATS.length];
    private List<It> items = new ArrayList<It>();
    private LinearLayout leftCol, rightCol;
    private ScrollView rightScroll;
    private float d, tScale, uScale;
    private int accent;
    private boolean hi;

    private int dp(float v) { return (int) (v * d * uScale + 0.5f); }
    private float sp(float v) { return v * tScale; }

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        d = getResources().getDisplayMetrics().density;
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.HORIZONTAL);
        root.setBackgroundColor(0xFF0B0C10);
        root.setWeightSum(100);
        leftCol = new LinearLayout(this);
        leftCol.setOrientation(LinearLayout.VERTICAL);
        leftCol.setBackgroundColor(0xFF111319);
        root.addView(leftCol, new LinearLayout.LayoutParams(0, -1, 34));
        rightScroll = new ScrollView(this);
        rightCol = new LinearLayout(this);
        rightCol.setOrientation(LinearLayout.VERTICAL);
        rightScroll.addView(rightCol, new ViewGroup.LayoutParams(-1, -2));
        root.addView(rightScroll, new LinearLayout.LayoutParams(0, -1, 66));
        setContentView(root);
        cat = Math.max(0, Math.min(CATS.length - 1, getIntent().getIntExtra("cat", 0)));
        pane = getIntent().hasExtra("cat") ? 1 : 0;
    }

    @Override protected void onResume() { super.onResume(); render(); }

    // ------------------------------------------------------------ rendering
    private void readLook() {
        tScale = new float[]{1f, 1.15f, 1.3f}[Math.max(0, Math.min(2, Prefs.geti(this, "text_size", 0)))];
        uScale = Prefs.getb(this, "large_ctrl", false) ? 1.2f : 1f;
        accent = ACC[Math.max(0, Math.min(5, Prefs.geti(this, "accent", 0)))];
        hi = Prefs.getb(this, "hi_contrast", false);
    }

    private void render() {
        readLook();
        items = build(cat);
        int n = items.size();
        cur = Math.max(0, Math.min(n - 1, last[cat]));
        if (cur < n && !items.get(cur).focusable) cur = firstFocusable();
        drawLeft();
        drawRight();
    }

    private TextView tv(String s, float size, boolean bold, int col) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(sp(size)); t.setTextColor(col);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private void drawLeft() {
        leftCol.removeAllViews();
        leftCol.setPadding(dp(24), dp(40), dp(16), dp(24));
        TextView title = tv("Settings", 30, true, Color.WHITE);
        title.setPadding(dp(14), 0, 0, dp(18));
        leftCol.addView(title);
        for (int i = 0; i < CATS.length; i++) {
            boolean sel = i == cat;
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(dp(14), dp(11), dp(14), dp(11));
            GradientDrawable g = new GradientDrawable();
            g.setCornerRadius(dp(14));
            g.setColor(sel ? (pane == 0 ? Color.WHITE : 0x26FFFFFF) : 0x00000000);
            if (sel && pane == 1) g.setStroke(dp(1), 0x33FFFFFF);
            row.setBackgroundDrawable(g);
            row.addView(new IconView(this, i, sel && pane == 0 ? 0xFF111111 : Color.WHITE), new LinearLayout.LayoutParams(dp(26), dp(26)));
            TextView t = tv(CATS[i], 19, sel, sel && pane == 0 ? 0xFF111111 : sel ? Color.WHITE : 0xB3FFFFFF);
            t.setPadding(dp(16), 0, 0, 0);
            row.addView(t);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
            lp.bottomMargin = dp(4);
            leftCol.addView(row, lp);
        }
    }

    private void drawRight() {
        final int keep = rightScroll.getScrollY();
        rightCol.removeAllViews();
        rightCol.setPadding(dp(40), dp(40), dp(48), dp(40));
        TextView title = tv(CATS[cat], 30, true, Color.WHITE);
        title.setPadding(0, 0, 0, dp(14));
        rightCol.addView(title);
        View selected = null;
        for (int i = 0; i < items.size(); i++) {
            It it = items.get(i);
            if (it instanceof Hdr) {
                TextView h = tv(it.label.toUpperCase(), 14, true, 0x99FFFFFF);
                h.setPadding(dp(8), dp(18), 0, dp(4));
                rightCol.addView(h);
                continue;
            }
            boolean sel = pane == 1 && i == cur;
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(dp(22), dp(13), dp(22), dp(13));
            GradientDrawable g = new GradientDrawable();
            g.setCornerRadius(dp(14));
            g.setColor(sel ? Color.WHITE : hi ? 0xFF1B1E27 : 0xFF14161D);
            g.setStroke(dp(sel ? 3 : 1), sel ? accent : hi ? 0x66FFFFFF : 0x1FFFFFFF);
            row.setBackgroundDrawable(g);
            LinearLayout txt = new LinearLayout(this);
            txt.setOrientation(LinearLayout.VERTICAL);
            txt.addView(tv(it.label, 19, true, sel ? 0xFF111111 : Color.WHITE));
            if (it.desc.length() > 0) txt.addView(tv(it.desc, 14, false, sel ? 0xFF555555 : 0xB3FFFFFF));
            row.addView(txt, new LinearLayout.LayoutParams(0, -2, 1f));
            LinearLayout val = new LinearLayout(this);
            val.setOrientation(LinearLayout.VERTICAL);
            val.setGravity(Gravity.RIGHT);
            boolean tog = it instanceof Tog;
            boolean on = tog && it.val().equals("On");
            TextView vt = tv(it instanceof Ch ? "‹  " + it.val() + "  ›" : it.val(), 18, true, sel ? 0xFF111111 : tog ? (on ? accent == 0xFFFFFFFF ? 0xFFFFB36B : accent : 0x99FFFFFF) : 0xE6FFFFFF);
            val.addView(vt);
            if (it.bar()) {
                LinearLayout seg = new LinearLayout(this);
                seg.setGravity(Gravity.RIGHT);
                for (int s = 0; s < it.levels(); s++) {
                    View b = new View(this);
                    b.setBackgroundColor(s <= it.level() ? (sel ? 0xFF111111 : accent) : (sel ? 0x33000000 : 0x33FFFFFF));
                    LinearLayout.LayoutParams sl = new LinearLayout.LayoutParams(dp(18), dp(5));
                    sl.leftMargin = dp(4); sl.topMargin = dp(6);
                    seg.addView(b, sl);
                }
                val.addView(seg);
            }
            row.addView(val, new LinearLayout.LayoutParams(-2, -2));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
            lp.topMargin = dp(8);
            rightCol.addView(row, lp);
            if (i == cur) selected = row;
        }
        final View sel = selected;
        rightScroll.post(new Runnable() { public void run() {
            rightScroll.scrollTo(0, keep);
            if (sel == null || pane != 1) return;
            int top = sel.getTop(), bot = sel.getBottom(), h = rightScroll.getHeight();
            if (top < rightScroll.getScrollY() + dp(60)) rightScroll.smoothScrollTo(0, Math.max(0, top - dp(80)));
            else if (bot > rightScroll.getScrollY() + h - dp(30)) rightScroll.smoothScrollTo(0, bot - h + dp(60));
        } });
    }

    /** Small category icons drawn in code. */
    static class IconView extends View {
        final int k, col;
        final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        IconView(Context c, int k, int col) { super(c); this.k = k; this.col = col; }
        @Override protected void onDraw(Canvas c) {
            float w = getWidth(), cx = w / 2, cy = w / 2, r = w * .38f;
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(w * .09f); p.setColor(col); p.setStrokeCap(Paint.Cap.ROUND);
            switch (k) {
                case 0: c.drawCircle(cx, cy, r, p); p.setStyle(Paint.Style.FILL); c.drawCircle(cx - r * .4f, cy - r * .2f, w * .06f, p); c.drawCircle(cx + r * .3f, cy - r * .35f, w * .06f, p); c.drawCircle(cx + r * .1f, cy + r * .4f, w * .06f, p); break;
                case 1: p.setStyle(Paint.Style.FILL); c.drawCircle(cx, cy, r, p); p.setColor(0xFF111319); c.drawCircle(cx + r * .5f, cy - r * .4f, r * .85f, p); break;
                case 2: p.setStyle(Paint.Style.FILL); c.drawCircle(cx - r * .35f, cy + r * .1f, r * .5f, p); c.drawCircle(cx + r * .2f, cy - r * .2f, r * .6f, p); c.drawCircle(cx + r * .6f, cy + r * .2f, r * .4f, p); c.drawRect(cx - r * .85f, cy + r * .1f, cx + r, cy + r * .6f, p); break;
                case 3: c.drawCircle(cx, cy, r, p); c.drawLine(cx, cy, cx, cy - r * .6f, p); c.drawLine(cx, cy, cx + r * .45f, cy, p); break;
                case 4: c.drawLine(cx - r, cy, cx, cy - r, p); c.drawLine(cx, cy - r, cx + r, cy, p); c.drawRect(cx - r * .65f, cy, cx + r * .65f, cy + r, p); break;
                case 5: float q = r * .85f; for (int i = 0; i < 2; i++) for (int j = 0; j < 2; j++) c.drawRect(cx - q + i * q * 1.1f, cy - q + j * q * 1.1f, cx - q + i * q * 1.1f + q * .9f, cy - q + j * q * 1.1f + q * .9f, p); break;
                case 6: p.setStyle(Paint.Style.FILL); c.drawCircle(cx, cy - r * .6f, r * .3f, p); p.setStyle(Paint.Style.STROKE); c.drawLine(cx - r * .8f, cy - r * .1f, cx + r * .8f, cy - r * .1f, p); c.drawLine(cx, cy - r * .1f, cx, cy + r * .4f, p); c.drawLine(cx, cy + r * .4f, cx - r * .5f, cy + r, p); c.drawLine(cx, cy + r * .4f, cx + r * .5f, cy + r, p); break;
                default: c.drawCircle(cx, cy, r, p); p.setStyle(Paint.Style.FILL); c.drawCircle(cx, cy - r * .45f, w * .05f, p); c.drawRect(cx - w * .04f, cy - r * .15f, cx + w * .04f, cy + r * .55f, p);
            }
        }
    }

    // ------------------------------------------------------------ navigation
    private int firstFocusable() { for (int i = 0; i < items.size(); i++) if (items.get(i).focusable) return i; return 0; }

    private void sound() {
        if (Prefs.getb(this, "ui_sound", false)) ((AudioManager) getSystemService(Context.AUDIO_SERVICE)).playSoundEffect(AudioManager.FX_FOCUS_NAVIGATION_UP);
    }

    private void moveItem(int dir) {
        int i = cur + dir;
        while (i >= 0 && i < items.size() && !items.get(i).focusable) i += dir;
        if (i < 0 || i >= items.size()) return;
        cur = i; last[cat] = i;
        drawRight();
    }

    @Override public boolean onKeyDown(int code, KeyEvent e) {
        switch (code) {
            case KeyEvent.KEYCODE_DPAD_UP:
                sound();
                if (pane == 0) { if (cat > 0) { cat--; render(); } } else moveItem(-1);
                return true;
            case KeyEvent.KEYCODE_DPAD_DOWN:
                sound();
                if (pane == 0) { if (cat < CATS.length - 1) { cat++; render(); } } else moveItem(1);
                return true;
            case KeyEvent.KEYCODE_DPAD_LEFT:
                if (pane == 1) { pane = 0; drawLeft(); drawRight(); }
                return true;
            case KeyEvent.KEYCODE_DPAD_RIGHT:
                if (pane == 0) enter();
                return true;
            case KeyEvent.KEYCODE_DPAD_CENTER:
            case KeyEvent.KEYCODE_ENTER:
                if (e.getRepeatCount() > 0) return true;
                if (pane == 0) enter(); else activate();
                return true;
            case KeyEvent.KEYCODE_BACK:
                if (pane == 1) { pane = 0; drawLeft(); drawRight(); return true; }
                finish();
                return true;
        }
        return super.onKeyDown(code, e);
    }

    private void enter() {
        pane = 1;
        if (cur >= items.size() || !items.get(cur).focusable) cur = firstFocusable();
        drawLeft(); drawRight();
    }

    private void activate() {
        if (cur < 0 || cur >= items.size()) return;
        items.get(cur).act();
        sound();
        readLook();
        items = build(cat);              // values (and visibility) may have changed
        cur = Math.min(cur, items.size() - 1);
        drawLeft();
        drawRight();
    }

    // ------------------------------------------------------------ content
    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_LONG).show(); }

    private void open(Class<?> c) { startActivity(new Intent(this, c)); }

    private void system(String action) {
        try { startActivity(new Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); }
        catch (Throwable t) { toast("Not available on this TV"); }
    }

    private void dialog(String title, String msg) {
        new AlertDialog.Builder(this).setTitle(title).setMessage(msg).setPositiveButton("OK", null).show();
    }

    private String modeName() {
        String m = Prefs.gets(this, "sv_mode", "clock");
        if (m.equals("ambient")) return SaverRenderer.AMBIENTS[Prefs.geti(this, "sv_amb", 0) % 5];
        if (m.equals("media")) return "My media";
        if (m.equals("cinematic")) return "Cinematic";
        return SaverRenderer.CLOCKS[Prefs.geti(this, "sv_clock", 0) % 7];
    }

    private void askCity() {
        final EditText et = new EditText(this);
        et.setSingleLine(true);
        et.setText(Prefs.gets(this, "w_city", ""));
        new AlertDialog.Builder(this).setTitle("Weather city").setMessage("Type a city name (needs internet)").setView(et)
                .setPositiveButton("Search", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface dlg, int w) {
                        final String q = et.getText().toString().trim();
                        if (q.length() == 0) return;
                        toast("Searching...");
                        new Thread(new Runnable() { public void run() {
                            String msg;
                            try { String r = Weather.geocode(SettingsActivity.this, q); msg = r == null ? "No place found for \"" + q + "\"" : "Location set: " + r; }
                            catch (Throwable t) { msg = "Could not reach the geocoding service (offline?)"; }
                            final String fm = msg;
                            runOnUiThread(new Runnable() { public void run() { toast(fm); Weather.refresh(SettingsActivity.this, true, null); render(); } });
                        } }).start();
                    }
                }).setNegativeButton("Cancel", null).show();
    }

    private String diagnostics() {
        Runtime rt = Runtime.getRuntime();
        StringBuilder b = new StringBuilder();
        b.append("Memory: ").append((rt.totalMemory() - rt.freeMemory()) / 1048576).append(" MB used of ").append(rt.maxMemory() / 1048576).append(" MB\n");
        b.append("Apps found: ").append(AppRepo.all(this).size()).append(", hidden ").append(Prefs.list(this, "hidden").size())
                .append(", favourites ").append(Prefs.list(this, "fav").size()).append("\n");
        int n = Weather.netType(this);
        b.append("Network: ").append(n == 0 ? "none" : n == 1 ? "Wi-Fi" : n == 2 ? "Ethernet" : "other").append("\n");
        Weather.Now w = Weather.cached(this);
        b.append("Weather cache: ").append(w == null ? "empty" : ((System.currentTimeMillis() - w.time) / 60000) + " min old").append(", ").append(Weather.status.length() > 0 ? Weather.status : "no request yet this session").append("\n");
        int missing = 0;
        List<MyMedia.Item> mm = MyMedia.list(this);
        for (MyMedia.Item i : mm) if (!MyMedia.exists(this, i.uri)) missing++;
        b.append("My media: ").append(mm.size()).append(" items, ").append(missing).append(" missing\n");
        b.append("Cinematic: ").append(Cinematic.catalog(this).size()).append(" catalogue items, ").append(Cinematic.freeBytes(this) / 1048576).append(" MB free\n");
        b.append("Screensaver: ").append(modeName());
        return b.toString();
    }

    private Tog tog(String l, String d, String k, boolean def) { return new Tog(l, d, k, def); }

    private List<It> build(int c) {
        final SettingsActivity a = this;
        List<It> l = new ArrayList<It>();
        switch (c) {
            case 0: {
                l.add(new Ch("Accent colour", "Focus highlights across the launcher", "accent", 0, "White", "Ember", "Sky", "Green", "Pink", "Violet"));
                l.add(new Ch("Background dimming", "How much the wallpaper is darkened behind apps", "dim", 1, "Light", "Normal", "Strong", "Maximum"));
                l.add(new Ch("Layout density", "Space between app tiles", "density", 1, "Compact", "Normal", "Comfortable"));
                l.add(tog("UI animations", "Smooth scrolling and focus movement", "anim", true));
                l.add(new Hdr("Personalise"));
                l.add(new Act("Wallpaper", "Illustrated scenes, colours or your own pictures", new V() { public String get() { return Prefs.wall(a).length() == 0 ? "Style default" : "Custom"; } }, new Runnable() { public void run() { open(WallpaperActivity.class); } }));
                l.add(new Act("Profile", "Name and one of 50 built-in pictures", new V() { public String get() { String n = Prefs.profileName(a); return n.length() == 0 ? "Not set" : n; } }, new Runnable() { public void run() { open(ProfileActivity.class); } }));
                break; }
            case 1: {
                l.add(new Hdr("General"));
                l.add(tog("Screensaver", "Start automatically when the TV is idle", "sv_on", true));
                l.add(new Ch("Start after", "Idle time before it starts", "sv_idle", 1, "1 min", "5 min", "10 min", "15 min", "30 min"));
                l.add(new Act("Screensaver Gallery", "Choose, preview and manage screensavers", new V() { public String get() { return modeName(); } }, new Runnable() { public void run() { open(ScreensaverGalleryActivity.class); } }));
                l.add(tog("Rotate clock styles", "Change the clock style automatically", "sv_rot", false));
                l.add(new Ch("Rotation interval", "How often the clock style changes", "sv_rotint", 1, "1 min", "5 min", "15 min"));
                l.add(new Ch("Stop after", "Goes black so the TV can sleep", "sv_max", 2, "Never", "1 hour", "2 hours", "4 hours"));
                l.add(new Ch("Screen brightness", "Dims the screen while the screensaver runs", "sv_dim", 0, "Full", "60%", "30%"));
                l.add(new Ch("Animation quality", "Efficient or static suits weaker devices", "sv_fps", 0, "Smooth", "Efficient", "Static"));
                l.add(new Hdr("Clock"));
                l.add(new Ch("Size", "", "sv_csize", 1, "Small", "Medium", "Large"));
                l.add(new Ch("Position", "", "sv_cpos", 0, "Centre", "Lower left", "Upper right", "Lower right"));
                l.add(new Ch("Colour", "", "sv_ccol", 0, "White", "Ember", "Sky", "Green", "Pink", "Gold"));
                l.add(tog("Show date", "", "sv_date", true));
                l.add(tog("Show seconds", "", "sv_secs", false));
                l.add(new Hdr("Ambient"));
                l.add(new Ch("Intensity", "Amount of movement and particles", "sv_int", 1, "Calm", "Normal", "Lively"));
                l.add(new Hdr("Photos and videos"));
                l.add(new Ch("Slideshow interval", "", "sv_slide", 1, "5 sec", "10 sec", "30 sec", "1 min"));
                l.add(tog("Play videos", "Videos that your TV cannot decode are skipped", "sv_video", true));
                l.add(new Ch("Order", "", "sv_order", 0, "Sequential", "Random"));
                l.add(new Ch("Transition", "", "sv_trans", 0, "Fade", "Slide", "None"));
                l.add(tog("Slow zoom on photos", "Ken Burns movement (off by default for weaker devices)", "sv_kb", false));
                l.add(tog("Clock overlay", "", "sv_oclock", true));
                l.add(tog("Date overlay", "", "sv_odate", true));
                l.add(tog("Weather overlay", "Uses the last weather reading", "sv_owx", false));
                l.add(new Act("My Screensavers", "Import and manage your own photos and videos", new V() { public String get() { return MyMedia.list(a).size() + " items"; } }, new Runnable() { public void run() { startActivity(new Intent(a, ScreensaverGalleryActivity.class).putExtra("tab", 3)); } }));
                l.add(new Act("Cinematic Library", "Verified real-world media (downloads on request)", new V() { public String get() { int n = Cinematic.catalog(a).size(); return n == 0 ? "No content yet" : n + " items"; } }, new Runnable() { public void run() { startActivity(new Intent(a, ScreensaverGalleryActivity.class).putExtra("tab", 2)); } }));
                break; }
            case 2: {
                Runnable fresh = new Runnable() { public void run() { Prefs.puts(a, "w_cache_key", ""); Weather.refresh(a, false, null); } };
                l.add(tog("Show weather on Home", "A small icon and temperature in the status area", "show_weather", true));
                Ch mode = new Ch("Location", "Automatic uses the TV's last known location, otherwise your city", "w_mode", 0, "Automatic", "Manual city");
                mode.after = fresh;
                l.add(mode);
                l.add(new Act("City", "Used for Manual, and as the fallback for Automatic", new V() { public String get() { String s = Prefs.gets(a, "w_city", ""); return s.length() == 0 ? "Not set" : s; } }, new Runnable() { public void run() { askCity(); } }));
                Ch units = new Ch("Temperature", "", "w_f", 0, "Celsius", "Fahrenheit");
                units.after = fresh;
                l.add(units);
                l.add(new Ch("Refresh every", "Cached between refreshes; works offline with the last reading", "w_int", 1, "30 min", "1 hour", "3 hours"));
                l.add(new Hdr("Weather details"));
                l.add(tog("Show wind", "", "w_wind", true));
                l.add(tog("Show humidity", "", "w_hum", true));
                l.add(tog("Show rain chance", "", "w_pre", true));
                l.add(new Ch("Forecast", "", "w_days", 1, "Today", "3 days"));
                l.add(new Act("View weather details", "Current conditions and forecast", null, new Runnable() { public void run() { dialog("Weather", Weather.details(a)); } }));
                l.add(new Act("Refresh now", "", null, new Runnable() { public void run() {
                    Weather.refresh(a, true, new Runnable() { public void run() { toast(Weather.status); } }); toast("Refreshing..."); } }));
                l.add(new Info("Data", "Open-Meteo.com"));
                break; }
            case 3: {
                l.add(tog("Show clock", "On the home screen", "show_clock", true));
                l.add(tog("Show date", "On the home screen", "show_date", true));
                l.add(new Ch("Time format", "Also used by the screensaver", "clock24", 0, "12-hour", "24-hour") {
                    @Override int get() { return Prefs.getb(a, "clock24", false) ? 1 : 0; }
                    @Override void set(int v) { Prefs.putb(a, "clock24", v == 1); } });
                l.add(tog("Show seconds", "On the home screen", "show_secs", false));
                l.add(new Ch("Date format", "", "date_fmt", 0, "Friday, 21 November", "Fri, 21 Nov 2026", "21/11/2026", "11/21/2026"));
                l.add(new Ch("Time zone name", "Shown after the date", "show_tz", 0, "Hidden", "Shown") {
                    @Override int get() { return Prefs.getb(a, "show_tz", false) ? 1 : 0; }
                    @Override void set(int v) { Prefs.putb(a, "show_tz", v == 1); } });
                l.add(new Info("Note", "EmberHome follows the TV's clock; it cannot change it"));
                break; }
            case 4: {
                l.add(new Ch("Home style", "", "style", 0, labels()) {
                    @Override int get() { return Prefs.style(a).ordinal(); }
                    @Override void set(int v) { Prefs.setStyle(a, HomeStyle.values()[v]); } });
                l.add(new Ch("Glass (tvOS) dock layout", "Scrolling dock, or 6 apps with the rest below", "glass", 1, "Scrolling dock", "Apps below dock") {
                    @Override int get() { return Prefs.glassLayout(a); }
                    @Override void set(int v) { Prefs.setGlassLayout(a, v); } });
                l.add(new Ch("Icon size", "", "icon_size", 1, "Small", "Medium", "Large"));
                l.add(new Ch("Quick access bar position", "Glass (tvOS) style", "gp", 0, "Top right", "Top centre", "Top left"));
                l.add(new Ch("Cinema hero", "What the whole top hero area shows", "cin_hero", 0, "Selected app", "Clock, date and weather", "Wallpaper"));
                l.add(new Hdr("Status area"));
                l.add(tog("Show clock", "", "show_clock", true));
                l.add(tog("Show weather", "", "show_weather", true));
                l.add(tog("Show network indicator", "Wi-Fi or Ethernet icon", "show_net", true));
                l.add(new Hdr("Layout"));
                l.add(new Info("Arrange apps", "Hold OK on an app, move it with the arrows, press OK to save"));
                l.add(new Act("Reset app order and wallpaper", "Also clears hidden apps and favourites", null, new Runnable() { public void run() { Prefs.resetLayout(a); toast("Reset"); } }));
                break; }
            case 5: {
                l.add(new Act("Manage apps", "Show, hide or favourite apps", new V() { public String get() { return Prefs.list(a, "hidden").size() + " hidden, " + Prefs.list(a, "fav").size() + " favourite"; } }, new Runnable() { public void run() { open(AppsActivity.class); } }));
                l.add(new Ch("Sort order", "Custom keeps your own arrangement", "sort", 0, "Custom", "A to Z", "Newest first"));
                l.add(tog("Favourites first", "Show favourite apps before the others", "fav_first", true));
                l.add(new Hdr("Android shortcuts"));
                l.add(new Act("Android Settings", "Opens the TV's own settings", null, new Runnable() { public void run() { system(Settings.ACTION_SETTINGS); } }));
                l.add(new Act("Network settings", "Wi-Fi and Ethernet are managed by Android", null, new Runnable() { public void run() { system(Settings.ACTION_WIRELESS_SETTINGS); } }));
                l.add(new Act("Installed applications", "Uninstalling and permissions are managed by Android", null, new Runnable() { public void run() { system(Settings.ACTION_APPLICATION_SETTINGS); } }));
                break; }
            case 6: {
                l.add(new Ch("Text size", "", "text_size", 0, "Normal", "Large", "Extra large"));
                l.add(tog("High contrast", "Darker backgrounds and outlined tiles", "hi_contrast", false));
                l.add(tog("Stronger focus indicators", "Thicker highlight around the selected item", "strong_focus", false));
                l.add(tog("Reduce motion", "Removes scrolling and wiggle animations", "reduce_motion", false));
                l.add(tog("Larger controls", "Bigger rows in Settings", "large_ctrl", false));
                l.add(tog("UI sounds", "Click sounds when navigating (follows the TV's sound-effects setting)", "ui_sound", false));
                break; }
            default: {
                String ver = "?";
                try { PackageInfo pi = getPackageManager().getPackageInfo(getPackageName(), 0); ver = pi.versionName + " (" + pi.versionCode + ")"; } catch (Throwable t) { /* ignore */ }
                DisplayMetrics dm = getResources().getDisplayMetrics();
                l.add(new Info("Version", ver));
                l.add(new Info("Build", "Android " + Build.VERSION.RELEASE + " (API " + Build.VERSION.SDK_INT + "), " + Build.MANUFACTURER + " " + Build.MODEL));
                l.add(new Info("Display", dm.widthPixels + " x " + dm.heightPixels + " px, " + Math.round(dm.density * 160) + " dpi"));
                String home = "";
                try { home = getPackageManager().resolveActivity(new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME), 0).activityInfo.packageName; } catch (Throwable t) { /* ignore */ }
                l.add(new Info("Launcher", home.equals(getPackageName()) ? "EmberHome is the default home app" : "EmberHome is not the default home app"));
                l.add(new Act("Diagnostics", "Memory, network, weather and media status", null, new Runnable() { public void run() { dialog("Diagnostics", diagnostics()); } }));
                l.add(new Act("Licences and credits", "", null, new Runnable() { public void run() {
                    dialog("Licences and credits", "Weather data by Open-Meteo.com, licensed CC BY 4.0 (open-meteo.com/en/license). The free Open-Meteo API is for non-commercial use; "
                            + "a commercial release needs an Open-Meteo subscription.\n\nAndroid and the Android Open Source Project: Apache License 2.0.\n\n"
                            + "EmberHome includes no third-party libraries. Wallpapers, avatars and screensavers are original artwork drawn in code. "
                            + "Media you import stays yours; the Cinematic Library ships empty until licence-verified items are added."); } }));
                break; }
        }
        return l;
    }

    private String[] labels() {
        HomeStyle[] s = HomeStyle.values();
        String[] o = new String[s.length];
        for (int i = 0; i < s.length; i++) o[i] = s[i].label;
        return o;
    }
}
