package com.emberhome.launcher;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Shader;

/** 50 built-in profile pictures: 25 drawn symbols x 2 colour treatments. No image files needed. */
public final class Avatars {
    private Avatars() {}
    public static final int COUNT = 50;

    // c = disc, k = background-coloured disc, p = polygon, q = background polygon, l = background line, m = line   (24x24 grid)
    private static final String[] GLYPHS = {
            "p 12 2 15 9 22 9 16.5 14 18.5 21 12 17 5.5 21 7.5 14 2 9 9 9",
            "c 8 9 4.5;c 16 9 4.5;p 3.8 11.5 20.2 11.5 12 21",
            "c 12 12 8;k 16 9 7",
            "c 12 12 5;p 11 2 13 2 13 6 11 6;p 11 18 13 18 13 22 11 22;p 2 11 6 11 6 13 2 13;p 18 11 22 11 22 13 18 13;p 4.5 6 6 4.5 8.5 7 7 8.5;p 19.5 6 18 4.5 15.5 7 17 8.5;p 4.5 18 6 19.5 8.5 17 7 15.5;p 19.5 18 18 19.5 15.5 17 17 15.5",
            "p 13 2 5 13 11 13 9 22 19 10 12.5 10",
            "p 12 3 19 8 19 15 12 21 5 15 5 8;l 12 21 12 9 1.4",
            "p 12 2 16 8 19 13 17 19 12 22 7 19 5 13 8 9 9.5 12",
            "p 12 2 17.5 12 6.5 12;c 12 14.5 6",
            "p 12 2 21 10 12 22 3 10;l 3 10 21 10 1.2",
            "p 3 8 8 13 12 5 16 13 21 8 19 19 5 19",
            "p 2 20 9 7 13 14 16 10 22 20;c 17 6 2",
            "c 8 14 5;c 14 11 5;c 17 15 4;p 5 19 19 19 19 14 5 14",
            "p 4 3 10 8 14 8 20 3 21 13 12 21 3 13;k 8.5 12 1.3;k 15.5 12 1.3;q 11 15 13 15 12 16.5",
            "p 3 6 8 4 9 9 15 9 16 4 21 6 20 16 12 21 4 16;k 9 12 1.3;k 15 12 1.3",
            "c 5 6 3;c 19 6 3;c 12 13 8.5;k 9 11 1.2;k 15 11 1.2;q 10.5 15 13.5 15 12 17",
            "p 5 8 19 8 19 19 5 19;m 12 8 12 4 1.4;c 12 3.5 1.5;k 9.5 13 2;k 14.5 13 2;l 9 17 15 17 1.2",
            "c 12 10 7;p 5 10 19 10 19 21 16 18 14 21 12 18 10 21 8 18 5 21;k 9.5 10 1.3;k 14.5 10 1.3",
            "p 12 2 16 8 16 16 8 16 8 8;p 8 14 4 19 8 18;p 16 14 20 19 16 18;k 12 9 2;p 10 17 14 17 12 22",
            "c 12 12 6.5;l 2 15 22 9 2.2;m 2 15 22 9 0.9",
            "c 8 18 3.2;c 17 16 3.2;p 10.5 4 20 2 20 16 17.5 16 17.5 5.5 11 6.5 11 18 8.5 18",
            "p 3 9 21 9 22 17 17 17 14 14 10 14 7 17 2 17;k 7 12 1.2;k 17 12 1.2",
            "p 3 8 8 8 10 5 14 5 16 8 21 8 21 19 3 19;k 12 13.5 3.5;c 12 13.5 2.2",
            "p 5 8 17 8 16 19 6 19;c 19 12 3;k 19 12 1.6",
            "m 5 15 5 11 1.8;m 5 11 8 6 1.8;m 8 6 16 6 1.8;m 16 6 19 11 1.8;m 19 11 19 15 1.8;p 3 14 7 14 7 20 3 20;p 17 14 21 14 21 20 17 20",
            "c 12 15 4.5;c 6.5 10 2.2;c 10 6.5 2.2;c 14 6.5 2.2;c 17.5 10 2.2"};

    private static final String[][] PAL = {
            {"#7F5AF0", "#3B2A8C", "#FFFFFF"}, {"#F0873A", "#B03A2E", "#FFF3E0"}, {"#2A9D8F", "#115E59", "#E6FFFA"},
            {"#3B82F6", "#1E3A8A", "#EAF2FF"}, {"#EC4899", "#9D174D", "#FFE4F1"}, {"#EAB308", "#A16207", "#FFF8DB"},
            {"#22C55E", "#166534", "#E8FFEF"}, {"#64748B", "#1E293B", "#F1F5F9"}, {"#F43F5E", "#881337", "#FFE4E8"},
            {"#06B6D4", "#155E75", "#E0FAFF"}};

    public static void draw(Canvas c, int id, float cx, float cy, float r) {
        id = ((id % COUNT) + COUNT) % COUNT;
        int g = id % 25;
        String[] pal = PAL[(g * 3 + (id / 25) * 5) % 10];
        int top = Color.parseColor(pal[0]), bot = Color.parseColor(pal[1]), fg = Color.parseColor(pal[2]);
        int mid = Color.rgb((Color.red(top) + Color.red(bot)) / 2, (Color.green(top) + Color.green(bot)) / 2, (Color.blue(top) + Color.blue(bot)) / 2);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setShader(new LinearGradient(cx, cy - r, cx, cy + r, top, bot, Shader.TileMode.CLAMP));
        c.drawCircle(cx, cy, r, p);
        p.setShader(null);
        float s = (r * 2 * 0.56f) / 24f, ox = cx - 12 * s, oy = cy - 12 * s;
        p.setStrokeCap(Paint.Cap.ROUND);
        if (g == 2) {                       // moon: a true crescent (circle minus circle)
            Path a = new Path(), b = new Path();
            a.addCircle(cx, cy, 8 * s, Path.Direction.CW);
            b.addCircle(ox + 16 * s, oy + 9 * s, 7 * s, Path.Direction.CW);
            a.op(b, Path.Op.DIFFERENCE);
            p.setStyle(Paint.Style.FILL); p.setColor(fg);
            c.drawPath(a, p);
            return;
        }
        for (String shape : GLYPHS[g].split(";")) {
            String[] t = shape.trim().split(" ");
            char k = t[0].charAt(0);
            float[] v = new float[t.length - 1];
            for (int i = 1; i < t.length; i++) v[i - 1] = Float.parseFloat(t[i]);
            p.setStyle(Paint.Style.FILL);
            p.setColor(k == 'c' || k == 'p' || k == 'm' ? fg : mid);
            if (k == 'c' || k == 'k') c.drawCircle(ox + v[0] * s, oy + v[1] * s, v[2] * s, p);
            else if (k == 'p' || k == 'q') {
                Path path = new Path();
                for (int i = 0; i + 1 < v.length; i += 2) {
                    if (i == 0) path.moveTo(ox + v[i] * s, oy + v[i + 1] * s); else path.lineTo(ox + v[i] * s, oy + v[i + 1] * s);
                }
                path.close();
                c.drawPath(path, p);
            } else {            // l / m lines
                p.setStyle(Paint.Style.STROKE);
                p.setStrokeWidth(v[4] * s);
                c.drawLine(ox + v[0] * s, oy + v[1] * s, ox + v[2] * s, oy + v[3] * s, p);
            }
        }
    }
}
