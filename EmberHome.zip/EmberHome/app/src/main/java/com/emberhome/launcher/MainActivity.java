package com.emberhome.launcher;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.view.WindowManager;
import android.widget.Toast;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;

public class MainActivity extends Activity implements HomeView.Host {
    private static final String[] DATE_FORMATS = {"EEEE, d MMMM", "EEE, d MMM yyyy", "dd/MM/yyyy", "MM/dd/yyyy"};
    private HomeView hv;
    private IdleTimer idle;
    private final Handler handler = new Handler();
    private boolean pkgOn, netOn;

    private final Runnable tick = new Runnable() {
        @Override public void run() {
            updateClock();
            handler.postDelayed(this, Prefs.getb(MainActivity.this, "show_secs", false) ? 1000 : 20000);
        }
    };
    private final Runnable wxTick = new Runnable() {
        @Override public void run() {
            if (Prefs.getb(MainActivity.this, "show_weather", true) || Prefs.getb(MainActivity.this, "sv_owx", false))
                Weather.refresh(MainActivity.this, false, new Runnable() { public void run() { updateWeather(); } });
            handler.postDelayed(this, 10 * 60000L);      // cheap check; the real request only happens when the refresh interval is due
        }
    };
    private final BroadcastReceiver pkgs = new BroadcastReceiver() {
        @Override public void onReceive(Context c, Intent i) { AppRepo.invalidate(); reload(); }
    };
    private final BroadcastReceiver net = new BroadcastReceiver() {
        @Override public void onReceive(Context c, Intent i) { hv.setNet(Weather.netType(MainActivity.this)); }
    };

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
        hv = new HomeView(this);
        hv.setHost(this);
        setContentView(hv);
        idle = new IdleTimer(this);
    }

    @Override protected void onResume() {
        super.onResume();
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN
                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        IntentFilter f = new IntentFilter();
        f.addAction(Intent.ACTION_PACKAGE_ADDED);
        f.addAction(Intent.ACTION_PACKAGE_REMOVED);
        f.addAction(Intent.ACTION_PACKAGE_CHANGED);
        f.addDataScheme("package");
        registerReceiver(pkgs, f);
        pkgOn = true;
        registerReceiver(net, new IntentFilter("android.net.conn.CONNECTIVITY_CHANGE"));
        netOn = true;
        reload();
        handler.post(tick);
        handler.post(wxTick);
        idle.reset();
        hv.requestFocus();
    }

    @Override protected void onPause() {
        super.onPause();
        idle.stop();
        handler.removeCallbacks(tick);
        handler.removeCallbacks(wxTick);
        if (pkgOn) { unregisterReceiver(pkgs); pkgOn = false; }
        if (netOn) { unregisterReceiver(net); netOn = false; }
    }

    @Override protected void onNewIntent(Intent i) { super.onNewIntent(i); reload(); }

    @Override public void onUserInteraction() { idle.reset(); }

    private void reload() {
        Drawable w = Wallpapers.byKey(this, Prefs.wall(this));
        hv.setData(Prefs.style(this), new ArrayList<AppEntry>(AppRepo.visible(this)), w);
        hv.setGlassLayout(Prefs.glassLayout(this));
        List<AppEntry> all = AppRepo.visible(this), rec = new ArrayList<AppEntry>(), fav = new ArrayList<AppEntry>();
        for (String pk : Prefs.list(this, "recent")) for (AppEntry a : all) if (a.pkg.equals(pk)) rec.add(a);
        for (String pk : Prefs.list(this, "fav")) for (AppEntry a : all) if (a.pkg.equals(pk)) fav.add(a);
        hv.setRecents(rec, fav);
        String ap = Prefs.avatarPath(this);
        Bitmap photo = ap.length() > 0 ? Wallpapers.avatar(ap) : null;
        hv.setProfile(Prefs.profileName(this), photo, Prefs.avatarId(this));
        hv.setNet(Weather.netType(this));
        updateClock();
        updateWeather();
    }

    private void updateWeather() {
        Weather.Now n = Prefs.getb(this, "show_weather", true) ? Weather.cached(this) : null;
        if (n == null) hv.setWeather(-1, "", "");
        else hv.setWeather(Weather.kind(n.code, n.day), Weather.tempText(this, n), Weather.describe(n.code));
    }

    private void updateClock() {
        Date d = new Date();
        boolean h24 = Prefs.getb(this, "clock24", false), secs = Prefs.getb(this, "show_secs", false);
        Locale l = Locale.getDefault();
        String time = new SimpleDateFormat((h24 ? "HH:mm" : "h:mm") + (secs ? ":ss" : ""), l).format(d);
        String date = new SimpleDateFormat(DATE_FORMATS[Math.max(0, Math.min(3, Prefs.geti(this, "date_fmt", 0)))], l).format(d);
        if (Prefs.getb(this, "show_tz", false)) {
            TimeZone tz = TimeZone.getDefault();
            date += "  ·  " + tz.getDisplayName(tz.inDaylightTime(d), TimeZone.SHORT);
        }
        hv.setTime(time, date);
    }

    @Override public boolean canEdit() {
        if (Prefs.geti(this, "sort", 0) == 0) return true;
        Toast.makeText(this, "Set Applications > Sort order to Custom to rearrange apps", Toast.LENGTH_LONG).show();
        return false;
    }

    @Override public void launch(AppEntry a) {
        List<String> r = Prefs.list(this, "recent");
        r.remove(a.pkg); r.add(0, a.pkg);
        while (r.size() > 8) r.remove(r.size() - 1);
        Prefs.putList(this, "recent", r);
        try { startActivity(a.intent); }
        catch (Exception e) { Toast.makeText(this, "Can't open " + a.label, Toast.LENGTH_SHORT).show(); }
    }

    @Override public void action(int k) {
        if (k == 0) startActivity(new Intent(this, WallpaperActivity.class));
        else if (k == 1) startActivity(new Intent(this, AppsActivity.class));
        else if (k == 2) startActivity(new Intent(this, SettingsActivity.class));
        else if (k == 4) startActivity(new Intent(this, SearchActivity.class));
        else if (k == -3) startActivity(new Intent(this, ProfileActivity.class));
        else startActivity(new Intent(this, ScreensaverActivity.class));
    }

    @Override public void orderChanged(List<AppEntry> list) {
        List<String> o = new ArrayList<String>();
        for (AppEntry a : list) o.add(a.pkg);
        for (AppEntry a : AppRepo.all(this)) if (!o.contains(a.pkg)) o.add(a.pkg);
        Prefs.setOrder(this, o);
    }
}
