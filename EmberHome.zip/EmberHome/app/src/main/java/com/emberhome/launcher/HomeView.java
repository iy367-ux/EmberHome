package com.emberhome.launcher;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.os.SystemClock;
import android.view.KeyEvent;
import android.view.SoundEffectConstants;
import android.view.View;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.List;

/**
 * Draws the whole home screen on a 1280x720 virtual canvas (scaled to the real screen) and handles the remote control.
 * Styles: Ember Dock, Cinema Rail (VIDAA-style), Glass (tvOS-style), Google TV-style.
 */
public class HomeView extends View {
    public interface Host {
        void launch(AppEntry a);
        void action(int id);                  // 0 wallpapers, 1 manage apps, 2 settings, 3 screensaver, 4 search, -3 profile
        void orderChanged(List<AppEntry> l);
        boolean canEdit();
    }

    private static final int W = 1280, H = 720, WHITE = 0xFFFFFFFF;
    private static final String[] DKN = {"Wallpapers", "Manage apps", "Settings", "Screensaver", "Search"};
    private static final int[] ACC = {0xFFFFFFFF, 0xFFFFB36B, 0xFF6AA9FF, 0xFF4ADE80, 0xFFFF7AB6, 0xFFB794F6};
    private static final int[][] DIMS = {{0x30000000, 0x00000000, 0x60000000}, {0x66000000, 0x14000000, 0x99000000},
            {0x99000000, 0x44000000, 0xCC000000}, {0xCC000000, 0x88000000, 0xEE000000}};

    private Host host;
    private HomeStyle style = HomeStyle.EMBER;
    private List<AppEntry> apps = new ArrayList<AppEntry>(), recents = new ArrayList<AppEntry>(), favs = new ArrayList<AppEntry>();
    private Drawable wall, glassDefault;
    private int ti, di, ri, tab, glassLayout = 1, cinHero, pillPos, avatarId;
    private boolean dockFocus, heroFocus, recFocus, edit, moving;
    private final float[] sc = new float[3];
    private float railW = 60;
    private String time = "", date = "", profName = "", wxText = "", wxDesc = "";
    private int wxKind = -1, netType;
    private Bitmap avatar;
    private boolean showClock = true, showDate = true, showWeather = true, showNet = true, anim = true, hiContrast;
    private int accent = 0xFFFFFFFF, dim = 1, ringW = 4;
    private float ts = 1f, sz = 1f, gp = 1f;
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF rf = new RectF();

    public HomeView(Context c) {
        super(c);
        setFocusable(true);
        setFocusableInTouchMode(true);
    }

    // ------------------------------------------------------------ data
    public void setHost(Host h) { host = h; }
    public void setTime(String t, String d) { time = t; date = d; invalidate(); }
    public void setGlassLayout(int v) { glassLayout = v; invalidate(); }
    public void setWeather(int kind, String text, String desc) { wxKind = kind; wxText = text == null ? "" : text; wxDesc = desc == null ? "" : desc; invalidate(); }
    public void setNet(int type) { netType = type; invalidate(); }
    public void setProfile(String name, Bitmap pic, int id) { profName = name == null ? "" : name; avatar = pic; avatarId = id; invalidate(); }
    public void setRecents(List<AppEntry> r, List<AppEntry> f) { recents = r; favs = f; if (ri >= recents.size()) ri = 0; invalidate(); }

    public void setData(HomeStyle s, List<AppEntry> list, Drawable w) {
        loadPrefs();
        if (s != style) { dockFocus = false; heroFocus = false; recFocus = false; edit = false; tab = 0; di = 0; ti = 0; sc[0] = sc[1] = sc[2] = 0; }
        style = s; apps = list; wall = w;
        if (s == HomeStyle.GLASS && wall == null && glassDefault == null) glassDefault = Wallpapers.get(getContext(), 2, 0);
        if (ti >= apps.size()) ti = Math.max(0, apps.size() - 1);
        invalidate();
    }

    private void loadPrefs() {
        Context c = getContext();
        showClock = Prefs.getb(c, "show_clock", true);
        showDate = Prefs.getb(c, "show_date", true);
        showWeather = Prefs.getb(c, "show_weather", true);
        showNet = Prefs.getb(c, "show_net", true);
        anim = Prefs.getb(c, "anim", true) && !Prefs.getb(c, "reduce_motion", false);
        hiContrast = Prefs.getb(c, "hi_contrast", false);
        accent = ACC[Math.max(0, Math.min(ACC.length - 1, Prefs.geti(c, "accent", 0)))];
        dim = Math.max(0, Math.min(3, Prefs.geti(c, "dim", 1)));
        ringW = Prefs.getb(c, "strong_focus", false) ? 8 : hiContrast ? 6 : 4;
        ts = new float[]{1f, 1.15f, 1.3f}[Math.max(0, Math.min(2, Prefs.geti(c, "text_size", 0)))];
        sz = new float[]{0.9f, 1f, 1.15f}[Math.max(0, Math.min(2, Prefs.geti(c, "icon_size", 1)))];
        gp = new float[]{0.6f, 1f, 1.3f}[Math.max(0, Math.min(2, Prefs.geti(c, "density", 1)))];
        cinHero = Math.max(0, Math.min(2, Prefs.geti(c, "cin_hero", 0)));
        pillPos = Math.max(0, Math.min(2, Prefs.geti(c, "gp", 0)));
    }

    // ------------------------------------------------------------ drawing helpers
    private void txt(Canvas c, String s, float x, float y, float size, int color, boolean bold, Paint.Align al) {
        p.setShader(null); p.setStyle(Paint.Style.FILL); p.setTextSize(size * ts); p.setColor(color);
        p.setTypeface(bold ? Typeface.DEFAULT_BOLD : Typeface.DEFAULT); p.setTextAlign(al);
        c.drawText(s, x, y, p);
    }
    private void rr(Canvas c, float x, float y, float w, float h, float r, int color) {
        p.setShader(null); p.setStyle(Paint.Style.FILL); p.setColor(color);
        rf.set(x, y, x + w, y + h); c.drawRoundRect(rf, r, r, p);
    }
    private void ring(Canvas c, float x, float y, float w, float h, float r, float sw, int color) {
        p.setShader(null); p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(sw); p.setColor(color);
        rf.set(x, y, x + w, y + h); c.drawRoundRect(rf, r, r, p);
        p.setStyle(Paint.Style.FILL);
    }
    private void circle(Canvas c, float cx, float cy, float r, int fill) {
        p.setShader(null); p.setStyle(Paint.Style.FILL); p.setColor(fill); c.drawCircle(cx, cy, r, p);
    }
    private void circleRing(Canvas c, float cx, float cy, float r, float sw, int col) {
        p.setShader(null); p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(sw); p.setColor(col); c.drawCircle(cx, cy, r, p);
        p.setStyle(Paint.Style.FILL);
    }
    private float tw(String s, float size, boolean bold) {
        p.setTextSize(size * ts); p.setTypeface(bold ? Typeface.DEFAULT_BOLD : Typeface.DEFAULT);
        return p.measureText(s);
    }
    private String fit(String s, float maxW, float size) {
        p.setTextSize(size * ts); p.setTypeface(Typeface.DEFAULT_BOLD);
        if (p.measureText(s) <= maxW) return s;
        while (s.length() > 1 && p.measureText(s + "…") > maxW) s = s.substring(0, s.length() - 1);
        return s + "…";
    }
    private float ease(float cur, float tgt) {
        float d = tgt - cur;
        if (!anim || Math.abs(d) < 0.6f) return tgt;
        moving = true;
        return cur + d * 0.25f;
    }
    private AppEntry cur() { return apps.isEmpty() ? null : apps.get(Math.min(ti, apps.size() - 1)); }
    private boolean tilesFocus() { return !dockFocus && !heroFocus && !recFocus; }

    /** Draws a drawable centred at (cx,cy), scaled to fit inside bw x bh. */
    private void iconIn(Canvas c, Drawable d, float cx, float cy, float bw, float bh) {
        if (d == null) return;
        int iw = d.getIntrinsicWidth(), ih = d.getIntrinsicHeight();
        float ar = (iw > 0 && ih > 0) ? (float) iw / ih : 1f;
        float w = Math.min(bw, bh * ar), h = w / ar;
        d.setBounds((int) (cx - w / 2), (int) (cy - h / 2), (int) (cx + w / 2), (int) (cy + h / 2));
        d.draw(c);
    }

    private String greeting() {
        int h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY);
        String g = h < 12 ? "Good morning" : h < 18 ? "Good afternoon" : "Good evening";
        return profName.length() > 0 ? g + ", " + profName : g;
    }

    private String nameOf(int id) {
        if (id >= 0 && id < DKN.length) return DKN[id];
        if (id == -3) return "Profile";
        if (id == -10) return "Home";
        if (id == -11) return "Favourites";
        return "Apps";
    }

    /** Button ids: 0 wallpapers, 1 manage apps, 2 settings, 3 screensaver, 4 search, -3 profile, -10/-11/-12 Google TV tabs. */
    private int[] ids() {
        switch (style) {
            case GLASS: return new int[]{4, 2, -3};
            case GTV: return new int[]{-3, 4, -10, -11, -12, 3, 0, 2};
            case CINEMA: return new int[]{-3, 4, 0, 3, 1, 2};
            default: return new int[]{0, 1, 2, 3};
        }
    }

    private void dockIcon(Canvas c, int k, float cx, float cy, float s) {
        float a = s / 2;
        p.setShader(null); p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(Math.max(2f, s * 0.08f));
        p.setStrokeCap(Paint.Cap.ROUND); p.setColor(WHITE);
        if (k == 0) {
            rf.set(cx - a, cy - a * .75f, cx + a, cy + a * .75f); c.drawRoundRect(rf, 4, 4, p);
            c.drawCircle(cx - a * .4f, cy - a * .2f, a * .18f, p);
            Path m = new Path(); m.moveTo(cx - a, cy + a * .45f); m.lineTo(cx - a * .2f, cy - a * .05f);
            m.lineTo(cx + a * .2f, cy + a * .3f); m.lineTo(cx + a * .5f, cy + a * .1f); m.lineTo(cx + a, cy + a * .5f);
            c.drawPath(m, p);
        } else if (k == 1) {
            float q = a * .8f;
            for (int i = 0; i < 2; i++) for (int j = 0; j < 2; j++)
                c.drawRect(cx - q + i * q * 1.1f, cy - q + j * q * 1.1f, cx - q + i * q * 1.1f + q * .9f, cy - q + j * q * 1.1f + q * .9f, p);
        } else if (k == 2) {
            Path g = new Path();
            float outer = a * .98f, inner = a * .74f, half = (float) Math.PI / 8;
            for (int i = 0; i < 8; i++) {
                double a0 = i * Math.PI / 4;
                float[][] pts = {{(float) (a0 - half * .62), inner}, {(float) (a0 - half * .38), outer}, {(float) (a0 + half * .38), outer}, {(float) (a0 + half * .62), inner}};
                for (int j = 0; j < 4; j++) {
                    float px = cx + (float) Math.cos(pts[j][0]) * pts[j][1], py = cy + (float) Math.sin(pts[j][0]) * pts[j][1];
                    if (i == 0 && j == 0) g.moveTo(px, py); else g.lineTo(px, py);
                }
            }
            g.close();
            c.drawPath(g, p);
            c.drawCircle(cx, cy, a * .3f, p);
        } else if (k == 4) {
            c.drawCircle(cx - a * .15f, cy - a * .15f, a * .55f, p);
            c.drawLine(cx + a * .25f, cy + a * .25f, cx + a * .85f, cy + a * .85f, p);
        } else {
            Path A = new Path(), B = new Path();
            A.addCircle(cx, cy, a * .85f, Path.Direction.CW);
            B.addCircle(cx + a * .45f, cy - a * .3f, a * .75f, Path.Direction.CW);
            A.op(B, Path.Op.DIFFERENCE);
            p.setStyle(Paint.Style.FILL); c.drawPath(A, p);
        }
        p.setStyle(Paint.Style.FILL);
    }

    private void drawAvatar(Canvas c, float cx, float cy, float r) {
        if (avatar != null) {
            BitmapShader sh = new BitmapShader(avatar, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP);
            Matrix m = new Matrix();
            float k = 2 * r / avatar.getWidth();
            m.setScale(k, k); m.postTranslate(cx - r, cy - r);
            sh.setLocalMatrix(m);
            p.setStyle(Paint.Style.FILL); p.setShader(sh);
            c.drawCircle(cx, cy, r, p);
            p.setShader(null);
        } else Avatars.draw(c, avatarId, cx, cy, r);
    }

    /** Round dock button (Ember Dock). */
    private void circleBtn(Canvas c, int k, float cx, float cy, float r, boolean f) {
        c.save();
        if (f) c.scale(1.15f, 1.15f, cx, cy);
        circle(c, cx, cy, r, f ? 0x59FFFFFF : 0x33FFFFFF);
        if (f) circleRing(c, cx, cy, r, ringW - 1, accent);
        dockIcon(c, k, cx, cy, r * 0.95f);
        c.restore();
        if (f) {
            String s = nameOf(k);
            float t = tw(s, 15, true), by = cy - r - 52;
            rr(c, cx - t / 2 - 12, by, t + 24, 30, 10, 0xB3000000);
            txt(c, s, cx, by + 21, 15, WHITE, true, Paint.Align.CENTER);
        }
    }

    private void tile(Canvas c, AppEntry a, float x, float y, float w, float h, float r, boolean f, boolean glass, int mode) {
        float cx = x + w / 2, cy = y + h / 2, fs = (mode & 16) != 0 ? 1.22f : 1.12f;
        c.save();
        if (f) c.scale(fs, fs, cx, cy);
        if (f && edit && anim) c.rotate((float) Math.sin(SystemClock.uptimeMillis() / 60.0) * 2.5f, cx, cy);
        if (f) rr(c, x + 4, y + 14, w, h, r, 0x44000000);
        rr(c, x, y, w, h, r, glass ? 0x40FFFFFF : a.color);
        if (a.icon != null) {
            int iw = a.icon.getIntrinsicWidth(), ih = a.icon.getIntrinsicHeight();
            float ar = (iw > 0 && ih > 0) ? (float) iw / ih : 1f;
            if (ar > 1.4f) iconIn(c, a.icon, cx, cy, w * .94f, h * .92f);
            else iconIn(c, a.icon, cx, cy - ((mode & 4) != 0 ? 10 : 0), w * .62f, h * .62f);
        }
        if (f) ring(c, x, y, w, h, r, ringW, edit ? 0xFFFFB36B : accent);
        else if (hiContrast) ring(c, x, y, w, h, r, 2, 0xB3FFFFFF);
        if ((mode & 4) != 0) txt(c, fit(a.label, w - 24, 15), x + 12, y + h - 12, 15, WHITE, true, Paint.Align.LEFT);
        c.restore();
        if ((mode & 1) != 0 || ((mode & 2) != 0 && f))
            txt(c, fit(a.label, w + 40, 18), cx, y + h + (f ? 40 : 30), f ? 20 : 18, WHITE, true, Paint.Align.CENTER);
    }

    private void row(Canvas c, int from, int to, float w, float h, float gap, float x0, float y, int id, float r, boolean glass, int mode) {
        w *= sz; h *= sz; gap *= gp;
        int k = Math.max(1, (int) ((W - x0 - 24) / (w + gap)) - 1);
        int pos = (tilesFocus() && ti >= from && ti < to) ? ti - from : 0;
        sc[id] = ease(sc[id], Math.max(0, pos - k) * (w + gap));
        for (int pass = 0; pass < 2; pass++)
            for (int i = from; i < to; i++) {
                boolean f = tilesFocus() && i == ti;
                if ((pass == 1) != f) continue;
                float x = x0 + (i - from) * (w + gap) - sc[id];
                if (x > W + 40 || x + w < -40) continue;
                tile(c, apps.get(i), x, y, w, h, r, f, glass, mode);
            }
    }

    /** Landscape card (recently used). */
    private void card(Canvas c, AppEntry a, float x, float y, float w, float h, float r, boolean f, float icon, float lab) {
        float cx = x + w / 2, cy = y + h / 2;
        c.save();
        if (f) c.scale(1.07f, 1.07f, cx, cy);
        p.setStyle(Paint.Style.FILL);
        p.setShader(new LinearGradient(x, y, x + w, y + h, a.color, 0xFF101030, Shader.TileMode.CLAMP));
        rf.set(x, y, x + w, y + h); c.drawRoundRect(rf, r, r, p);
        p.setShader(null);
        iconIn(c, a.icon, x + 14 + icon / 2, y + 12 + icon / 2, icon, icon);
        txt(c, fit(a.label, w - 28, lab), x + 14, y + h - 12, lab, WHITE, true, Paint.Align.LEFT);
        if (f) ring(c, x, y, w, h, r, ringW, accent);
        c.restore();
    }

    private void cardRow(Canvas c, float x0, float y, float w, float h, float gap, float r, float icon, float lab) {
        int k = Math.max(1, (int) ((W - x0 - 24) / (w + gap)) - 1);
        sc[1] = ease(sc[1], Math.max(0, (recFocus ? ri : 0) - k) * (w + gap));
        for (int pass = 0; pass < 2; pass++)
            for (int i = 0; i < recents.size(); i++) {
                boolean f = recFocus && i == ri;
                if ((pass == 1) != f) continue;
                float x = x0 + i * (w + gap) - sc[1];
                if (x > W + 40 || x + w < -40) continue;
                card(c, recents.get(i), x, y, w, h, r, f, icon, lab);
            }
    }

    private void circleApp(Canvas c, AppEntry a, float cx, float cy, boolean f, boolean label) {
        c.save();
        if (f) c.scale(1.07f, 1.07f, cx, cy);
        if (f && edit && anim) c.rotate((float) Math.sin(SystemClock.uptimeMillis() / 60.0) * 2.5f, cx, cy);
        circle(c, cx, cy, 50, a.color);
        iconIn(c, a.icon, cx, cy, 52, 52);
        if (f) circleRing(c, cx, cy, 50, ringW, edit ? 0xFFFFB36B : accent);
        c.restore();
        if (label) txt(c, fit(a.label, 104, 16), cx, cy + 74, 16, 0xE6FFFFFF, false, Paint.Align.CENTER);
    }

    // ------------------------------------------------------------ status (network + weather)
    private void drawStatus(Canvas c, float x, float y, boolean right, float k) {
        boolean net = showNet && netType > 0, wx = showWeather && wxKind >= 0 && wxText.length() > 0;
        if (!net && !wx) return;
        float t = wx ? tw(wxText, 26 * k, true) : 0;
        float total = (net ? 40 * k : 0) + (wx ? 42 * k + t : 0);
        float cx = right ? x - total : x;
        if (net) { netIcon(c, netType, cx + 14 * k, y - 9 * k, 26 * k); cx += 40 * k; }
        if (wx) { weatherIcon(c, wxKind, cx + 15 * k, y - 9 * k, 30 * k); txt(c, wxText, cx + 42 * k, y, 26 * k, WHITE, true, Paint.Align.LEFT); }
    }

    private void netIcon(Canvas c, int type, float cx, float cy, float s) {
        p.setShader(null); p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(Math.max(1.6f, s * .09f)); p.setStrokeCap(Paint.Cap.ROUND); p.setColor(WHITE);
        if (type == 2) {
            rf.set(cx - s * .38f, cy - s * .3f, cx + s * .38f, cy + s * .22f); c.drawRoundRect(rf, 3, 3, p);
            for (int i = -1; i <= 1; i++) c.drawLine(cx + i * s * .2f, cy - s * .12f, cx + i * s * .2f, cy + s * .05f, p);
            c.drawLine(cx, cy + s * .22f, cx, cy + s * .4f, p);
        } else {
            float by = cy + s * .38f;
            for (int i = 1; i <= 3; i++) { float r = s * .2f * i; rf.set(cx - r, by - r, cx + r, by + r); c.drawArc(rf, 225, 90, false, p); }
            p.setStyle(Paint.Style.FILL); c.drawCircle(cx, by - 1, Math.max(1.6f, s * .08f), p);
        }
        p.setStyle(Paint.Style.FILL);
    }

    private void cloud(Canvas c, float cx, float cy, float s, int col) {
        p.setShader(null); p.setStyle(Paint.Style.FILL); p.setColor(col);
        c.drawCircle(cx - s * .18f, cy, s * .2f, p);
        c.drawCircle(cx + s * .08f, cy - s * .1f, s * .26f, p);
        c.drawCircle(cx + s * .3f, cy + s * .02f, s * .17f, p);
        rf.set(cx - s * .38f, cy, cx + s * .47f, cy + s * .2f); c.drawRoundRect(rf, s * .1f, s * .1f, p);
    }

    private void sunDisc(Canvas c, float cx, float cy, float s) {
        p.setShader(null); p.setColor(0xFFFFC857); p.setStyle(Paint.Style.FILL);
        c.drawCircle(cx, cy, s * .2f, p);
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(Math.max(1.6f, s * .07f)); p.setStrokeCap(Paint.Cap.ROUND);
        for (int i = 0; i < 8; i++) {
            double a = i * Math.PI / 4;
            c.drawLine(cx + (float) Math.cos(a) * s * .32f, cy + (float) Math.sin(a) * s * .32f, cx + (float) Math.cos(a) * s * .46f, cy + (float) Math.sin(a) * s * .46f, p);
        }
        p.setStyle(Paint.Style.FILL);
    }

    private void moon(Canvas c, float cx, float cy, float s) {
        Path A = new Path(), B = new Path();
        A.addCircle(cx, cy, s * .3f, Path.Direction.CW);
        B.addCircle(cx + s * .15f, cy - s * .1f, s * .26f, Path.Direction.CW);
        A.op(B, Path.Op.DIFFERENCE);
        p.setShader(null); p.setStyle(Paint.Style.FILL); p.setColor(0xFFE9E4D0);
        c.drawPath(A, p);
    }

    private void weatherIcon(Canvas c, int kind, float cx, float cy, float s) {
        switch (kind) {
            case Weather.SUN: sunDisc(c, cx, cy, s); break;
            case Weather.MOON: moon(c, cx, cy, s); break;
            case Weather.PARTLY: sunDisc(c, cx - s * .14f, cy - s * .14f, s * .8f); cloud(c, cx + s * .05f, cy + s * .12f, s * .9f, 0xFFE8EEF5); break;
            case Weather.PARTLY_NIGHT: moon(c, cx - s * .14f, cy - s * .14f, s * .8f); cloud(c, cx + s * .05f, cy + s * .12f, s * .9f, 0xFFE8EEF5); break;
            case Weather.RAIN:
                cloud(c, cx, cy - s * .12f, s * .95f, 0xFFD6DEE8);
                p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(Math.max(1.6f, s * .08f)); p.setColor(0xFF6AB0FF);
                for (int i = -1; i <= 1; i++) c.drawLine(cx + i * s * .2f, cy + s * .2f, cx + i * s * .2f - s * .06f, cy + s * .38f, p);
                p.setStyle(Paint.Style.FILL); break;
            case Weather.STORM: {
                cloud(c, cx, cy - s * .14f, s * .95f, 0xFFB8C2CF);
                Path b = new Path();
                b.moveTo(cx + s * .04f, cy + s * .05f); b.lineTo(cx - s * .1f, cy + s * .26f); b.lineTo(cx, cy + s * .26f);
                b.lineTo(cx - s * .06f, cy + s * .46f); b.lineTo(cx + s * .14f, cy + s * .2f); b.lineTo(cx + s * .04f, cy + s * .2f); b.close();
                p.setColor(0xFFFFD84D); c.drawPath(b, p); break; }
            case Weather.SNOW:
                cloud(c, cx, cy - s * .12f, s * .95f, 0xFFD6DEE8);
                p.setColor(WHITE);
                for (int i = -1; i <= 1; i++) c.drawCircle(cx + i * s * .2f, cy + s * .3f, Math.max(1.5f, s * .07f), p);
                break;
            case Weather.FOG:
                cloud(c, cx, cy - s * .14f, s * .95f, 0xFFB8C2CF);
                p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(Math.max(1.6f, s * .08f)); p.setColor(0xFFB8C2CF);
                c.drawLine(cx - s * .3f, cy + s * .22f, cx + s * .3f, cy + s * .22f, p);
                c.drawLine(cx - s * .2f, cy + s * .36f, cx + s * .4f, cy + s * .36f, p);
                p.setStyle(Paint.Style.FILL); break;
            default: cloud(c, cx, cy, s, 0xFFE8EEF5);
        }
    }

    // ------------------------------------------------------------ main draw
    @Override protected void onDraw(Canvas c) {
        moving = false;
        c.save();
        c.scale(getWidth() / (float) W, getHeight() / (float) H);
        drawBackground(c);
        if (apps.isEmpty()) txt(c, "No apps found", W / 2f, H / 2f, 36, WHITE, true, Paint.Align.CENTER);
        else switch (style) {
            case EMBER: drawEmber(c); break;
            case CINEMA: drawCinema(c); break;
            case GLASS: drawGlass(c); break;
            default: drawGtv(c); break;
        }
        c.restore();
        if (moving || (edit && anim)) postInvalidateOnAnimation();
    }

    private void drawBackground(Canvas c) {
        if (style == HomeStyle.CINEMA) { c.drawColor(0xFF08081C); return; }
        if (style == HomeStyle.GTV) { c.drawColor(0xFF0A0A1E); return; }
        Drawable w = style == HomeStyle.GLASS && wall == null ? glassDefault : wall;
        if (w != null) {
            w.setBounds(0, 0, W, H); w.draw(c);
            p.setShader(new LinearGradient(0, 0, 0, H, DIMS[hiContrast ? Math.max(dim, 2) : dim], null, Shader.TileMode.CLAMP));
            c.drawRect(0, 0, W, H, p); p.setShader(null);
        } else {
            p.setShader(new LinearGradient(0, 0, W * .35f, H, new int[]{0xFF1C1030, 0xFF7B2D3C, 0xFFF0873A}, new float[]{0, .55f, 1}, Shader.TileMode.CLAMP));
            c.drawRect(0, 0, W, H, p); p.setShader(null);
        }
    }

    // ---------------------------------------------------------------- Ember Dock
    private void drawEmber(Canvas c) {
        if (showClock) txt(c, time, 72, 120, 72, WHITE, true, Paint.Align.LEFT);
        if (showDate) txt(c, date + (profName.length() > 0 ? "  ·  " + greeting() : ""), 72, 156, 22, 0xD9FFFFFF, false, Paint.Align.LEFT);
        drawStatus(c, 1232, 62, true, 1f);
        if (!dockFocus) txt(c, fit(cur().label, 1100, 36), 72, 290, 36, WHITE, true, Paint.Align.LEFT);
        row(c, 0, apps.size(), 168, 168, 28, 72, 326, 0, 28, false, 0);
        float pw = 4 * 62 + 3 * 16 + 44, px = (W - pw) / 2, py = 600;
        rr(c, px, py, pw, 86, 43, 0x29FFFFFF);
        for (int i = 0; i < 4; i++) circleBtn(c, i, px + 22 + 31 + i * 78, py + 43, 31, dockFocus && di == i);
    }

    // ---------------------------------------------------------------- Cinema Rail (VIDAA-style)
    private void drawCinHero(Canvas c, AppEntry fa) {
        if (cinHero == 0) {
            p.setShader(new LinearGradient(0, 0, W, 0, new int[]{0xFF1B27D4, 0xFF2C3DF2, fa.color}, new float[]{0, .38f, 1}, Shader.TileMode.CLAMP));
            c.drawRect(0, 0, W, 354, p); p.setShader(null);
            if (fa.icon != null) { fa.icon.setAlpha(225); iconIn(c, fa.icon, W - 235, 165, 230, 230); fa.icon.setAlpha(255); }
            float fs = Math.max(46, 86 - Math.max(0, fa.label.length() - 6) * 7);
            txt(c, fit(fa.label, 760, fs), 118, 112 + fs * .82f, fs, WHITE, true, Paint.Align.LEFT);
            return;
        }
        if (cinHero == 1) {
            p.setShader(new LinearGradient(0, 0, W, 0, new int[]{0xFF1B27D4, 0xFF3A35D8, 0xFF5B2FB8}, new float[]{0, .55f, 1}, Shader.TileMode.CLAMP));
            c.drawRect(0, 0, W, 354, p); p.setShader(null);
        } else {
            Drawable w = wall != null ? wall : Wallpapers.get(getContext(), 2, 0);
            c.save(); c.clipRect(0, 0, W, 354);
            w.setBounds(0, -183, W, 537); w.draw(c);
            p.setShader(new LinearGradient(0, 0, W, 0, new int[]{0xB8080828, 0x1A080828}, new float[]{0, .65f}, Shader.TileMode.CLAMP));
            c.drawRect(0, 0, W, 354, p); p.setShader(null);
            c.restore();
        }
        txt(c, greeting(), 118, 76, 22, 0xE6FFFFFF, true, Paint.Align.LEFT);
        if (showClock) txt(c, time, 118, 164, 88, WHITE, true, Paint.Align.LEFT);
        if (showDate) txt(c, date, 118, 200, 22, 0xE6FFFFFF, false, Paint.Align.LEFT);
        if (showWeather && wxKind >= 0 && wxText.length() > 0) {
            float t1 = tw(wxText, 68, true), t2 = tw(wxDesc, 24, false), col = Math.max(t1, t2), x0 = 1150 - (110 + 22 + col);
            weatherIcon(c, wxKind, x0 + 55, 125, 110);
            txt(c, wxText, x0 + 132, 124, 68, WHITE, true, Paint.Align.LEFT);
            txt(c, wxDesc, x0 + 132, 158, 24, 0xE6FFFFFF, false, Paint.Align.LEFT);
        }
    }

    private void openPill(Canvas c, float x, float y, String label, boolean f, boolean outline) {
        float t = tw(label, outline ? 22 : 18, true), h = outline ? 46 : 40, w = (outline ? 14 + 26 + 10 : 16 + 20 + 8) + t + 24;
        if (f) { rr(c, x, y, w, h, h / 2, WHITE); }
        else if (outline) ring(c, x, y, w, h, h / 2, 2, 0xE6FFFFFF);
        else rr(c, x, y, w, h, h / 2, 0x47FFFFFF);
        if (f && !outline) ring(c, x, y, w, h, h / 2, ringW - 1, accent);
        int col = f ? 0xFF111111 : WHITE;
        float ix = x + (outline ? 14 + 13 : 16 + 10), iy = y + h / 2, r = outline ? 11 : 0;
        p.setShader(null); p.setColor(col);
        if (outline) { circleRing(c, ix, iy, r, 2, col); }
        Path tri = new Path();
        float s = outline ? 5 : 8;
        tri.moveTo(ix - s * .5f, iy - s); tri.lineTo(ix + s, iy); tri.lineTo(ix - s * .5f, iy + s); tri.close();
        p.setStyle(Paint.Style.FILL); c.drawPath(tri, p);
        txt(c, label, x + (outline ? 14 + 26 + 10 : 16 + 20 + 8), iy + (outline ? 8 : 6.5f), outline ? 22 : 18, col, true, Paint.Align.LEFT);
    }

    private void drawCinema(Canvas c) {
        AppEntry fa = cur();
        drawCinHero(c, fa);
        p.setShader(new LinearGradient(0, 232, 0, 366, 0x0008081C, 0xFF08081C, Shader.TileMode.CLAMP));
        c.drawRect(0, 232, W, 366, p); p.setShader(null);
        openPill(c, 118, cinHero == 0 ? 262 : 282, cinHero == 0 ? "Open" : "Open " + fa.label, heroFocus, true);
        if (cinHero == 0) {
            float tx = W - 40, tt = 0;
            if (showClock) { txt(c, time, tx, 60, 30, WHITE, true, Paint.Align.RIGHT); tt = tw(time, 30, true) + 22; }
            drawStatus(c, tx - tt, 60, true, 1f);
        }
        c.save();
        c.clipRect(60, 0, W, H);
        row(c, 0, apps.size(), 90, 90, 10, 71, 344, 0, 10, false, 0);
        if (!recents.isEmpty()) {
            txt(c, "Recently used", 71, 480, 24, WHITE, true, Paint.Align.LEFT);
            cardRow(c, 71, 504, 280, 160, 15, 12, 64, 24);
        }
        c.restore();
        railW = ease(railW, dockFocus ? 300 : 60);
        boolean open = railW > 150;
        if (open) {
            p.setColor(0x8C08081C); c.drawRect(0, 0, W, H, p);
            p.setShader(new LinearGradient(0, 0, railW, 0, new int[]{0xF7060618, 0xF7060618, 0x00060618}, new float[]{0, .82f, 1}, Shader.TileMode.CLAMP));
            c.drawRect(0, 0, railW, H, p); p.setShader(null);
        }
        int[] ids = ids();
        float[] ys = {191, 258, 327, 396, 462, 533};
        for (int i = 0; i < ids.length; i++) {
            boolean f = open && dockFocus && di == i;
            float cx = open ? 40 : 30;
            if (f) { rr(c, 10, ys[i] - 28, 270, 56, 30, 0x33FFFFFF); ring(c, 10, ys[i] - 28, 270, 56, 30, ringW - 1, accent); }
            if (ids[i] == -3) drawAvatar(c, cx, ys[i], 17); else dockIcon(c, ids[i], cx, ys[i], 30);
            if (open) txt(c, nameOf(ids[i]), 70, ys[i] + 8, 24, WHITE, true, Paint.Align.LEFT);
        }
    }

    // ---------------------------------------------------------------- Glass (tvOS-style)
    private void drawGlass(Canvas c) {
        int[] ids = ids();
        boolean net = showNet && netType > 0, wx = showWeather && wxKind >= 0 && wxText.length() > 0;
        float t = showClock ? tw(time, 19, true) : 0, wt = wx ? tw(wxText, 19, true) : 0;
        float w = 20 + (net ? 32 : 0) + (wx ? 30 + wt + 12 : 0) + (showClock ? t + 14 : 0) + 34 + 12 + 34 + 12 + 32 + 9;
        float x = pillPos == 0 ? W - 28 - w : pillPos == 1 ? (W - w) / 2 : 44;
        rr(c, x, 30, w, 43, 22, 0x8C424248);
        float cx = x + 20, by = 59;
        if (net) { netIcon(c, netType, cx + 11, 51.5f, 22); cx += 32; }
        if (wx) { weatherIcon(c, wxKind, cx + 11, 51.5f, 24); txt(c, wxText, cx + 30, by, 19, WHITE, true, Paint.Align.LEFT); cx += 30 + wt + 12; }
        if (showClock) { txt(c, time, cx, by, 19, WHITE, true, Paint.Align.LEFT); cx += t + 14; }
        float[] ix = {cx + 17, cx + 17 + 46, cx + 17 + 92};
        for (int i = 0; i < 3; i++) {
            if (dockFocus && di == i) circleRing(c, ix[i], 51.5f, 21, ringW - 1, accent);
            if (i < 2) dockIcon(c, ids[i], ix[i], 51.5f, 22); else drawAvatar(c, ix[i], 51.5f, 16);
        }
        int n = apps.size();
        boolean shelf = glassLayout == 1;
        int nd = shelf ? Math.min(6, n) : n;
        boolean inShelf = shelf && tilesFocus() && ti >= 6 && n > 6;
        sc[2] = ease(sc[2], inShelf ? 380 + Math.max(0, (ti - 6) / 6 - 1) * 160 : 0);
        float off = sc[2], dy = 523 - off;
        rr(c, 21, dy, 1228, 160, 49, 0x85707076);
        ring(c, 21, dy, 1228, 160, 49, 1.5f, 0x24FFFFFF);
        if (!shelf) sc[0] = ease(sc[0], Math.max(0, (tilesFocus() ? ti : 0) - 5) * 198);
        c.save();
        if (!shelf) c.clipRect(27, 0, 1243, H);
        for (int pass = 0; pass < 2; pass++)
            for (int i = 0; i < nd; i++) {
                boolean f = tilesFocus() && i == ti;
                if ((pass == 1) != f) continue;
                float ax = 51 + i * 198 - (shelf ? 0 : sc[0]);
                if (ax > 1249 || ax + 166 < 21) continue;
                tile(c, apps.get(i), ax, 551 - off, 166, 101, 22, f, false, 16);
            }
        c.restore();
        if (shelf && n > 6)
            for (int pass = 0; pass < 2; pass++)
                for (int i = 6; i < n; i++) {
                    boolean f = tilesFocus() && i == ti;
                    if ((pass == 1) != f) continue;
                    float ax = 51 + ((i - 6) % 6) * 198, ay = 706 + ((i - 6) / 6) * 160 - off;
                    if (ay > H + 20 || ay + 101 < -40) continue;
                    tile(c, apps.get(i), ax, ay, 166, 101, 22, f, false, 18);
                }
    }

    // ---------------------------------------------------------------- Google TV-style
    private void drawGtv(Canvas c) {
        AppEntry fa = cur();
        List<AppEntry> list = tab == 1 ? favs : apps;
        int tint = fa.color & 0xFFFFFF;
        p.setShader(new LinearGradient(0, 0, W, H * .6f, new int[]{0xFF1A1148, 0xFF2A1A68, 0xFF3B2380}, new float[]{0, .55f, 1}, Shader.TileMode.CLAMP));
        c.drawRect(0, 0, W, H, p);
        p.setShader(new RadialGradient(W * .78f, H * .24f, 520, tint | 0xCC000000, tint, Shader.TileMode.CLAMP));
        c.drawRect(0, 0, W, H, p);
        p.setShader(new LinearGradient(0, 0, 0, H, new int[]{0x000A0A1E, 0x000A0A1E, 0xFF0A0A1E}, new float[]{0, .36f, .8f}, Shader.TileMode.CLAMP));
        c.drawRect(0, 0, W, H, p); p.setShader(null);
        if (tab == 0 && fa.icon != null) { fa.icon.setAlpha(77); iconIn(c, fa.icon, W - 290, 210, 280, 280); fa.icon.setAlpha(255); }
        // top bar
        int[] ids = ids();
        if (dockFocus && di == 0) circleRing(c, 104, 57, 29, ringW - 1, accent);
        drawAvatar(c, 104, 57, 26);
        float[] tabW = {tw("Home", 22, true) + 44, tw("Favourites", 22, true) + 44, tw("Apps", 22, true) + 44};
        float px = 142, pw = 10 + 44 + 4 + tabW[0] + tabW[1] + tabW[2] + 8 + 8;
        rr(c, px, 29, pw, 56, 28, 0x8C121030);
        float sx = px + 10;
        if (dockFocus && di == 1) circleRing(c, sx + 22, 57, 24, ringW - 1, accent);
        dockIcon(c, 4, sx + 22, 57, 26);
        float tx = sx + 48;
        for (int i = 0; i < 3; i++) {
            boolean act = tab == i, f = dockFocus && di == 2 + i;
            if (act) rr(c, tx, 34, tabW[i], 46, 23, WHITE);
            if (f) ring(c, tx, 34, tabW[i], 46, 23, ringW - 1, accent);
            txt(c, nameOf(ids[2 + i]), tx + tabW[i] / 2, 64, 22, act ? 0xFF14142B : WHITE, true, Paint.Align.CENTER);
            tx += tabW[i] + 4;
        }
        float qx = px + pw + 16;
        rr(c, qx, 29, 10 + 44 * 3 + 8 + 8, 56, 28, 0x8C121030);
        for (int i = 0; i < 3; i++) {
            float cx = qx + 10 + 22 + i * 48;
            if (dockFocus && di == 5 + i) circleRing(c, cx, 57, 24, ringW - 1, accent);
            dockIcon(c, ids[5 + i], cx, 57, 24);
        }
        float rx = W - 75;
        txt(c, "EmberHome", rx, 63, 19, 0xD9FFFFFF, false, Paint.Align.RIGHT);
        float bw = tw("EmberHome", 19, false);
        p.setColor(0x66FFFFFF); c.drawRect(rx - bw - 14, 45, rx - bw - 13, 69, p);
        float cxr = rx - bw - 28;
        if (showClock) { txt(c, time, cxr, 64, 22, WHITE, true, Paint.Align.RIGHT); cxr -= tw(time, 22, true) + 22; }
        drawStatus(c, cxr, 64, true, 0.85f);
        if (tab != 0) {
            txt(c, tab == 1 ? "Favourites" : "Apps", 78, 160, 34, WHITE, true, Paint.Align.LEFT);
            if (list.isEmpty()) { txt(c, "No favourites yet. In Settings > Applications > Manage apps, press OK until an app shows Favourite.", 78, 240, 20, 0xBFFFFFFF, false, Paint.Align.LEFT); return; }
            sc[2] = ease(sc[2], Math.max(0, ti / 9 - 1) * 158);
            c.save(); c.clipRect(0, 186, W, H);
            for (int pass = 0; pass < 2; pass++)
                for (int i = 0; i < list.size(); i++) {
                    boolean f = tilesFocus() && i == ti;
                    if ((pass == 1) != f) continue;
                    float ax = 71 + 50 + (i % 9) * 128, ay = 206 + 50 + (i / 9) * 158 - sc[2];
                    if (ay > H + 60 || ay < 150) continue;
                    circleApp(c, list.get(i), ax, ay, f, true);
                }
            c.restore();
            return;
        }
        // hero
        txt(c, fit(fa.label, 900, 54), 78, 240 + 44, 54, WHITE, true, Paint.Align.LEFT);
        openPill(c, 78, 322, "Open", heroFocus, false);
        for (int i = 0; i < 5; i++) { p.setColor(i == ti % 5 ? WHITE : 0x59FFFFFF); c.drawCircle(W - 90 - (4 - i) * 16, 343, 3.5f, p); }
        if (!recents.isEmpty()) {
            txt(c, "Recently used", 69, 405, 19, 0xEBFFFFFF, false, Paint.Align.LEFT);
            cardRow(c, 73, 426, 205, 115, 27, 10, 40, 17);
        }
        txt(c, "Your apps", 69, 584, 19, 0xEBFFFFFF, false, Paint.Align.LEFT);
        int k = Math.max(1, (int) ((W - 71) / 128f) - 1);
        sc[0] = ease(sc[0], Math.max(0, (tilesFocus() ? ti : 0) - k) * 128);
        c.save(); c.clipRect(0, 592, W, H);
        for (int pass = 0; pass < 2; pass++)
            for (int i = 0; i < apps.size(); i++) {
                boolean f = tilesFocus() && i == ti;
                if ((pass == 1) != f) continue;
                float ax = 71 + 50 + i * 128 - sc[0];
                if (ax > W + 60 || ax < -60) continue;
                circleApp(c, apps.get(i), ax, 658, f, false);
            }
        c.restore();
    }

    // ------------------------------------------------------------ remote control
    @Override public boolean onKeyDown(int code, KeyEvent e) {
        switch (code) {
            case KeyEvent.KEYCODE_DPAD_LEFT: dir(0); return true;
            case KeyEvent.KEYCODE_DPAD_RIGHT: dir(1); return true;
            case KeyEvent.KEYCODE_DPAD_UP: dir(2); return true;
            case KeyEvent.KEYCODE_DPAD_DOWN: dir(3); return true;
            case KeyEvent.KEYCODE_DPAD_CENTER:
            case KeyEvent.KEYCODE_ENTER:
            case KeyEvent.KEYCODE_NUMPAD_ENTER:
                e.startTracking(); return true;
            case KeyEvent.KEYCODE_BACK:
                if (edit) { edit = false; if (host != null) host.orderChanged(apps); }
                else if (style == HomeStyle.GTV && tab > 0) { tab = 0; ti = 0; dockFocus = false; heroFocus = true; }
                invalidate();
                return true;
        }
        return super.onKeyDown(code, e);
    }

    @Override public boolean onKeyUp(int code, KeyEvent e) {
        if (code == KeyEvent.KEYCODE_DPAD_CENTER || code == KeyEvent.KEYCODE_ENTER || code == KeyEvent.KEYCODE_NUMPAD_ENTER) {
            if (e.isTracking() && !e.isCanceled()) ok();
            return true;
        }
        return super.onKeyUp(code, e);
    }

    @Override public boolean onKeyLongPress(int code, KeyEvent e) {
        if (code == KeyEvent.KEYCODE_DPAD_CENTER || code == KeyEvent.KEYCODE_ENTER || code == KeyEvent.KEYCODE_NUMPAD_ENTER) {
            if (tilesFocus() && !apps.isEmpty() && !edit && (host == null || host.canEdit()) && !(style == HomeStyle.GTV && tab == 1)) { edit = true; invalidate(); }
            return true;
        }
        return super.onKeyLongPress(code, e);
    }

    private void act(int id) {
        if (style == HomeStyle.GTV && id <= -10) {
            tab = -10 - id; dockFocus = false; ti = 0; sc[2] = 0;
            if (tab == 0) heroFocus = true;
            return;
        }
        if (host != null) host.action(id);
    }

    private void ok() {
        if (Prefs.getb(getContext(), "ui_sound", false)) playSoundEffect(SoundEffectConstants.CLICK);
        if (edit) { edit = false; if (host != null) host.orderChanged(apps); }
        else if (dockFocus) act(ids()[di]);
        else if (host != null) {
            if (recFocus) { if (ri < recents.size()) host.launch(recents.get(ri)); }
            else if (heroFocus) { AppEntry a = cur(); if (a != null) host.launch(a); }
            else {
                List<AppEntry> l = style == HomeStyle.GTV && tab == 1 ? favs : apps;
                if (ti < l.size()) host.launch(l.get(ti));
            }
        }
        invalidate();
    }

    private void move(int d) {
        int j = ti + d;
        if (j < 0 || j >= apps.size()) return;
        Collections.swap(apps, ti, j);
        ti = j;
        if (host != null) host.orderChanged(apps);
    }

    private static int shelfRow(int i) { return i < 6 ? -1 : (i - 6) / 6; }

    private void clear() { dockFocus = false; heroFocus = false; recFocus = false; }

    private void dir(int d) {            // 0 left, 1 right, 2 up, 3 down
        if (Prefs.getb(getContext(), "ui_sound", false)) playSoundEffect(SoundEffectConstants.NAVIGATION_RIGHT);
        int n = apps.size(), nd = ids().length, R = recents.size();
        boolean gl = style == HomeStyle.GLASS, cin = style == HomeStyle.CINEMA, tv = style == HomeStyle.GTV, em = style == HomeStyle.EMBER;
        if (em) {
            if (tilesFocus()) {
                if (n == 0) return;
                if (d == 0) { if (edit) move(-1); else if (ti > 0) ti--; }
                else if (d == 1) { if (edit) move(1); else ti = Math.min(n - 1, ti + 1); }
                else if (d == 3 && !edit) dockFocus = true;
            } else {
                if (d == 0) di = Math.max(0, di - 1);
                if (d == 1) di = Math.min(nd - 1, di + 1);
                if (d == 2) dockFocus = false;
            }
        } else if (cin) {
            if (dockFocus) {
                if (d == 2) di = Math.max(0, di - 1);
                if (d == 3) di = Math.min(nd - 1, di + 1);
                if (d == 1) clear();
            } else if (heroFocus) {
                if (d == 3) clear();
                if (d == 0) { clear(); dockFocus = true; }
            } else if (recFocus) {
                if (d == 0) { if (ri > 0) ri--; else { clear(); dockFocus = true; } }
                if (d == 1) ri = Math.min(R - 1, ri + 1);
                if (d == 2) clear();
            } else {
                if (n == 0) return;
                if (d == 0) { if (edit) move(-1); else if (ti > 0) ti--; else { clear(); dockFocus = true; } }
                else if (d == 1) { if (edit) move(1); else ti = Math.min(n - 1, ti + 1); }
                else if (d == 2 && !edit) { clear(); heroFocus = true; }
                else if (d == 3 && !edit && R > 0) { clear(); recFocus = true; ri = Math.min(ri, R - 1); }
            }
        } else if (gl) {
            boolean sh = glassLayout == 1;
            if (!dockFocus) {
                if (n == 0) return;
                if (d == 0) { if (edit) move(-1); else if (ti > 0 && !(sh && ti % 6 == 0)) ti--; }
                else if (d == 1) { if (edit) move(1); else ti = Math.min(sh && ti < 6 ? Math.min(5, n - 1) : n - 1, ti + 1); }
                else if (d == 3 && !edit) {
                    if (sh && n > 6) { int nx = ti + 6; if (nx <= n - 1) ti = nx; else if (shelfRow(n - 1) > shelfRow(ti)) ti = n - 1; }
                } else if (d == 2 && !edit) { if (sh && ti >= 6) ti -= 6; else dockFocus = true; }
            } else {
                if (d == 0) di = Math.max(0, di - 1);
                if (d == 1) di = Math.min(nd - 1, di + 1);
                if (d == 3) { dockFocus = false; ti = Math.min(ti, sh ? Math.min(5, n - 1) : n - 1); }
            }
        } else {
            int gn = tab == 1 ? favs.size() : n;
            if (tab == 0) {
                if (dockFocus) {
                    if (d == 0) di = Math.max(0, di - 1);
                    if (d == 1) di = Math.min(nd - 1, di + 1);
                    if (d == 3) { clear(); heroFocus = true; }
                } else if (heroFocus) {
                    if (d == 2) { clear(); dockFocus = true; }
                    if (d == 3) { clear(); if (R > 0) { recFocus = true; ri = Math.min(ri, R - 1); } }
                } else if (recFocus) {
                    if (d == 0) ri = Math.max(0, ri - 1);
                    if (d == 1) ri = Math.min(R - 1, ri + 1);
                    if (d == 2) { clear(); heroFocus = true; }
                    if (d == 3) clear();
                } else {
                    if (n == 0) return;
                    if (d == 0) { if (edit) move(-1); else ti = Math.max(0, ti - 1); }
                    else if (d == 1) { if (edit) move(1); else ti = Math.min(n - 1, ti + 1); }
                    else if (d == 2 && !edit) { clear(); if (R > 0) recFocus = true; else heroFocus = true; }
                }
            } else {
                if (dockFocus) {
                    if (d == 0) di = Math.max(0, di - 1);
                    if (d == 1) di = Math.min(nd - 1, di + 1);
                    if (d == 3 && gn > 0) { clear(); ti = 0; }
                } else {
                    if (d == 0) ti = Math.max(0, ti - 1);
                    if (d == 1) ti = Math.min(gn - 1, ti + 1);
                    if (d == 3) ti = Math.min(gn - 1, ti + 9);
                    if (d == 2) { if (ti >= 9) ti -= 9; else { clear(); dockFocus = true; } }
                }
            }
        }
        invalidate();
    }
}
