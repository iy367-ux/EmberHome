# EmberHome v3.0.0 (final API 19 release)

Android TV launcher for **Android 4.4.4 (API 19) and newer**. `minSdk 19`, no third-party libraries, no Android Studio needed.
Build target is unchanged: Gradle project, `compileSdk 33`, `targetSdk 28`, built by GitHub Actions.

## Build the APK on GitHub
1. Create a repository and upload everything in this folder (keep `.github` and `app`).
2. Actions tab -> "Build EmberHome APK" -> wait for the green tick (or Run workflow).
3. Download artifact `EmberHome-debug-apk`, install `app-debug.apk` on the TV, press Home and pick EmberHome.
If the build fails, send me the first error lines.

## What is in this release
- **Four home styles** (Ember Dock, Cinema Rail, Glass/tvOS, Google TV), 50 built-in profile pictures, profile name.
- **Settings**: two columns (categories 34% / settings 66%), 8 categories, every row is a real preference: Appearance,
  Screensaver, Weather, Clock & Date, Home Screen, Applications, Accessibility, About.
- **Compact weather** in the status area (icon + temperature, plus Wi-Fi/Ethernet icon) from Open-Meteo, cached, offline-safe.
- **Screensaver Gallery**: 7 native clocks, 5 ambient scenes, Cinematic Library (empty, licence-tracked), My Screensavers (photos and videos).

## Weather and licensing
Weather data by Open-Meteo.com (CC BY 4.0). Open-Meteo's free API is for **non-commercial use only**; a commercial or public release
needs an Open-Meteo subscription (https://open-meteo.com/en/pricing). Attribution is shown in Settings > Weather and About.

## Media and licensing
No photographs or videos are bundled. The Cinematic Library reads `app/src/main/assets/cinematic_catalog.json`, which ships empty.
An entry is only shown if it has creator, licence, source and at least one download URL. Only add media you have verified for
redistribution and commercial use (see docs/MEDIA_LICENCES.md). Do not scrape sites; do not use Pexels or Pixabay as a wallpaper/screensaver source
unless their terms explicitly permit it.

## Your own pictures and videos
- Settings > Screensaver > My Screensavers, or Screensaver Gallery > My Screensavers.
- "Import" uses Android's document picker when the TV has one (read access is kept). Many TVs do not: copy files to
  `Pictures/EmberHome` or `Movies/EmberHome` on the TV and choose "Scan folders".
- Wallpapers and profile photos use `Pictures/EmberHome` too.
- Photos can be replaced by real wallpapers: put `wp_sunsets_1.jpg`..`4`, `wp_nature_1..4`, `wp_cities_1..4` in `app/src/main/res/drawable-nodpi/`.

## Known limitations (read these)
See CHANGELOG.md and TESTING.md. In short: not yet built or run on a device by the author; HTTPS on Android 4.4 may fail for weather
on some TVs (old certificate store); photo EXIF rotation is not applied; no automatic location without a last-known fix.
