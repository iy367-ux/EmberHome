package com.emberhome.launcher;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.Drawable;
import android.os.Environment;
import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Wallpaper catalogue. Categories 1-3 use REAL PHOTOS when you add files named
 * wp_sunsets_1.jpg ... wp_sunsets_4.jpg, wp_nature_1..4, wp_cities_1..4 to app/src/main/res/drawable-nodpi/.
 * Without a photo, a code-drawn scene is used. "My Wallpapers" reads pictures from Pictures/EmberHome on the device.
 */
public final class Wallpapers {
    private Wallpapers() {}
    public static final String[] CATS = {"Gradients", "Sunsets", "Nature", "Cities", "Plain colours", "My Wallpapers"};
    private static final String[] PHOTO = {"", "sunsets", "nature", "cities"};

    private static final int[][] G = {
            {0xFF1C1030, 0xFF7B2D3C, 0xFFF0873A}, {0xFF06303A, 0xFF0E6B73, 0xFF7FD6C2}, {0xFF141E30, 0xFF243B55, 0xFF6A82FB},
            {0xFF42275A, 0xFF734B6D, 0xFFE6A4B4}, {0xFF0F2027, 0xFF203A43, 0xFF2C5364}, {0xFF232526, 0xFF414345, 0xFF8E8E8E}};
    private static final int[] PLAIN = {0xFF111827, 0xFF1F2937, 0xFF7C2D12, 0xFF064E3B, 0xFF1E3A8A, 0xFF3B0764};

    private static SceneDrawable scene(int cat, int i) {
        i = i % 4;
        if (cat == 1) switch (i) {
            case 0: return new SceneDrawable(3, 470, "#2b1055", "#d1456b", "#ffb36b").sun(640, 470, 62, "#ffd9a0").clouds(5, "#ffd0b0")
                    .water("#a3416a", "#1a0f2a").birds().hills("#1a0f2a", 470, 26, 110, 0, false, null, 476);
            case 1: return new SceneDrawable(5, 520, "#0b1d3a", "#4a6fa5", "#f6c177").stars(60).sun(300, 520, 46, "#ffe2a8").clouds(3, "#ffffff")
                    .hills("#3a2a4a", 520, 60, 160, 0, false, null, 0).hills("#1d1428", 600, 70, 200, 0, false, null, 0).hills("#0e0a14", 670, 50, 240, 0, false, null, 0);
            case 2: return new SceneDrawable(8, 520, "#3a0f3f", "#e0524d", "#ffd27a").sun(820, 470, 80, "#ffe7a0").clouds(4, "#ffd0b0")
                    .hills("#4a1a3a", 500, 150, 90, 0, false, null, 0).hills("#2a0e26", 580, 120, 80, 30, false, null, 0);
            default: return new SceneDrawable(11, 500, "#12263a", "#6b5b95", "#f4a6a0").sun(900, 500, 42, "#ffd9c0").clouds(6, "#ffd0d8").birds()
                    .water("#7a5c8f", "#12263a").hills("#14202e", 495, 40, 130, 0, false, null, 502).hills("#0a1118", 700, 30, 160, 0, false, null, 0);
        }
        if (cat == 2) switch (i) {
            case 0: return new SceneDrawable(2, 430, "#7ec8e3", "#cfeaf2").clouds(5, "#ffffff").water("#8fc3d6", "#2c5364")
                    .hills("#9fb4c7", 340, 150, 100, 0, true, null, 432).hills("#4f6d73", 400, 80, 80, 26, false, null, 440).hills("#1f3b3a", 690, 60, 60, 24, false, null, 0);
            case 1: return new SceneDrawable(4, 480, "#0b1d3a", "#3d5a80", "#98c1d9").clouds(3, "#ffffff")
                    .hills("#5a6b8c", 360, 110, 70, 20, false, "#cfe3f0", 0).hills("#3a4a68", 470, 90, 60, 20, false, "#a8c4d8", 0)
                    .hills("#2b3350", 580, 70, 50, 18, false, "#7f9ab5", 0).hills("#171c33", 690, 50, 44, 16, false, null, 0);
            case 2: return new SceneDrawable(6, 420, "#aedcc0", "#f7f3d7").sun(980, 210, 44, "#fff3b0").clouds(6, "#ffffff")
                    .hills("#7fb08a", 430, 70, 140, 0, false, null, 0).hills("#5f9b6f", 520, 60, 120, 0, false, null, 0)
                    .hills("#3f7c55", 620, 50, 100, 50, false, null, 0).hills("#2c5c3f", 700, 30, 90, 0, false, null, 0);
            default: return new SceneDrawable(9, 470, "#050a18", "#0f2b3d", "#1b3a4a").stars(140).aurora().moon(1020, 130, 22)
                    .hills("#c9d8e6", 400, 110, 100, 0, true, null, 0).hills("#0a1626", 560, 90, 60, 22, false, null, 0).hills("#050b14", 690, 60, 50, 20, false, null, 0);
        }
        switch (i) {
            case 0: return new SceneDrawable(4, 520, "#0b1026", "#1d2b64", "#f8a07a").stars(40).moon(200, 140, 26)
                    .city("#26305a", 560, 90, 260, null, 0).city("#131a38", 620, 60, 200, "#ffd98a", 0).city("#0a0e22", 700, 40, 130, "#ffd98a", 0);
            case 1: return new SceneDrawable(7, 520, "#050510", "#1b1b3f", "#6a3d8f").stars(90).moon(1000, 120, 30)
                    .city("#251c4a", 540, 120, 300, "#ff5fd2", 0).city("#150f2e", 620, 80, 240, "#4df3ff", 0).city("#0a0716", 710, 50, 150, "#ffd98a", 0);
            case 2: return new SceneDrawable(10, 560, "#0a1a2a", "#2c5364", "#9fd3c7").water("#2c5364", "#08141f")
                    .city("#1f3b4d", 560, 80, 240, "#ffe9a8", 560).city("#0e2230", 560, 40, 140, null, 560);
            default: return new SceneDrawable(13, 560, "#14080c", "#5a2a3a", "#ffb36b").sun(760, 520, 70, "#ffd9a0").clouds(4, "#ffd0b0")
                    .city("#2a1a22", 600, 100, 260, null, 0).city("#120a10", 690, 60, 180, "#ffcf7a", 0);
        }
    }

    public static List<File> userFiles() {
        File dir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES), "EmberHome");
        List<File> out = new ArrayList<File>();
        File[] fs = dir.listFiles();
        if (fs != null) {
            Arrays.sort(fs);
            for (File f : fs) {
                String n = f.getName().toLowerCase();
                if (n.endsWith(".jpg") || n.endsWith(".jpeg") || n.endsWith(".png")) out.add(f);
            }
        }
        return out;
    }

    public static int count(int cat) {
        switch (cat) {
            case 0: return G.length;
            case 4: return PLAIN.length;
            case 5: return userFiles().size();
            default: return 4;
        }
    }

    public static String key(int cat, int idx) {
        if (cat == 5) { List<File> f = userFiles(); return idx < f.size() ? "f:" + f.get(idx).getAbsolutePath() : ""; }
        return "c:" + cat + ":" + idx;
    }

    public static Drawable byKey(Context c, String key) {
        try {
            if (key == null || key.length() == 0) return null;
            if (key.startsWith("f:")) return decodeFile(new File(key.substring(2)));
            String[] p = key.split(":");
            return get(c, Integer.parseInt(p[1]), Integer.parseInt(p[2]));
        } catch (Throwable t) { return null; }
    }

    public static Drawable get(Context c, int cat, int i) {
        if (cat == 5) { List<File> f = userFiles(); return i < f.size() ? decodeFile(f.get(i)) : new ColorDrawable(0xFF111827); }
        if (cat >= 1 && cat <= 3) {
            int res = c.getResources().getIdentifier("wp_" + PHOTO[cat] + "_" + (i + 1), "drawable", c.getPackageName());
            if (res != 0) {
                try {
                    BitmapFactory.Options o = new BitmapFactory.Options();
                    o.inSampleSize = 1; o.inPreferredConfig = Bitmap.Config.RGB_565;
                    return new BitmapDrawable(c.getResources(), crop(BitmapFactory.decodeResource(c.getResources(), res, o)));
                } catch (Throwable t) { /* fall back to scene */ }
            }
        }
        switch (cat) {
            case 0: return new GradientDrawable(GradientDrawable.Orientation.TL_BR, G[i % G.length]);
            case 1: case 2: case 3: return scene(cat, i);
            default: return new ColorDrawable(PLAIN[i % PLAIN.length]);
        }
    }

    private static Drawable decodeFile(File f) {
        BitmapFactory.Options o = new BitmapFactory.Options();
        o.inJustDecodeBounds = true;
        BitmapFactory.decodeFile(f.getAbsolutePath(), o);
        int s = 1;
        while (o.outWidth / (s * 2) >= 1920) s *= 2;
        o = new BitmapFactory.Options();
        o.inSampleSize = s; o.inPreferredConfig = Bitmap.Config.RGB_565;
        Bitmap b = BitmapFactory.decodeFile(f.getAbsolutePath(), o);
        return b == null ? new ColorDrawable(0xFF111827) : new BitmapDrawable(crop(b));
    }

    /** Square, centre-cropped profile picture (128 px). */
    public static Bitmap avatar(String path) {
        try {
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            BitmapFactory.decodeFile(path, o);
            int s = 1;
            while (o.outWidth / (s * 2) >= 256) s *= 2;
            o = new BitmapFactory.Options();
            o.inSampleSize = s;
            Bitmap b = BitmapFactory.decodeFile(path, o);
            if (b == null) return null;
            int m = Math.min(b.getWidth(), b.getHeight());
            Bitmap sq = Bitmap.createBitmap(b, (b.getWidth() - m) / 2, (b.getHeight() - m) / 2, m, m);
            return Bitmap.createScaledBitmap(sq, 128, 128, true);
        } catch (Throwable t) { return null; }
    }

    /** Centre-crop to 16:9 so photos fill the screen without stretching. */
    private static Bitmap crop(Bitmap b) {
        int w = b.getWidth(), h = b.getHeight();
        int tw = w, th = w * 9 / 16;
        if (th > h) { th = h; tw = h * 16 / 9; }
        if (tw == w && th == h) return b;
        return Bitmap.createBitmap(b, (w - tw) / 2, (h - th) / 2, tw, th);
    }
}
