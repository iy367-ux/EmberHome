package com.emberhome.launcher;

import android.content.Context;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.os.StatFs;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Cinematic library: a licence-tracked catalogue (assets/cinematic_catalog.json) plus a small user-initiated download manager.
 * The catalogue ships EMPTY on purpose: no media has been individually licence-verified for bundling.
 */
public final class Cinematic {
    private Cinematic() {}

    public static class Variant { public String quality, url; public long bytes; }
    public static class Item {
        public String id, title, category, creator, licence, licenceUrl, source;
        public boolean video;
        public List<Variant> variants = new ArrayList<Variant>();
    }
    public interface Listener { void onProgress(String key, long done, long total); void onDone(String key, boolean ok, String msg); }

    private static final Map<String, boolean[]> ACTIVE = new HashMap<String, boolean[]>();      // key -> {cancelled}

    public static List<Item> catalog(Context c) {
        List<Item> out = new ArrayList<Item>();
        try {
            InputStream in = c.getAssets().open("cinematic_catalog.json");
            ByteArrayOutputStream b = new ByteArrayOutputStream();
            byte[] buf = new byte[4096];
            int n;
            while ((n = in.read(buf)) > 0) b.write(buf, 0, n);
            in.close();
            JSONArray arr = new JSONObject(b.toString("UTF-8")).getJSONArray("items");
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.getJSONObject(i);
                Item it = new Item();
                it.id = o.getString("id"); it.title = o.getString("title"); it.category = o.optString("category");
                it.creator = o.optString("creator"); it.licence = o.optString("licence"); it.licenceUrl = o.optString("licenceUrl");
                it.source = o.optString("source"); it.video = o.optBoolean("video", true);
                JSONArray vs = o.getJSONArray("variants");
                for (int j = 0; j < vs.length(); j++) {
                    Variant v = new Variant();
                    v.quality = vs.getJSONObject(j).getString("quality"); v.url = vs.getJSONObject(j).getString("url");
                    v.bytes = vs.getJSONObject(j).optLong("bytes", 0);
                    it.variants.add(v);
                }
                if (it.creator.length() > 0 && it.licence.length() > 0 && it.source.length() > 0 && !it.variants.isEmpty()) out.add(it);   // unverified entries are ignored
            }
        } catch (Throwable t) { /* empty catalogue */ }
        return out;
    }

    public static File dir(Context c) {
        File d = c.getExternalFilesDir("cinematic");
        if (d == null) d = new File(c.getFilesDir(), "cinematic");
        d.mkdirs();
        return d;
    }

    public static File file(Context c, Item it, Variant v) { return new File(dir(c), it.id + "_" + v.quality + (it.video ? ".mp4" : ".jpg")); }

    public static boolean downloaded(Context c, Item it) {
        for (Variant v : it.variants) if (file(c, it, v).exists()) return true;
        return false;
    }

    public static File firstFile(Context c, Item it) {
        for (Variant v : it.variants) if (file(c, it, v).exists()) return file(c, it, v);
        return null;
    }

    public static void delete(Context c, Item it) {
        for (Variant v : it.variants) { file(c, it, v).delete(); new File(file(c, it, v).getPath() + ".part").delete(); }
    }

    public static List<File> downloadedFiles(Context c) {
        List<File> out = new ArrayList<File>();
        for (Item it : catalog(c)) { File f = firstFile(c, it); if (f != null) out.add(f); }
        return out;
    }

    public static long freeBytes(Context c) {
        try { return new StatFs(dir(c).getPath()).getAvailableBytes(); } catch (Throwable t) { return 0; }
    }

    public static boolean isActive(Item it) {
        synchronized (ACTIVE) { for (String k : ACTIVE.keySet()) if (k.startsWith(it.id + "|")) return true; }
        return false;
    }

    public static void cancel(Item it) {
        synchronized (ACTIVE) { for (String k : ACTIVE.keySet()) if (k.startsWith(it.id + "|")) ACTIVE.get(k)[0] = true; }
    }

    /** Starts a user-requested download. Returns an error message, or null when it started. Partial files are resumed. */
    public static String start(final Context ctx, final Item it, final Variant v, final Listener l) {
        final Context c = ctx.getApplicationContext();
        final String key = it.id + "|" + v.quality;
        final File out = file(c, it, v), part = new File(out.getPath() + ".part");
        if (out.exists()) return "Already downloaded";
        if (isActive(it)) return "Already downloading";
        int net = Weather.netType(c);
        if (net != 1 && net != 2) return "Connect to Wi-Fi or Ethernet to download (mobile data is never used)";
        long need = v.bytes - (part.exists() ? part.length() : 0);
        if (v.bytes > 0 && freeBytes(c) < need + 50L * 1024 * 1024) return "Not enough free storage";
        final boolean[] flag = {false};
        synchronized (ACTIVE) { ACTIVE.put(key, flag); }
        final Handler ui = new Handler(Looper.getMainLooper());
        new Thread(new Runnable() {
            @Override public void run() {
                boolean ok = false;
                String msg = "";
                try {
                    long have = part.exists() ? part.length() : 0;
                    HttpURLConnection h = (HttpURLConnection) new URL(v.url).openConnection();
                    h.setConnectTimeout(15000); h.setReadTimeout(15000);
                    if (have > 0) h.setRequestProperty("Range", "bytes=" + have + "-");
                    int code = h.getResponseCode();
                    if (code != 200 && code != 206) throw new Exception("HTTP " + code);
                    if (code == 200) have = 0;                                    // server ignored Range
                    long total = have + h.getContentLength();
                    InputStream in = h.getInputStream();
                    FileOutputStream fo = new FileOutputStream(part, have > 0);
                    byte[] buf = new byte[32768];
                    int n;
                    long done = have, lastTick = 0;
                    while (!flag[0] && (n = in.read(buf)) > 0) {
                        fo.write(buf, 0, n);
                        done += n;
                        long now = System.currentTimeMillis();
                        if (now - lastTick > 500) { lastTick = now; final long d = done, t = total; ui.post(new Runnable() { public void run() { l.onProgress(key, d, t); } }); }
                    }
                    fo.close(); in.close(); h.disconnect();
                    if (flag[0]) msg = "Paused (partial file kept; start again to resume)";
                    else if (part.renameTo(out)) ok = true;
                    else msg = "Could not save file";
                } catch (Throwable t) { msg = "Download failed: " + t.getMessage() + " (start again to retry)"; }
                synchronized (ACTIVE) { ACTIVE.remove(key); }
                final boolean fok = ok; final String fm = msg;
                ui.post(new Runnable() { public void run() { l.onDone(key, fok, fm); } });
            }
        }, "download").start();
        return null;
    }
}
