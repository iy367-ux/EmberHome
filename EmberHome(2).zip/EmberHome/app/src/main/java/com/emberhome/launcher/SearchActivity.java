package com.emberhome.launcher;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.util.List;

/** Search your installed apps. Type with the on-screen keyboard, press Down to reach the results, OK to open. */
public class SearchActivity extends Activity {
    private LinearLayout results;
    private List<AppEntry> apps;
    private float d;
    private int dp(int v) { return (int) (v * d + 0.5f); }

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        d = getResources().getDisplayMetrics().density;
        apps = AppRepo.visible(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setBackgroundColor(0xFF0D0F14);
        root.setPadding(dp(40), dp(40), dp(40), dp(24));
        TextView title = new TextView(this);
        title.setText("Search apps"); title.setTextSize(30); title.setTextColor(Color.WHITE); title.setTypeface(Typeface.DEFAULT_BOLD);
        root.addView(title, new LinearLayout.LayoutParams(dp(640), -2));
        EditText box = new EditText(this);
        box.setHint("Type to search your installed apps");
        box.setHintTextColor(0x80FFFFFF); box.setTextColor(Color.WHITE); box.setTextSize(20);
        box.setSingleLine(true);
        box.setImeOptions(EditorInfo.IME_ACTION_DONE);
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(dp(640), -2);
        bp.topMargin = dp(14); bp.bottomMargin = dp(10);
        root.addView(box, bp);
        ScrollView sv = new ScrollView(this);
        results = new LinearLayout(this);
        results.setOrientation(LinearLayout.VERTICAL);
        sv.addView(results, new ViewGroup.LayoutParams(-1, -2));
        root.addView(sv, new LinearLayout.LayoutParams(dp(640), 0, 1f));
        setContentView(root);
        box.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) {}
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) { refresh(s.toString()); }
            @Override public void afterTextChanged(Editable s) {}
        });
        refresh("");
        box.requestFocus();
    }

    private void refresh(String q) {
        results.removeAllViews();
        String k = q.trim().toLowerCase();
        int shown = 0;
        for (final AppEntry a : apps) {
            if (k.length() > 0 && !a.label.toLowerCase().contains(k)) continue;
            shown++;
            final TextView t = new TextView(this);
            t.setText(a.label); t.setTextSize(19); t.setTypeface(Typeface.DEFAULT_BOLD);
            t.setGravity(Gravity.CENTER_VERTICAL);
            t.setCompoundDrawablePadding(dp(16));
            t.setPadding(dp(16), dp(8), dp(16), dp(8));
            Drawable ic = a.icon;
            if (ic != null) { ic.setBounds(0, 0, dp(44), dp(44)); t.setCompoundDrawables(ic, null, null, null); }
            t.setFocusable(true); t.setClickable(true);
            paint(t, false);
            t.setOnFocusChangeListener(new View.OnFocusChangeListener() { @Override public void onFocusChange(View v, boolean f) { paint(t, f); } });
            t.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    try { startActivity(a.intent); finish(); }
                    catch (Exception e) { Toast.makeText(SearchActivity.this, "Can't open " + a.label, Toast.LENGTH_SHORT).show(); }
                }
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
            lp.topMargin = dp(6);
            results.addView(t, lp);
        }
        if (shown == 0) {
            TextView none = new TextView(this);
            none.setText("No installed app matches"); none.setTextColor(0x99FFFFFF); none.setTextSize(18);
            none.setPadding(dp(16), dp(16), dp(16), dp(16));
            results.addView(none);
        }
    }

    private void paint(TextView t, boolean f) {
        GradientDrawable g = new GradientDrawable();
        g.setCornerRadius(dp(14));
        g.setColor(f ? Color.WHITE : 0x00000000);
        t.setBackgroundDrawable(g);
        t.setTextColor(f ? 0xFF111111 : Color.WHITE);
    }
}
