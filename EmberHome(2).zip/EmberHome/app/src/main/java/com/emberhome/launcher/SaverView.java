package com.emberhome.launcher;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.view.View;

/** Animated (or static preview) view for one clock style or ambient scene. */
public class SaverView extends View {
    private final SaverRenderer r = new SaverRenderer();
    private boolean ambient, still;
    private int style, fps = 0;

    public SaverView(Context c) { super(c); }

    /** still = draw one frame only (gallery thumbnails). */
    public void setMode(boolean ambient, int style, boolean still) {
        this.ambient = ambient; this.style = style; this.still = still;
        r.load(getContext());
        fps = Prefs.geti(getContext(), "sv_fps", 0);
        invalidate();
    }

    public void setStyle(int style) { this.style = style; invalidate(); }

    @Override protected void onDraw(Canvas c) {
        long now = System.currentTimeMillis();
        c.save();
        c.scale(getWidth() / 1280f, getHeight() / 720f);
        c.drawColor(Color.BLACK);
        if (ambient) r.drawAmbient(c, now, style); else r.drawClock(c, now, style);
        c.restore();
        if (still) return;
        if (ambient) postInvalidateDelayed(fps == 2 ? 60000 : fps == 1 ? 66 : 33);
        else postInvalidateDelayed(r.smooth && ((style == 1 && r.showSecs) || r.busy(now)) ? 40 : 1010 - now % 1000);
    }
}
