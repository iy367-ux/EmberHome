package com.emberhome.launcher;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.List;

/** Screensaver Gallery: Clocks, Ambient, Cinematic library and My Screensavers. D-pad only. */
public class ScreensaverGalleryActivity extends Activity {
    private static final String[] TABS = {"Clocks", "Ambient", "Cinematic", "My Screensavers"};
    private static final int REQ_IMPORT = 41;
    private int tab;
    private float d;
    private LinearLayout tabRow, content;
    private ScrollView scroll;
    private int dp(int v) { return (int) (v * d + 0.5f); }

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        d = getResources().getDisplayMetrics().density;
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(0xFF0D0F14);
        root.setPadding(dp(40), dp(28), dp(40), dp(16));
        TextView title = text("Screensaver Gallery", 28, true, Color.WHITE);
        root.addView(title);
        tabRow = new LinearLayout(this);
        tabRow.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(-2, -2);
        tp.topMargin = dp(12); tp.bottomMargin = dp(12);
        root.addView(tabRow, tp);
        scroll = new ScrollView(this);
        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(content, new ViewGroup.LayoutParams(-1, -2));
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1f));
        setContentView(root);
        show(getIntent().getIntExtra("tab", 0));
        tabRow.getChildAt(tab).requestFocus();
    }

    @Override protected void onResume() { super.onResume(); show(tab); }

    private TextView text(String s, int sp, boolean bold, int col) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(sp); t.setTextColor(col);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private void box(View v, boolean focus, boolean selected) {
        GradientDrawable g = new GradientDrawable();
        g.setCornerRadius(dp(14));
        g.setColor(0xFF161922);
        g.setStroke(dp(focus ? 4 : selected ? 2 : 1), focus ? Color.WHITE : selected ? 0xFFFFB36B : 0x33FFFFFF);
        v.setBackgroundDrawable(g);
    }

    private void show(int t) {
        tab = t;
        tabRow.removeAllViews();
        for (int i = 0; i < TABS.length; i++) {
            final int at = i;
            final TextView tv = text(TABS[i], 18, true, i == tab ? 0xFF111111 : Color.WHITE);
            tv.setPadding(dp(20), dp(10), dp(20), dp(10));
            tv.setFocusable(true); tv.setClickable(true);
            GradientDrawable g = new GradientDrawable();
            g.setCornerRadius(dp(22)); g.setColor(i == tab ? Color.WHITE : 0xFF1F2330);
            tv.setBackgroundDrawable(g);
            tv.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { show(at); tabRow.getChildAt(at).requestFocus(); } });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
            lp.rightMargin = dp(10);
            tabRow.addView(tv, lp);
        }
        content.removeAllViews();
        List<View> tiles = new ArrayList<View>();
        String mode = Prefs.gets(this, "sv_mode", "clock");
        if (tab == 0) {
            note("Pick a clock. Size, position, colour, date and seconds: Settings > Screensaver.");
            for (int i = 0; i < SaverRenderer.CLOCKS.length; i++) {
                final int at = i;
                SaverView v = new SaverView(this);
                v.setMode(false, i, true);
                tiles.add(tile(v, SaverRenderer.CLOCKS[i], mode.equals("clock") && Prefs.geti(this, "sv_clock", 0) == i ? "In use" : "", new Runnable() { public void run() { choose("clock", at); } }));
            }
        } else if (tab == 1) {
            note("Ambient scenes need no photos or video and work fully offline. Intensity and brightness: Settings > Screensaver.");
            for (int i = 0; i < SaverRenderer.AMBIENTS.length; i++) {
                final int at = i;
                SaverView v = new SaverView(this);
                v.setMode(true, i, true);
                tiles.add(tile(v, SaverRenderer.AMBIENTS[i], mode.equals("ambient") && Prefs.geti(this, "sv_amb", 0) == i ? "In use" : "", new Runnable() { public void run() { choose("ambient", at); } }));
            }
        } else if (tab == 2) cinematic(tiles);
        else mine(tiles);
        grid(tiles);
    }

    private void note(String s) {
        TextView t = text(s, 15, false, 0xB3FFFFFF);
        t.setPadding(0, 0, 0, dp(10));
        content.addView(t);
    }

    private void grid(List<View> tiles) {
        LinearLayout row = null;
        for (int i = 0; i < tiles.size(); i++) {
            if (i % 3 == 0) {
                row = new LinearLayout(this);
                row.setOrientation(LinearLayout.HORIZONTAL);
                LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(-2, -2);
                rp.bottomMargin = dp(14);
                content.addView(row, rp);
            }
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(300), -2);
            lp.rightMargin = dp(16);
            row.addView(tiles.get(i), lp);
        }
    }

    private View tile(View preview, String title, String sub, final Runnable ok) {
        final LinearLayout t = new LinearLayout(this);
        t.setOrientation(LinearLayout.VERTICAL);
        t.setFocusable(true); t.setClickable(true);
        t.setPadding(dp(6), dp(6), dp(6), dp(8));
        t.addView(preview, new LinearLayout.LayoutParams(-1, dp(160)));
        TextView a = text(title, 16, true, Color.WHITE);
        a.setPadding(dp(8), dp(6), dp(8), 0);
        a.setSingleLine(true);
        t.addView(a);
        if (sub.length() > 0) { TextView b = text(sub, 13, false, 0xFFFFB36B); b.setPadding(dp(8), 0, dp(8), 0); t.addView(b); }
        box(t, false, sub.equals("In use"));
        final boolean sel = sub.equals("In use");
        t.setOnFocusChangeListener(new View.OnFocusChangeListener() { @Override public void onFocusChange(View v, boolean f) { box(t, f, sel); } });
        t.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { ok.run(); } });
        return t;
    }

    private void choose(final String mode, final int idx) {
        final String key = mode.equals("clock") ? "sv_clock" : "sv_amb";
        new AlertDialog.Builder(this).setTitle(mode.equals("clock") ? SaverRenderer.CLOCKS[idx] : SaverRenderer.AMBIENTS[idx])
                .setItems(new String[]{"Preview", "Use as my screensaver"}, new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface dlg, int which) {
                        if (which == 0) preview(mode, idx, null, false);
                        else { Prefs.puts(ScreensaverGalleryActivity.this, "sv_mode", mode); Prefs.puti(ScreensaverGalleryActivity.this, key, idx); show(tab); }
                    }
                }).show();
    }

    private void preview(String mode, int idx, String uri, boolean video) {
        Intent i = new Intent(this, ScreensaverActivity.class).putExtra("mode", mode).putExtra("idx", idx).putExtra("preview", true);
        if (uri != null) i.putExtra("uri", uri).putExtra("video", video);
        startActivity(i);
    }

    // ---------------------------------------------------------------- Cinematic
    private void cinematic(List<View> tiles) {
        final List<Cinematic.Item> items = Cinematic.catalog(this);
        if (items.isEmpty()) {
            note("The Cinematic Library is ready for content but empty. EmberHome does not bundle or fetch any photo or video that has not been individually "
                    + "licence-verified for redistribution. Add verified items (with creator, licence and source) to assets/cinematic_catalog.json and they will appear here "
                    + "with download, quality choice and preview. Meanwhile use the Clocks, Ambient and My Screensavers sections.");
            return;
        }
        note("Downloads start only when you ask, use Wi-Fi/Ethernet only and can be resumed. Free space: " + (Cinematic.freeBytes(this) / (1024 * 1024)) + " MB.");
        for (final Cinematic.Item it : items) {
            ImageView v = new ImageView(this);
            v.setBackgroundColor(0xFF1F2330);
            String sub = Cinematic.downloaded(this, it) ? "Downloaded" : Cinematic.isActive(it) ? "Downloading..." : it.category;
            tiles.add(tile(v, it.title, sub, new Runnable() { public void run() { cinemaMenu(it); } }));
        }
    }

    private void cinemaMenu(final Cinematic.Item it) {
        final List<String> labels = new ArrayList<String>();
        final List<Runnable> acts = new ArrayList<Runnable>();
        labels.add("Info: " + it.creator + ", " + it.licence);
        acts.add(new Runnable() { public void run() { new AlertDialog.Builder(ScreensaverGalleryActivity.this).setTitle(it.title)
                .setMessage("Creator: " + it.creator + "\nLicence: " + it.licence + "\n" + it.licenceUrl + "\nSource: " + it.source).setPositiveButton("OK", null).show(); } });
        if (Cinematic.downloaded(this, it)) {
            labels.add("Preview");
            acts.add(new Runnable() { public void run() { java.io.File f = Cinematic.firstFile(ScreensaverGalleryActivity.this, it); preview("media", 0, Uri.fromFile(f).toString(), it.video); } });
            labels.add("Use cinematic downloads as my screensaver");
            acts.add(new Runnable() { public void run() { Prefs.puts(ScreensaverGalleryActivity.this, "sv_mode", "cinematic"); toast("Cinematic screensaver selected"); } });
            labels.add("Delete download");
            acts.add(new Runnable() { public void run() { Cinematic.delete(ScreensaverGalleryActivity.this, it); show(tab); } });
        } else if (Cinematic.isActive(it)) {
            labels.add("Cancel download (partial file kept)");
            acts.add(new Runnable() { public void run() { Cinematic.cancel(it); } });
        } else {
            for (final Cinematic.Variant v : it.variants) {
                labels.add("Download " + v.quality + (v.bytes > 0 ? " (" + v.bytes / (1024 * 1024) + " MB)" : ""));
                acts.add(new Runnable() { public void run() {
                    String err = Cinematic.start(ScreensaverGalleryActivity.this, it, v, new Cinematic.Listener() {
                        public void onProgress(String k, long done, long total) { }
                        public void onDone(String k, boolean ok, String msg) { if (msg.length() > 0) toast(msg); show(tab); }
                    });
                    if (err != null) toast(err); else { toast("Download started"); show(tab); }
                } });
            }
        }
        new AlertDialog.Builder(this).setTitle(it.title).setItems(labels.toArray(new String[0]), new DialogInterface.OnClickListener() {
            @Override public void onClick(DialogInterface dlg, int which) { acts.get(which).run(); }
        }).show();
    }

    // ---------------------------------------------------------------- My Screensavers
    private void mine(List<View> tiles) {
        note("Your own photos and videos. Originals are never copied or deleted; removing an item only removes it from this collection.");
        tiles.add(tile(label("＋  Import photos and videos"), "Import", "", new Runnable() { public void run() { importMedia(); } }));
        tiles.add(tile(label("Scan Pictures/EmberHome\nand Movies/EmberHome"), "Scan folders", "", new Runnable() { public void run() {
            int n = MyMedia.scanFolders(ScreensaverGalleryActivity.this);
            toast(n > 0 ? n + " item(s) added" : "Nothing new found"); show(tab); } }));
        tiles.add(tile(label("Use my media as\nscreensaver"), "Use my media", Prefs.gets(this, "sv_mode", "clock").equals("media") ? "In use" : "", new Runnable() { public void run() {
            Prefs.puts(ScreensaverGalleryActivity.this, "sv_mode", "media");
            if (MyMedia.list(ScreensaverGalleryActivity.this).isEmpty()) toast("Add some photos or videos first (the clock is used until then)");
            show(tab); } }));
        for (final MyMedia.Item it : MyMedia.list(this)) {
            final ImageView v = new ImageView(this);
            v.setScaleType(ImageView.ScaleType.CENTER_CROP);
            v.setBackgroundColor(0xFF1F2330);
            final boolean gone = !MyMedia.exists(this, it.uri);
            new Thread(new Runnable() { public void run() {
                final Bitmap bmp = gone ? null : MyMedia.thumb(ScreensaverGalleryActivity.this, it, 480);
                runOnUiThread(new Runnable() { public void run() { if (bmp != null) v.setImageBitmap(bmp); } });
            } }).start();
            String name = Uri.parse(it.uri).getLastPathSegment();
            tiles.add(tile(v, name == null ? "Item" : name, gone ? "File missing" : (it.video ? "Video" : "Photo") + (it.enabled ? "" : " · excluded"),
                    new Runnable() { public void run() { itemMenu(it, gone); } }));
        }
    }

    private TextView label(String s) {
        TextView t = text(s, 18, true, Color.WHITE);
        t.setGravity(Gravity.CENTER);
        t.setBackgroundColor(0xFF1F2330);
        return t;
    }

    private void itemMenu(final MyMedia.Item it, final boolean gone) {
        String[] labels = {"Preview", it.enabled ? "Exclude from slideshow" : "Include in slideshow", "Remove from collection (file is kept)"};
        new AlertDialog.Builder(this).setItems(labels, new DialogInterface.OnClickListener() {
            @Override public void onClick(DialogInterface dlg, int which) {
                if (which == 0) { if (gone) toast("This file is no longer available"); else preview("media", 0, it.uri, it.video); }
                else if (which == 1) { MyMedia.setEnabled(ScreensaverGalleryActivity.this, it.uri, !it.enabled); show(tab); }
                else { MyMedia.remove(ScreensaverGalleryActivity.this, it.uri); show(tab); }
            }
        }).show();
    }

    private void importMedia() {
        try {
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            i.addCategory(Intent.CATEGORY_OPENABLE);
            i.setType("*/*");
            i.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"image/*", "video/*"});
            i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
            startActivityForResult(i, REQ_IMPORT);
        } catch (Throwable t) {          // many TVs have no document picker: use the folders instead
            int n = MyMedia.scanFolders(this);
            toast("No file picker on this TV. Copy files to Pictures/EmberHome or Movies/EmberHome. " + (n > 0 ? n + " item(s) found." : "Nothing found yet."));
            show(tab);
        }
    }

    @Override protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req != REQ_IMPORT || res != RESULT_OK || data == null) return;
        List<Uri> uris = new ArrayList<Uri>();
        ClipData cd = data.getClipData();
        if (cd != null) for (int i = 0; i < cd.getItemCount(); i++) uris.add(cd.getItemAt(i).getUri());
        else if (data.getData() != null) uris.add(data.getData());
        int n = 0;
        for (Uri u : uris) {
            try { getContentResolver().takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION); } catch (Throwable t) { /* not persistable */ }
            String type = getContentResolver().getType(u);
            boolean video = type != null ? type.startsWith("video") : MyMedia.isVideoName(String.valueOf(u.getLastPathSegment()));
            if (MyMedia.add(this, u.toString(), video)) n++;
        }
        toast(n + " item(s) added");
        show(3);
    }

    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_LONG).show(); }
}
