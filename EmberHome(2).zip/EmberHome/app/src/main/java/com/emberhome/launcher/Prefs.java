package com.emberhome.launcher;

import android.content.Context;
import android.content.SharedPreferences;
import java.util.ArrayList;
import java.util.List;

public final class Prefs {
    private Prefs() {}
    private static SharedPreferences sp(Context c) { return c.getSharedPreferences("emberhome", Context.MODE_PRIVATE); }

    public static HomeStyle style(Context c) { return HomeStyle.fromKey(sp(c).getString("style", "ember")); }
    public static void setStyle(Context c, HomeStyle s) { sp(c).edit().putString("style", s.key).apply(); }

    private static List<String> csv(Context c, String key) {
        String s = sp(c).getString(key, "");
        List<String> l = new ArrayList<String>();
        if (s.length() > 0) for (String x : s.split(",")) l.add(x);
        return l;
    }
    private static void setCsv(Context c, String key, List<String> l) {
        StringBuilder b = new StringBuilder();
        for (String x : l) { if (b.length() > 0) b.append(','); b.append(x); }
        sp(c).edit().putString(key, b.toString()).apply();
    }
    public static List<String> order(Context c) { return csv(c, "order"); }
    public static void setOrder(Context c, List<String> l) { setCsv(c, "order", l); }
    public static boolean isHidden(Context c, String pkg) { return csv(c, "hidden").contains(pkg); }
    public static void setHidden(Context c, String pkg, boolean hide) {
        List<String> l = csv(c, "hidden");
        l.remove(pkg);
        if (hide) l.add(pkg);
        setCsv(c, "hidden", l);
    }
    /** "c:cat:idx" for built-in wallpapers, "f:/path" for your own pictures, "" for style default. */
    public static String wall(Context c) { return sp(c).getString("wall", ""); }
    public static void setWall(Context c, String k) { sp(c).edit().putString("wall", k).apply(); }
    private static final int[] IDLE = {1, 5, 10, 15, 30};
    public static boolean saverOn(Context c) { return getb(c, "sv_on", true); }
    public static int idleMin(Context c) { return IDLE[Math.max(0, Math.min(IDLE.length - 1, geti(c, "sv_idle", 1)))]; }

    // generic typed access used by Settings, the home screen and the screensaver
    public static int geti(Context c, String k, int d) { return sp(c).getInt(k, d); }
    public static void puti(Context c, String k, int v) { sp(c).edit().putInt(k, v).apply(); }
    public static boolean getb(Context c, String k, boolean d) { return sp(c).getBoolean(k, d); }
    public static void putb(Context c, String k, boolean v) { sp(c).edit().putBoolean(k, v).apply(); }
    public static String gets(Context c, String k, String d) { return sp(c).getString(k, d); }
    public static void puts(Context c, String k, String v) { sp(c).edit().putString(k, v).apply(); }
    public static long getl(Context c, String k, long d) { return sp(c).getLong(k, d); }
    public static void putl(Context c, String k, long v) { sp(c).edit().putLong(k, v).apply(); }
    public static List<String> list(Context c, String k) { return csv(c, k); }
    public static void putList(Context c, String k, List<String> l) { setCsv(c, k, l); }
    public static boolean inList(Context c, String k, String v) { return csv(c, k).contains(v); }
    public static void setInList(Context c, String k, String v, boolean on) {
        List<String> l = csv(c, k); l.remove(v); if (on) l.add(v); setCsv(c, k, l);
    }
    public static int avatarId(Context c) { return geti(c, "avatar_id", 0); }
    public static String profileName(Context c) { return sp(c).getString("pname", ""); }
    public static void setProfileName(Context c, String n) { sp(c).edit().putString("pname", n).apply(); }
    public static int avatarColor(Context c) { return sp(c).getInt("pcolor", 0); }
    public static void setAvatarColor(Context c, int i) { sp(c).edit().putInt("pcolor", i).apply(); }
    public static String avatarPath(Context c) { return sp(c).getString("ppath", ""); }
    public static void setAvatarPath(Context c, String p) { sp(c).edit().putString("ppath", p).apply(); }
    /** 0 = one scrolling dock, 1 = 8-app dock with the rest of the apps under it. */
    public static int glassLayout(Context c) { return sp(c).getInt("glass", 1); }
    public static void setGlassLayout(Context c, int v) { sp(c).edit().putInt("glass", v).apply(); }
    public static void resetLayout(Context c) { sp(c).edit().remove("order").remove("hidden").remove("wall").remove("fav").apply(); }
}
