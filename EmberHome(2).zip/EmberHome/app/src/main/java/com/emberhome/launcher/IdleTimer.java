package com.emberhome.launcher;

import android.app.Activity;
import android.content.Intent;
import android.os.Handler;
import android.os.Looper;

public final class IdleTimer {
    private final Activity a;
    private final Handler h = new Handler(Looper.getMainLooper());
    private final Runnable fire = new Runnable() {
        @Override public void run() { a.startActivity(new Intent(a, ScreensaverActivity.class)); }
    };
    public IdleTimer(Activity a) { this.a = a; }
    public void reset() {
        h.removeCallbacks(fire);
        if (Prefs.saverOn(a)) h.postDelayed(fire, Prefs.idleMin(a) * 60000L);
    }
    public void stop() { h.removeCallbacks(fire); }
}
