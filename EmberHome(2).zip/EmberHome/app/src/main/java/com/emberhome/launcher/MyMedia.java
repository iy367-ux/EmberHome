package com.emberhome.launcher;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.os.Environment;
import android.util.LruCache;
import java.io.File;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * The user's own screensaver photos and videos. Only references (URIs) are stored; originals are never copied or deleted.
 * Items come from Android's document picker (persistable read access) or from Pictures/EmberHome and Movies/EmberHome.
 */
public final class MyMedia {
    private MyMedia() {}
    public static class Item { public String uri; public boolean video, enabled = true; }

    private static final String KEY = "mm_items";
    private static final LruCache<String, Bitmap> CACHE = new LruCache<String, Bitmap>(24);

    public static synchronized List<Item> list(Context c) {
        List<Item> out = new ArrayList<Item>();
        String s = Prefs.gets(c, KEY, "");
        if (s.length() == 0) return out;
        for (String line : s.split("\n")) {
            String[] t = line.split("\t");
            if (t.length < 3) continue;
            Item i = new Item();
            i.uri = t[0]; i.video = t[1].equals("v"); i.enabled = t[2].equals("1");
            out.add(i);
        }
        return out;
    }

    private static void save(Context c, List<Item> l) {
        StringBuilder b = new StringBuilder();
        for (Item i : l) b.append(i.uri).append('\t').append(i.video ? "v" : "i").append('\t').append(i.enabled ? "1" : "0").append('\n');
        Prefs.puts(c, KEY, b.toString());
    }

    public static synchronized boolean add(Context c, String uri, boolean video) {
        List<Item> l = list(c);
        for (Item i : l) if (i.uri.equals(uri)) return false;
        Item n = new Item(); n.uri = uri; n.video = video;
        l.add(n);
        save(c, l);
        return true;
    }

    public static synchronized void remove(Context c, String uri) {
        List<Item> l = list(c);
        for (int i = 0; i < l.size(); i++) if (l.get(i).uri.equals(uri)) { l.remove(i); break; }
        save(c, l);
    }

    public static synchronized void setEnabled(Context c, String uri, boolean on) {
        List<Item> l = list(c);
        for (Item i : l) if (i.uri.equals(uri)) i.enabled = on;
        save(c, l);
    }

    public static boolean isVideoName(String n) {
        n = n.toLowerCase();
        return n.endsWith(".mp4") || n.endsWith(".m4v") || n.endsWith(".3gp") || n.endsWith(".webm") || n.endsWith(".mkv");
    }

    private static boolean isImageName(String n) {
        n = n.toLowerCase();
        return n.endsWith(".jpg") || n.endsWith(".jpeg") || n.endsWith(".png") || n.endsWith(".webp");
    }

    /** Adds anything found in Pictures/EmberHome and Movies/EmberHome. Returns how many new items were added. */
    public static int scanFolders(Context c) {
        int added = 0;
        File[] dirs = {new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES), "EmberHome"),
                new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES), "EmberHome")};
        for (File d : dirs) {
            File[] fs = d.listFiles();
            if (fs == null) continue;
            Arrays.sort(fs);
            for (File f : fs) {
                String n = f.getName();
                if (isVideoName(n) || isImageName(n)) if (add(c, Uri.fromFile(f).toString(), isVideoName(n))) added++;
            }
        }
        return added;
    }

    public static boolean exists(Context c, String uri) {
        try {
            Uri u = Uri.parse(uri);
            if ("file".equals(u.getScheme())) return new File(u.getPath()).exists();
            InputStream in = c.getContentResolver().openInputStream(u);
            if (in == null) return false;
            in.close();
            return true;
        } catch (Throwable t) { return false; }
    }

    /** Decodes with a sample size so the bitmap never exceeds roughly maxW pixels wide (RGB_565 keeps memory low). */
    public static Bitmap decode(Context c, String uri, int maxW) {
        try {
            Uri u = Uri.parse(uri);
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            InputStream in = c.getContentResolver().openInputStream(u);
            BitmapFactory.decodeStream(in, null, o);
            in.close();
            int s = 1;
            while (o.outWidth / (s * 2) >= maxW) s *= 2;
            o = new BitmapFactory.Options();
            o.inSampleSize = s;
            o.inPreferredConfig = Bitmap.Config.RGB_565;
            in = c.getContentResolver().openInputStream(u);
            Bitmap b = BitmapFactory.decodeStream(in, null, o);
            in.close();
            return b;
        } catch (Throwable t) { return null; }
    }

    /** Thumbnail (cached). Call from a background thread. */
    public static Bitmap thumb(Context c, Item it, int w) {
        Bitmap b = CACHE.get(it.uri);
        if (b != null) return b;
        try {
            if (it.video) {
                MediaMetadataRetriever r = new MediaMetadataRetriever();
                r.setDataSource(c, Uri.parse(it.uri));
                b = r.getFrameAtTime(1000000);
                r.release();
                if (b != null) b = Bitmap.createScaledBitmap(b, w, Math.max(1, b.getHeight() * w / b.getWidth()), true);
            } else b = decode(c, it.uri, w);
        } catch (Throwable t) { b = null; }
        if (b != null) CACHE.put(it.uri, b);
        return b;
    }
}
