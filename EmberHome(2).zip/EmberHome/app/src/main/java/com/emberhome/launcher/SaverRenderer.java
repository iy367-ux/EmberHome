package com.emberhome.launcher;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.Random;
import java.util.TimeZone;

/** Draws the 7 clock styles and 5 ambient scenes on a 1280x720 virtual canvas. Pure Canvas, no images. */
public final class SaverRenderer {
    public static final String[] CLOCKS = {"Minimal Digital", "Classic Analog", "Flip Clock", "World Clock", "Typography Clock", "Ambient Glow", "Word Clock"};
    public static final String[] AMBIENTS = {"Flowing Gradients", "Ambient Glow", "Floating Particles", "Geometric Motion", "Cosmic Journey"};
    public static final int[] COLORS = {0xFFFFFFFF, 0xFFFFB36B, 0xFF7FB8FF, 0xFF6FE3A0, 0xFFFF8CC0, 0xFFFFD166};
    private static final String[] DATE_FMT = {"EEEE, d MMMM", "EEE, d MMM yyyy", "dd/MM/yyyy", "MM/dd/yyyy"};
    private static final float[] SIZE = {0.8f, 1f, 1.2f};
    private static final float[][] POS = {{640, 360}, {360, 520}, {930, 200}, {920, 520}};
    private static final String[] HOURS = {"twelve", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine", "ten", "eleven"};
    private static final String[] PHRASE = {"", "five past", "ten past", "quarter past", "twenty past", "twenty-five past", "half past",
            "twenty-five to", "twenty to", "quarter to", "ten to", "five to"};
    private static final String[][] ZONES = {{"New York", "America/New_York"}, {"London", "Europe/London"}, {"Dubai", "Asia/Dubai"}, {"Tokyo", "Asia/Tokyo"}};
    private static final Typeface LIGHT = Typeface.create("sans-serif-light", Typeface.NORMAL);
    private static final Typeface MED = Typeface.create("sans-serif-medium", Typeface.NORMAL);
    private static final Typeface BOLD = Typeface.DEFAULT_BOLD;

    // configuration
    public int color = COLORS[0], size = 1, pos, dateFmt;
    public boolean h24, showDate = true, showSecs, smooth = true;
    public float speed = 1f, count = 1f;

    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF rf = new RectF();
    private final Path path = new Path();
    private long last;

    public void load(Context c) {
        color = COLORS[Math.max(0, Math.min(5, Prefs.geti(c, "sv_ccol", 0)))];
        size = Math.max(0, Math.min(2, Prefs.geti(c, "sv_csize", 1)));
        pos = Math.max(0, Math.min(3, Prefs.geti(c, "sv_cpos", 0)));
        showDate = Prefs.getb(c, "sv_date", true);
        showSecs = Prefs.getb(c, "sv_secs", false);
        h24 = Prefs.getb(c, "clock24", false);
        dateFmt = Math.max(0, Math.min(3, Prefs.geti(c, "date_fmt", 0)));
        int fps = Prefs.geti(c, "sv_fps", 0);
        smooth = fps == 0 && Prefs.getb(c, "anim", true) && !Prefs.getb(c, "reduce_motion", false);
        float inten = new float[]{0.6f, 1f, 1.5f}[Math.max(0, Math.min(2, Prefs.geti(c, "sv_int", 1)))];
        speed = inten * (smooth ? 1f : 0.35f);
        count = inten;
    }

    // ---------------------------------------------------------------- helpers
    private void text(Canvas c, String s, float x, float y, float sz, int col, Typeface tf, Paint.Align al) {
        p.setShader(null); p.setStyle(Paint.Style.FILL); p.setColor(col); p.setTypeface(tf); p.setTextSize(sz); p.setTextAlign(al);
        c.drawText(s, x, y, p);
    }
    private static int alpha(int col, float a) { return (col & 0xFFFFFF) | ((int) (Math.max(0, Math.min(1, a)) * 255) << 24); }
    private String dateText(long now) { return new SimpleDateFormat(DATE_FMT[dateFmt], Locale.getDefault()).format(new Date(now)); }
    private String two(int v) { return v < 10 ? "0" + v : String.valueOf(v); }
    private int h12(int h) { return h % 12 == 0 ? 12 : h % 12; }
    private String timeText(Calendar cal, boolean sec) {
        int h = cal.get(Calendar.HOUR_OF_DAY);
        return (h24 ? two(h) : String.valueOf(h12(h))) + ":" + two(cal.get(Calendar.MINUTE)) + (sec ? ":" + two(cal.get(Calendar.SECOND)) : "");
    }

    // ---------------------------------------------------------------- clocks
    private final char[] cur = new char[6], prev = new char[6];
    private final long[] chg = new long[6];

    /** True while a flip animation is running (the view then redraws faster). */
    public boolean busy(long now) {
        for (long t : chg) if (now - t < 450) return true;
        return false;
    }

    public void drawClock(Canvas c, long now, int style) {
        Calendar cal = Calendar.getInstance();
        cal.setTimeInMillis(now);
        float k = pos == 0 ? 1f : 0.72f, s = SIZE[size] * k;
        float dx = ((now / 60000) % 7 - 3) * 5, dy = ((now / 60000) % 5 - 2) * 5;      // slow drift protects OLED panels
        c.save();
        c.translate(POS[pos][0] + dx, POS[pos][1] + dy);
        c.scale(s, s);
        switch (style) {
            case 0: minimal(c, now, cal); break;
            case 1: analog(c, now, cal); break;
            case 2: flip(c, now, cal); break;
            case 3: world(c, now, cal); break;
            case 4: typography(c, now, cal); break;
            case 5: glow(c, now, cal); break;
            default: words(c, now, cal);
        }
        c.restore();
    }

    private void minimal(Canvas c, long now, Calendar cal) {
        text(c, timeText(cal, showSecs), 0, 60, 190, color, LIGHT, Paint.Align.CENTER);
        if (showDate) text(c, dateText(now), 0, 130, 36, alpha(color, .7f), MED, Paint.Align.CENTER);
    }

    private void analog(Canvas c, long now, Calendar cal) {
        float r = 230;
        p.setShader(null); p.setStyle(Paint.Style.STROKE); p.setStrokeCap(Paint.Cap.ROUND);
        p.setStrokeWidth(3); p.setColor(alpha(color, .3f));
        c.drawCircle(0, 0, r + 20, p);
        for (int i = 0; i < 60; i++) {
            double a = i * Math.PI / 30;
            boolean big = i % 5 == 0;
            p.setStrokeWidth(big ? 5 : 2); p.setColor(alpha(color, big ? .9f : .4f));
            float r1 = r + 10, r2 = r1 - (big ? 24 : 10);
            c.drawLine((float) Math.sin(a) * r1, (float) -Math.cos(a) * r1, (float) Math.sin(a) * r2, (float) -Math.cos(a) * r2, p);
        }
        for (int h = 1; h <= 12; h++) {
            double a = h * Math.PI / 6;
            text(c, String.valueOf(h), (float) Math.sin(a) * r * .74f, (float) -Math.cos(a) * r * .74f + 13, 38, alpha(color, .9f), MED, Paint.Align.CENTER);
        }
        int H = cal.get(Calendar.HOUR), M = cal.get(Calendar.MINUTE), S = cal.get(Calendar.SECOND);
        float sec = S + (smooth ? cal.get(Calendar.MILLISECOND) / 1000f : 0);
        hand(c, (H + M / 60f) * 30, 120, 12, color);
        hand(c, (M + S / 60f) * 6, 180, 8, color);
        if (showSecs) hand(c, sec * 6, 205, 3, 0xFFFF6B3D);
        p.setStyle(Paint.Style.FILL); p.setColor(color);
        c.drawCircle(0, 0, 11, p);
        if (showDate) text(c, dateText(now), 0, r + 90, 32, alpha(color, .7f), MED, Paint.Align.CENTER);
    }

    private void hand(Canvas c, float deg, float len, float w, int col) {
        double a = Math.toRadians(deg);
        p.setShader(null); p.setStyle(Paint.Style.STROKE); p.setStrokeCap(Paint.Cap.ROUND); p.setStrokeWidth(w); p.setColor(col);
        c.drawLine(0, 0, (float) Math.sin(a) * len, (float) -Math.cos(a) * len, p);
    }

    private void flip(Canvas c, long now, Calendar cal) {
        String t = timeText(cal, showSecs).replace(":", "");
        if (t.length() == 3) t = "0" + t;             // keep a leading card for 12-hour times
        int n = t.length();
        float w = 150, h = 220, gap = 14, colon = 40;
        int groups = showSecs ? 3 : 2;
        float total = n * w + (n - groups) * gap + (groups - 1) * colon + (groups - 1) * 0;
        float x = -total / 2, y = -h / 2 - 20;
        for (int i = 0; i < n; i++) {
            char ch = t.charAt(i);
            if (cur[i] == 0) { cur[i] = ch; prev[i] = ch; }
            if (ch != cur[i]) { prev[i] = cur[i]; cur[i] = ch; chg[i] = now; }
            float q = smooth ? Math.min(1f, (now - chg[i]) / 400f) : 1f;
            flipCard(c, x, y, w, h, prev[i], cur[i], q);
            x += w;
            boolean endGroup = (i % 2 == 1) && i < n - 1;
            if (endGroup) {
                p.setStyle(Paint.Style.FILL); p.setShader(null); p.setColor(alpha(color, .8f));
                c.drawCircle(x + colon / 2, y + h * .36f, 7, p); c.drawCircle(x + colon / 2, y + h * .64f, 7, p);
                x += colon;
            } else x += gap;
        }
        if (showDate) text(c, dateText(now), 0, h / 2 + 70, 34, alpha(color, .7f), MED, Paint.Align.CENTER);
    }

    private void card(Canvas c, float x, float y, float w, float h, char ch) {
        text(c, String.valueOf(ch), x + w / 2, y + h * 0.74f, 190, color, BOLD, Paint.Align.CENTER);
    }

    private void flipCard(Canvas c, float x, float y, float w, float h, char old, char now, float q) {
        float mid = y + h / 2;
        p.setShader(null); p.setStyle(Paint.Style.FILL);
        p.setColor(0xFF1B1E27); rf.set(x, y, x + w, y + h); c.drawRoundRect(rf, 18, 18, p);
        c.save(); c.clipRect(x, y, x + w, mid); card(c, x, y, w, h, q < 1 ? now : now); c.restore();               // top = new
        c.save(); c.clipRect(x, mid, x + w, y + h); card(c, x, y, w, h, q < .5f ? old : now); c.restore();         // bottom
        if (q < .5f) {                                                                                             // old top folds down
            c.save(); c.translate(0, mid); c.scale(1, 1 - 2 * q); c.translate(0, -mid);
            c.clipRect(x, y, x + w, mid);
            p.setColor(0xFF1B1E27); rf.set(x, y, x + w, y + h); c.drawRoundRect(rf, 18, 18, p);
            card(c, x, y, w, h, old); c.restore();
        } else if (q < 1f) {                                                                                       // new bottom unfolds
            c.save(); c.translate(0, mid); c.scale(1, 2 * q - 1); c.translate(0, -mid);
            c.clipRect(x, mid, x + w, y + h);
            p.setColor(0xFF22262F); rf.set(x, y, x + w, y + h); c.drawRoundRect(rf, 18, 18, p);
            card(c, x, y, w, h, now); c.restore();
        }
        p.setStyle(Paint.Style.FILL); p.setColor(0xFF000000); c.drawRect(x, mid - 2, x + w, mid + 2, p);
    }

    private void world(Canvas c, long now, Calendar cal) {
        text(c, timeText(cal, showSecs), 0, -50, 150, color, LIGHT, Paint.Align.CENTER);
        text(c, "Local  ·  " + TimeZone.getDefault().getID().replace('_', ' '), 0, 0, 28, alpha(color, .65f), MED, Paint.Align.CENTER);
        float w = 250, gap = 20, x0 = -(4 * w + 3 * gap) / 2;
        int today = cal.get(Calendar.DAY_OF_YEAR);
        for (int i = 0; i < 4; i++) {
            Calendar z = Calendar.getInstance(TimeZone.getTimeZone(ZONES[i][1]));
            z.setTimeInMillis(now);
            float x = x0 + i * (w + gap);
            p.setShader(null); p.setStyle(Paint.Style.FILL); p.setColor(0xFF161922);
            rf.set(x, 50, x + w, 220); c.drawRoundRect(rf, 22, 22, p);
            text(c, ZONES[i][0], x + w / 2, 92, 28, alpha(color, .8f), MED, Paint.Align.CENTER);
            text(c, timeText(z, false), x + w / 2, 160, 62, color, LIGHT, Paint.Align.CENTER);
            int dd = z.get(Calendar.DAY_OF_YEAR) - today;
            if (dd > 300) dd = -1; else if (dd < -300) dd = 1;
            text(c, dd == 0 ? "Today" : dd > 0 ? "Tomorrow" : "Yesterday", x + w / 2, 197, 22, alpha(color, .55f), MED, Paint.Align.CENTER);
        }
        if (showDate) text(c, dateText(now), 0, 290, 30, alpha(color, .6f), MED, Paint.Align.CENTER);
    }

    private void typography(Canvas c, long now, Calendar cal) {
        int h = cal.get(Calendar.HOUR_OF_DAY);
        String hh = h24 ? two(h) : String.valueOf(h12(h));
        text(c, hh, -10, -10, 380, alpha(color, .95f), BOLD, Paint.Align.CENTER);
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(5); p.setColor(color); p.setTypeface(BOLD); p.setTextSize(380); p.setTextAlign(Paint.Align.CENTER);
        c.drawText(two(cal.get(Calendar.MINUTE)), 60, 300, p);
        p.setStyle(Paint.Style.FILL);
        String sub = (showSecs ? ":" + two(cal.get(Calendar.SECOND)) + "   " : "") + (showDate ? dateText(now) : "");
        if (sub.length() > 0) text(c, sub, 0, 370, 34, alpha(color, .65f), MED, Paint.Align.CENTER);
    }

    private void glow(Canvas c, long now, Calendar cal) {
        float r = (float) (430 * (1 + 0.04 * Math.sin(now / 2500.0)));
        p.setStyle(Paint.Style.FILL);
        p.setShader(new RadialGradient(0, 0, r, new int[]{alpha(color, .38f), alpha(color, .12f), alpha(color, 0f)}, new float[]{0, .5f, 1}, Shader.TileMode.CLAMP));
        c.drawCircle(0, 0, r, p);
        p.setShader(null);
        p.setShadowLayer(36, 0, 0, alpha(color, .8f));
        text(c, timeText(cal, showSecs), 0, 60, 200, color, LIGHT, Paint.Align.CENTER);
        p.clearShadowLayer();
        if (showDate) text(c, dateText(now), 0, 130, 36, alpha(color, .7f), MED, Paint.Align.CENTER);
    }

    private void fitText(Canvas c, String s, float y, float sz, float maxW, int col, Typeface tf) {
        p.setTypeface(tf); p.setTextSize(sz);
        float w = p.measureText(s), k = w > maxW ? maxW / w : 1f;
        text(c, s, 0, y, sz * k, col, tf, Paint.Align.CENTER);
    }

    private void words(Canvas c, long now, Calendar cal) {
        int h = cal.get(Calendar.HOUR_OF_DAY), m5 = (cal.get(Calendar.MINUTE) + 2) / 5 * 5;
        if (m5 >= 60) { m5 = 0; h++; }
        int idx = m5 / 5, hour = (idx >= 7 ? h + 1 : h) % 12;
        text(c, "IT’S", 0, -90, 54, alpha(color, .55f), MED, Paint.Align.CENTER);
        if (idx == 0) {
            fitText(c, HOURS[hour].toUpperCase(Locale.US), 50, 160, 1000, color, BOLD);
            fitText(c, "O’CLOCK", 150, 90, 1000, alpha(color, .8f), BOLD);
        } else {
            fitText(c, PHRASE[idx].toUpperCase(Locale.US), 40, 110, 1000, alpha(color, .85f), BOLD);
            fitText(c, HOURS[hour].toUpperCase(Locale.US), 170, 150, 1000, color, BOLD);
        }
        if (showDate) text(c, dateText(now), 0, 240, 32, alpha(color, .6f), MED, Paint.Align.CENTER);
    }

    // ---------------------------------------------------------------- ambient
    private static final int MAXP = 120, MAXS = 16, MAXST = 300;
    private final float[] px = new float[MAXP], py = new float[MAXP], pz = new float[MAXP], pph = new float[MAXP];
    private final float[] gx = new float[MAXS], gy = new float[MAXS], gs = new float[MAXS], gr = new float[MAXS], gv = new float[MAXS], gdx = new float[MAXS], gdy = new float[MAXS];
    private final int[] gt = new int[MAXS], gc = new int[MAXS];
    private final float[] sx = new float[MAXST], sy = new float[MAXST], sz = new float[MAXST];
    private boolean inited;
    private static final int[][] PAL = {{0xFF3B1FA8, 0xFF1E6BFF, 0xFF8E2DE2, 0xFF0B3D91}, {0xFF0E6B73, 0xFF1B4965, 0xFF2A9D8F, 0xFF264653},
            {0xFFFF9A8B, 0xFFFFD6A5, 0xFFB5A8FF, 0xFF8FD3FE}};
    private static final int[] GEO = {0xFF7F5AF0, 0xFF2CB1BC, 0xFFFFB36B, 0xFF6AA9FF};

    private void init() {
        Random r = new Random(11);
        for (int i = 0; i < MAXP; i++) { px[i] = r.nextFloat() * 1280; py[i] = r.nextFloat() * 720; pz[i] = .2f + r.nextFloat() * .8f; pph[i] = r.nextFloat() * 6.28f; }
        for (int i = 0; i < MAXS; i++) {
            gx[i] = r.nextFloat() * 1280; gy[i] = r.nextFloat() * 720; gs[i] = 50 + r.nextFloat() * 90; gr[i] = r.nextFloat() * 360;
            gv[i] = (r.nextFloat() - .5f) * 8; gdx[i] = (r.nextFloat() - .5f) * 14; gdy[i] = (r.nextFloat() - .5f) * 10;
            gt[i] = r.nextInt(4); gc[i] = r.nextInt(4);
        }
        for (int i = 0; i < MAXST; i++) { sx[i] = r.nextFloat() * 2 - 1; sy[i] = r.nextFloat() * 2 - 1; sz[i] = .05f + r.nextFloat() * .95f; }
        inited = true;
    }

    public void drawAmbient(Canvas c, long now, int style) {
        if (!inited) init();
        float dt = last == 0 ? 0 : Math.min(80, now - last) / 1000f;
        if (dt < 0) dt = 0;
        last = now;
        float sp = dt * speed;
        switch (style) {
            case 0: gradients(c, now); break;
            case 1: lights(c, now); break;
            case 2: particles(c, sp); break;
            case 3: geometry(c, sp); break;
            default: cosmos(c, now, sp);
        }
    }

    private void blob(Canvas c, float x, float y, float r, int col, float a) {
        p.setStyle(Paint.Style.FILL);
        p.setShader(new RadialGradient(x, y, r, alpha(col, a), alpha(col, 0), Shader.TileMode.CLAMP));
        c.drawCircle(x, y, r, p);
        p.setShader(null);
    }

    private void gradients(Canvas c, long now) {
        double t = now * speed;
        double phase = now / 90000.0;
        int idx = (int) phase % 3, prevIdx = (idx + 2) % 3;
        float w = Math.min(1f, (float) ((phase - Math.floor(phase)) * 90 / 6.0));
        for (int pass = 0; pass < 2; pass++) {
            int[] pal = PAL[pass == 0 ? prevIdx : idx];
            float a = (pass == 0 ? 1 - w : w) * (idx == 2 || prevIdx == 2 ? .4f : .7f);
            if (a <= 0.01f) continue;
            for (int i = 0; i < 4; i++)
                blob(c, (float) (640 + 520 * Math.sin(t * 0.00007 * (i + 1) + i * 1.7)), (float) (360 + 280 * Math.cos(t * 0.00005 * (i + 2) + i)), 560, pal[i], a);
        }
    }

    private void lights(Canvas c, long now) {
        double t = now * speed;
        blob(c, (float) (400 + 160 * Math.sin(t * 0.00009)), (float) (300 + 90 * Math.cos(t * 0.00007)), (float) (470 + 30 * Math.sin(t * 0.0002)), 0xFFFFA45C, .34f);
        blob(c, (float) (900 + 140 * Math.cos(t * 0.00006)), (float) (430 + 100 * Math.sin(t * 0.00008)), 520, 0xFF5C8DFF, .28f);
        blob(c, (float) (650 + 200 * Math.sin(t * 0.00005 + 2)), (float) (220 + 80 * Math.cos(t * 0.00009)), 380, 0xFFB26BFF, .2f);
    }

    private void particles(Canvas c, float sp) {
        int n = Math.min(MAXP, (int) (70 * count));
        p.setStyle(Paint.Style.FILL); p.setShader(null);
        for (int i = 0; i < n; i++) {
            pph[i] += sp * (.4f + pz[i]);
            py[i] -= sp * 22 * pz[i];
            px[i] += (float) Math.sin(pph[i]) * sp * 14 * pz[i];
            if (py[i] < -20) { py[i] = 740; px[i] = (px[i] * 7 + 100) % 1280; }
            p.setColor(alpha(0xFFBFD7FF, .12f + .5f * pz[i]));
            c.drawCircle(px[i], py[i], 1.2f + 5 * pz[i], p);
        }
    }

    private void poly(Path out, int sides, float r) {
        out.reset();
        for (int i = 0; i < sides; i++) {
            double a = i * 2 * Math.PI / sides - Math.PI / 2;
            if (i == 0) out.moveTo((float) Math.cos(a) * r, (float) Math.sin(a) * r); else out.lineTo((float) Math.cos(a) * r, (float) Math.sin(a) * r);
        }
        out.close();
    }

    private void geometry(Canvas c, float sp) {
        int n = Math.min(MAXS, (int) (10 * count));
        for (int i = 0; i < n; i++) {
            gx[i] += gdx[i] * sp; gy[i] += gdy[i] * sp; gr[i] += gv[i] * sp;
            if (gx[i] < -150) gx[i] = 1430; else if (gx[i] > 1430) gx[i] = -150;
            if (gy[i] < -150) gy[i] = 870; else if (gy[i] > 870) gy[i] = -150;
            int sides = gt[i] == 0 ? 3 : gt[i] == 1 ? 4 : gt[i] == 2 ? 6 : 0;
            for (int pass = 0; pass < 3; pass++) {
                c.save();
                c.translate(gx[i] + (pass == 0 ? 10 : 0), gy[i] + (pass == 0 ? 14 : 0));
                c.rotate(gr[i]);
                if (sides == 0) { path.reset(); path.addCircle(0, 0, gs[i], Path.Direction.CW); } else poly(path, sides, gs[i]);
                p.setShader(null);
                if (pass == 0) { p.setStyle(Paint.Style.FILL); p.setColor(0x33000000); }
                else if (pass == 1) { p.setStyle(Paint.Style.FILL); p.setColor(alpha(GEO[gc[i]], .16f)); }
                else { p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(2.5f); p.setColor(alpha(GEO[gc[i]], .55f)); }
                c.drawPath(path, p);
                c.restore();
            }
        }
        p.setStyle(Paint.Style.FILL);
    }

    private void cosmos(Canvas c, long now, float sp) {
        blob(c, (float) (420 + 40 * Math.sin(now * 0.00003)), 260, 520, 0xFF6A3DE8, .2f);
        blob(c, (float) (900 + 40 * Math.cos(now * 0.00004)), 500, 460, 0xFF2D6BFF, .16f);
        int n = Math.min(MAXST, (int) (200 * count));
        p.setStyle(Paint.Style.FILL); p.setShader(null);
        for (int i = 0; i < n; i++) {
            sz[i] -= sp * 0.045f;
            float X = 640 + sx[i] / sz[i] * 220, Y = 360 + sy[i] / sz[i] * 124;
            if (sz[i] < .04f || X < -10 || X > 1290 || Y < -10 || Y > 730) { sx[i] = (float) (Math.random() * 2 - 1); sy[i] = (float) (Math.random() * 2 - 1); sz[i] = 1f; continue; }
            float near = 1 - sz[i];
            p.setColor(alpha(0xFFFFFFFF, .25f + .75f * near));
            c.drawCircle(X, Y, .6f + near * 2.2f, p);
        }
    }
}
