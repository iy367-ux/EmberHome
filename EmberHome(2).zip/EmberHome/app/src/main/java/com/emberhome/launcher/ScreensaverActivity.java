package com.emberhome.launcher;

import android.animation.ObjectAnimator;
import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.VideoView;
import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/**
 * Plays the chosen screensaver: a native clock, an ambient scene, or a photo/video slideshow
 * (my media or downloaded cinematic items). Any remote key wakes it. All resources are released in onPause.
 * Extras (used by the gallery preview): mode, idx, preview, uri, video.
 */
public class ScreensaverActivity extends Activity {
    private static final String[] DATE_FMT = {"EEEE, d MMMM", "EEE, d MMM yyyy", "dd/MM/yyyy", "MM/dd/yyyy"};
    private final Handler h = new Handler();
    private SaverView sv;
    private FrameLayout root;
    private final ImageView[] img = new ImageView[2];
    private VideoView vv;
    private LinearLayout overlay;
    private TextView clockTv, dateTv, wxTv;
    private View blackout;
    private String mode;
    private int idx, front, pos = -1;
    private boolean preview, alive, mediaMode, videoShowing;
    private final List<String> uris = new ArrayList<String>();
    private final List<Boolean> vids = new ArrayList<Boolean>();
    private int token;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN | WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        int dim = Prefs.geti(this, "sv_dim", 0);
        if (dim > 0) {
            WindowManager.LayoutParams lp = getWindow().getAttributes();
            lp.screenBrightness = dim == 1 ? 0.6f : 0.3f;
            getWindow().setAttributes(lp);
        }
        readExtras();
        root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);
        sv = new SaverView(this);
        root.addView(sv, new FrameLayout.LayoutParams(-1, -1));
        for (int i = 0; i < 2; i++) {
            img[i] = new ImageView(this);
            img[i].setScaleType(ImageView.ScaleType.CENTER_CROP);
            img[i].setVisibility(View.GONE);
            root.addView(img[i], new FrameLayout.LayoutParams(-1, -1));
        }
        vv = new VideoView(this);
        vv.setVisibility(View.GONE);
        root.addView(vv, new FrameLayout.LayoutParams(-1, -1, Gravity.CENTER));
        overlay = new LinearLayout(this);
        overlay.setOrientation(LinearLayout.VERTICAL);
        float d = getResources().getDisplayMetrics().density;
        clockTv = new TextView(this); clockTv.setTextColor(Color.WHITE); clockTv.setTextSize(64);
        dateTv = new TextView(this); dateTv.setTextColor(0xE6FFFFFF); dateTv.setTextSize(20);
        wxTv = new TextView(this); wxTv.setTextColor(0xE6FFFFFF); wxTv.setTextSize(20);
        for (TextView t : new TextView[]{clockTv, dateTv, wxTv}) { t.setShadowLayer(8, 0, 2, 0xCC000000); overlay.addView(t); }
        FrameLayout.LayoutParams op = new FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM | Gravity.LEFT);
        op.setMargins((int) (48 * d), 0, 0, (int) (40 * d));
        root.addView(overlay, op);
        blackout = new View(this);
        blackout.setBackgroundColor(Color.BLACK);
        blackout.setVisibility(View.GONE);
        root.addView(blackout, new FrameLayout.LayoutParams(-1, -1));
        setContentView(root);
    }

    private void readExtras() {
        mode = getIntent().getStringExtra("mode");
        preview = getIntent().getBooleanExtra("preview", false);
        if (mode == null) mode = Prefs.gets(this, "sv_mode", "clock");
        idx = getIntent().hasExtra("idx") ? getIntent().getIntExtra("idx", 0)
                : mode.equals("ambient") ? Prefs.geti(this, "sv_amb", 0) : Prefs.geti(this, "sv_clock", 0);
    }

    @Override protected void onResume() {
        super.onResume();
        alive = true;
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
        start();
        int[] max = {0, 1, 2, 4};
        int m = max[Math.max(0, Math.min(3, Prefs.geti(this, "sv_max", 2)))];
        if (m > 0 && !preview) h.postDelayed(new Runnable() { public void run() { sleep(); } }, m * 3600000L);
    }

    @Override protected void onPause() {
        super.onPause();
        alive = false;
        token++;
        h.removeCallbacksAndMessages(null);
        try { vv.stopPlayback(); } catch (Throwable t) { /* ignore */ }
        for (ImageView i : img) { i.setImageDrawable(null); i.setVisibility(View.GONE); }
        vv.setVisibility(View.GONE);
        finish();
    }

    /** Maximum screensaver time reached: go black and let the TV's own sleep timer work. */
    private void sleep() {
        token++;
        try { vv.stopPlayback(); } catch (Throwable t) { /* ignore */ }
        blackout.setVisibility(View.VISIBLE);
        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
    }

    private void start() {
        mediaMode = mode.equals("media") || mode.equals("cinematic");
        if (mediaMode) buildPlaylist();
        if (mediaMode && uris.isEmpty()) { mediaMode = false; mode = "clock"; idx = Prefs.geti(this, "sv_clock", 0); }
        sv.setVisibility(mediaMode ? View.GONE : View.VISIBLE);
        overlay.setVisibility(View.GONE);
        if (!mediaMode) {
            sv.setMode(mode.equals("ambient"), idx, false);
            if (mode.equals("clock") && Prefs.getb(this, "sv_rot", false) && !preview) rotate();
            return;
        }
        boolean h24 = Prefs.getb(this, "clock24", false);
        clockTv.setText(new SimpleDateFormat(h24 ? "HH:mm" : "h:mm", Locale.getDefault()).format(new Date()));
        dateTv.setText(new SimpleDateFormat(DATE_FMT[Math.max(0, Math.min(3, Prefs.geti(this, "date_fmt", 0)))], Locale.getDefault()).format(new Date()));
        Weather.Now n = Weather.cached(this);
        wxTv.setText(n != null ? Weather.describe(n.code) + "  " + Weather.tempText(this, n) : "");
        clockTv.setVisibility(Prefs.getb(this, "sv_oclock", true) ? View.VISIBLE : View.GONE);
        dateTv.setVisibility(Prefs.getb(this, "sv_odate", true) ? View.VISIBLE : View.GONE);
        wxTv.setVisibility(Prefs.getb(this, "sv_owx", false) && wxTv.length() > 0 ? View.VISIBLE : View.GONE);
        overlay.setVisibility(View.VISIBLE);
        overlay.bringToFront();
        clockTick();
        next();
    }

    private void clockTick() {
        h.postDelayed(new Runnable() { public void run() {
            if (!alive) return;
            boolean h24 = Prefs.getb(ScreensaverActivity.this, "clock24", false);
            clockTv.setText(new SimpleDateFormat(h24 ? "HH:mm" : "h:mm", Locale.getDefault()).format(new Date()));
            clockTick();
        } }, 15000);
    }

    private void rotate() {
        int[] mins = {1, 5, 15};
        long ms = mins[Math.max(0, Math.min(2, Prefs.geti(this, "sv_rotint", 1)))] * 60000L;
        h.postDelayed(new Runnable() { public void run() {
            if (!alive) return;
            idx = (idx + 1) % SaverRenderer.CLOCKS.length;
            sv.setStyle(idx);
            rotate();
        } }, ms);
    }

    // ---------------------------------------------------------------- slideshow
    private void buildPlaylist() {
        uris.clear(); vids.clear();
        boolean video = Prefs.getb(this, "sv_video", true);
        String one = getIntent().getStringExtra("uri");
        if (one != null) {
            uris.add(one); vids.add(getIntent().getBooleanExtra("video", false));
            return;
        }
        if (mode.equals("cinematic")) {
            for (File f : Cinematic.downloadedFiles(this)) {
                boolean v = MyMedia.isVideoName(f.getName());
                if (v && !video) continue;
                uris.add(Uri.fromFile(f).toString()); vids.add(v);
            }
        } else {
            for (MyMedia.Item it : MyMedia.list(this)) {
                if (!it.enabled || (it.video && !video) || !MyMedia.exists(this, it.uri)) continue;
                uris.add(it.uri); vids.add(it.video);
            }
        }
        if (Prefs.geti(this, "sv_order", 0) == 1 && uris.size() > 1) {
            long seed = System.nanoTime();
            List<Integer> order = new ArrayList<Integer>();
            for (int i = 0; i < uris.size(); i++) order.add(i);
            Collections.shuffle(order, new java.util.Random(seed));
            List<String> u2 = new ArrayList<String>(); List<Boolean> v2 = new ArrayList<Boolean>();
            for (int i : order) { u2.add(uris.get(i)); v2.add(vids.get(i)); }
            uris.clear(); vids.clear(); uris.addAll(u2); vids.addAll(v2);
        }
    }

    private void next() {
        if (!alive || uris.isEmpty()) return;
        pos = (pos + 1) % uris.size();
        final int my = ++token;
        if (vids.get(pos)) playVideo(uris.get(pos), my); else showImage(uris.get(pos), my);
    }

    private void showImage(final String uri, final int my) {
        vv.setVisibility(View.GONE);
        new Thread(new Runnable() { public void run() {
            final Bitmap bmp = MyMedia.decode(ScreensaverActivity.this, uri, 1920);
            runOnUiThread(new Runnable() { public void run() {
                if (!alive || my != token) return;
                if (bmp == null) { h.postDelayed(new Runnable() { public void run() { if (alive && my == token) next(); } }, 300); return; }
                transition(bmp);
                long ms = new long[]{5000, 10000, 30000, 60000}[Math.max(0, Math.min(3, Prefs.geti(ScreensaverActivity.this, "sv_slide", 1)))];
                if (uris.size() == 1 && !preview) return;
                h.postDelayed(new Runnable() { public void run() { if (alive && my == token) next(); } }, ms);
            } });
        } }, "decode").start();
    }

    private void transition(Bitmap bmp) {
        ImageView in = img[1 - front], out = img[front];
        in.setImageBitmap(bmp);
        in.setVisibility(View.VISIBLE);
        in.bringToFront();
        overlay.bringToFront();
        in.setScaleX(1f); in.setScaleY(1f);
        int t = Prefs.geti(this, "sv_trans", 0);
        float w = Math.max(1, root.getWidth());
        if (t == 0) { in.setAlpha(0f); in.setTranslationX(0); ObjectAnimator.ofFloat(in, "alpha", 0f, 1f).setDuration(700).start(); }
        else if (t == 1) { in.setAlpha(1f); in.setTranslationX(w); in.animate().translationX(0).setDuration(600).start(); out.animate().translationX(-w).setDuration(600).start(); }
        else { in.setAlpha(1f); in.setTranslationX(0); }
        if (Prefs.getb(this, "sv_kb", false) && Prefs.getb(this, "anim", true) && !Prefs.getb(this, "reduce_motion", false))
            in.animate().scaleX(1.08f).scaleY(1.08f).setDuration(12000).start();
        front = 1 - front;
        out.setImageDrawable(null);
    }

    private void playVideo(final String uri, final int my) {
        for (ImageView i : img) i.setVisibility(View.GONE);
        vv.setVisibility(View.VISIBLE);
        vv.bringToFront();
        overlay.bringToFront();
        vv.setOnPreparedListener(new android.media.MediaPlayer.OnPreparedListener() {
            @Override public void onPrepared(android.media.MediaPlayer mp) { mp.setLooping(uris.size() == 1 && !preview); vv.start(); }
        });
        vv.setOnCompletionListener(new android.media.MediaPlayer.OnCompletionListener() {
            @Override public void onCompletion(android.media.MediaPlayer mp) { if (alive && my == token) next(); }
        });
        vv.setOnErrorListener(new android.media.MediaPlayer.OnErrorListener() {
            @Override public boolean onError(android.media.MediaPlayer mp, int what, int extra) {
                if (alive && my == token) h.postDelayed(new Runnable() { public void run() { if (alive && my == token) next(); } }, 300);
                return true;                      // unsupported format or decoder error: skip quietly
            }
        });
        try { vv.setVideoURI(Uri.parse(uri)); } catch (Throwable t) { next(); }
    }

    @Override public boolean dispatchKeyEvent(KeyEvent e) { if (e.getAction() == KeyEvent.ACTION_UP) finish(); return true; }
    @Override public boolean onTouchEvent(MotionEvent e) { finish(); return true; }
}
