package com.emberhome.launcher;

import android.app.Activity;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.io.File;
import java.util.List;

/** Profile name and picture: 50 built-in avatars, or a photo from Pictures/EmberHome. */
public class ProfileActivity extends Activity {
    private EditText name;
    private TextView photoRow, status;
    private AvatarGrid grid;
    private float d;
    private int dp(int v) { return (int) (v * d + 0.5f); }

    /** 10 x 5 grid of avatars, D-pad navigated. */
    class AvatarGrid extends View {
        static final int COLS = 10;
        int sel = Prefs.avatarId(getContext()) % Avatars.COUNT, foc = sel;
        final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        AvatarGrid(Context c) { super(c); setFocusable(true); setFocusableInTouchMode(true); }
        @Override protected void onMeasure(int w, int h) {
            int ww = MeasureSpec.getSize(w);
            setMeasuredDimension(ww, ww / COLS * (Avatars.COUNT / COLS));
        }
        @Override protected void onDraw(Canvas c) {
            float cell = getWidth() / (float) COLS, r = cell * 0.36f;
            int accent = new int[]{0xFFFFFFFF, 0xFFFFB36B, 0xFF6AA9FF, 0xFF4ADE80, 0xFFFF7AB6, 0xFFB794F6}[Math.max(0, Math.min(5, Prefs.geti(getContext(), "accent", 0)))];
            for (int i = 0; i < Avatars.COUNT; i++) {
                float cx = (i % COLS + .5f) * cell, cy = (i / COLS + .5f) * cell;
                boolean f = hasFocus() && i == foc;
                Avatars.draw(c, i, cx, cy, f ? r * 1.12f : r);
                p.setStyle(Paint.Style.STROKE);
                if (f) { p.setStrokeWidth(dp(4)); p.setColor(accent); c.drawCircle(cx, cy, r * 1.12f + dp(4), p); }
                else if (i == sel && Prefs.avatarPath(getContext()).length() == 0) { p.setStrokeWidth(dp(3)); p.setColor(0xFF4ADE80); c.drawCircle(cx, cy, r + dp(4), p); }
            }
        }
        @Override protected void onFocusChanged(boolean g, int dir, android.graphics.Rect r) { super.onFocusChanged(g, dir, r); invalidate(); }
        @Override public boolean onKeyDown(int code, KeyEvent e) {
            int rows = Avatars.COUNT / COLS;
            switch (code) {
                case KeyEvent.KEYCODE_DPAD_LEFT: if (foc % COLS > 0) foc--; invalidate(); return true;
                case KeyEvent.KEYCODE_DPAD_RIGHT: if (foc % COLS < COLS - 1) foc++; invalidate(); return true;
                case KeyEvent.KEYCODE_DPAD_UP: if (foc / COLS > 0) { foc -= COLS; invalidate(); return true; } return false;
                case KeyEvent.KEYCODE_DPAD_DOWN: if (foc / COLS < rows - 1) { foc += COLS; invalidate(); return true; } return false;
                case KeyEvent.KEYCODE_DPAD_CENTER:
                case KeyEvent.KEYCODE_ENTER:
                    sel = foc;
                    Prefs.puti(getContext(), "avatar_id", sel);
                    Prefs.setAvatarPath(getContext(), "");
                    refresh();
                    invalidate();
                    return true;
            }
            return super.onKeyDown(code, e);
        }
    }

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        d = getResources().getDisplayMetrics().density;
        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(0xFF0B0C10);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setPadding(dp(40), dp(32), dp(40), dp(24));
        sv.addView(root, new ViewGroup.LayoutParams(-1, -2));
        TextView title = text("Profile", 30, true, Color.WHITE);
        root.addView(title, new LinearLayout.LayoutParams(dp(720), -2));
        name = new EditText(this);
        name.setHint("Your name"); name.setHintTextColor(0x80FFFFFF); name.setTextColor(Color.WHITE); name.setTextSize(22);
        name.setSingleLine(true); name.setText(Prefs.profileName(this));
        LinearLayout.LayoutParams np = new LinearLayout.LayoutParams(dp(720), -2);
        np.topMargin = dp(10);
        root.addView(name, np);
        TextView pick = text("Choose a picture", 16, true, 0xB3FFFFFF);
        LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(dp(720), -2);
        pp.topMargin = dp(14); pp.bottomMargin = dp(6);
        root.addView(pick, pp);
        grid = new AvatarGrid(this);
        root.addView(grid, new LinearLayout.LayoutParams(dp(720), -2));
        photoRow = text("", 18, true, Color.WHITE);
        photoRow.setPadding(dp(20), dp(12), dp(20), dp(12));
        photoRow.setFocusable(true); photoRow.setClickable(true);
        box(photoRow, false);
        photoRow.setOnFocusChangeListener(new View.OnFocusChangeListener() { @Override public void onFocusChange(View v, boolean f) { box(photoRow, f); } });
        photoRow.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { cyclePhoto(); } });
        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(dp(720), -2);
        rp.topMargin = dp(12);
        root.addView(photoRow, rp);
        status = text("To use your own photo, copy pictures to  Pictures/EmberHome  on the TV. Pressing OK above cycles through them.", 14, false, 0x99FFFFFF);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(dp(720), -2);
        sp.topMargin = dp(10);
        root.addView(status, sp);
        setContentView(sv);
        refresh();
        grid.requestFocus();
    }

    @Override protected void onPause() {
        super.onPause();
        Prefs.setProfileName(this, name.getText().toString().trim());
    }

    private TextView text(String s, int sp, boolean bold, int col) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(sp); t.setTextColor(col);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private void box(TextView t, boolean f) {
        GradientDrawable g = new GradientDrawable();
        g.setCornerRadius(dp(14));
        g.setColor(f ? Color.WHITE : 0xFF161922);
        t.setBackgroundDrawable(g);
        t.setTextColor(f ? 0xFF111111 : Color.WHITE);
    }

    private void cyclePhoto() {
        List<File> fs = Wallpapers.userFiles();
        String cur = Prefs.avatarPath(this), next = "";
        if (cur.length() == 0) { if (!fs.isEmpty()) next = fs.get(0).getAbsolutePath(); }
        else for (int i = 0; i < fs.size(); i++) if (fs.get(i).getAbsolutePath().equals(cur)) next = i + 1 < fs.size() ? fs.get(i + 1).getAbsolutePath() : "";
        Prefs.setAvatarPath(this, next);
        refresh();
        grid.invalidate();
    }

    private void refresh() {
        String p = Prefs.avatarPath(this);
        photoRow.setText("Use a photo:  " + (p.length() == 0 ? "None (using built-in picture " + (Prefs.avatarId(this) + 1) + " of 50)" : new File(p).getName()) + "   (OK to change)");
    }
}
