package com.emberhome.launcher;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

/** Full-screen gallery. Left/Right browse, Up/Down category, OK apply, Back return. */
public class WallpaperActivity extends Activity {
    private View bg;
    private TextView hint, empty;
    private final TextView[] cats = new TextView[Wallpapers.CATS.length];
    private int cat, idx;
    private float d;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        d = getResources().getDisplayMetrics().density;
        FrameLayout root = new FrameLayout(this);
        bg = new View(this);
        root.addView(bg, new ViewGroup.LayoutParams(-1, -1));
        LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        for (int i = 0; i < cats.length; i++) {
            cats[i] = new TextView(this);
            cats[i].setText(Wallpapers.CATS[i]);
            cats[i].setTextSize(17);
            cats[i].setTypeface(Typeface.DEFAULT_BOLD);
            cats[i].setPadding(dp(16), dp(8), dp(16), dp(8));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(220), -2);
            lp.bottomMargin = dp(6);
            list.addView(cats[i], lp);
        }
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(-2, -2, Gravity.TOP | Gravity.LEFT);
        lp.setMargins(dp(40), dp(40), 0, 0);
        root.addView(list, lp);
        hint = new TextView(this);
        hint.setTextColor(Color.WHITE); hint.setTextSize(16); hint.setTypeface(Typeface.DEFAULT_BOLD);
        hint.setPadding(dp(22), dp(10), dp(22), dp(10));
        hint.setBackgroundColor(0x99000000);
        FrameLayout.LayoutParams hp = new FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
        hp.bottomMargin = dp(36);
        root.addView(hint, hp);
        empty = new TextView(this);
        empty.setTextColor(Color.WHITE); empty.setTextSize(18); empty.setGravity(Gravity.CENTER);
        empty.setText("Copy your pictures to  Pictures/EmberHome  on the device, then come back.");
        root.addView(empty, new FrameLayout.LayoutParams(-1, -1));
        setContentView(root);
        root.setFocusable(true);
        root.requestFocus();
        show();
    }

    private int dp(int v) { return (int) (v * d + 0.5f); }

    private void show() {
        int n = Wallpapers.count(cat);
        if (idx >= n) idx = Math.max(0, n - 1);
        empty.setVisibility(n == 0 ? View.VISIBLE : View.GONE);
        bg.setBackgroundDrawable(n == 0 ? null : Wallpapers.get(this, cat, idx));
        if (n == 0) bg.setBackgroundColor(0xFF111827);
        for (int i = 0; i < cats.length; i++) {
            boolean on = i == cat;
            cats[i].setTextColor(on ? 0xFF111111 : Color.WHITE);
            GradientDrawable g = new GradientDrawable();
            g.setColor(on ? Color.WHITE : 0x59000000); g.setCornerRadius(dp(12));
            cats[i].setBackgroundDrawable(g);
        }
        boolean applied = n > 0 && Prefs.wall(this).equals(Wallpapers.key(cat, idx));
        hint.setText(n == 0 ? "▲▼ category · Back" : "◀ " + Wallpapers.CATS[cat] + " " + (idx + 1) + "/" + n + " ▶  ·  ▲▼ category  ·  OK " + (applied ? "✓ Applied" : "Apply") + "  ·  Back");
    }

    @Override public boolean onKeyDown(int code, KeyEvent e) {
        int n = Wallpapers.count(cat);
        switch (code) {
            case KeyEvent.KEYCODE_DPAD_LEFT: idx = Math.max(0, idx - 1); break;
            case KeyEvent.KEYCODE_DPAD_RIGHT: idx = Math.min(Math.max(0, n - 1), idx + 1); break;
            case KeyEvent.KEYCODE_DPAD_UP: cat = Math.max(0, cat - 1); idx = 0; break;
            case KeyEvent.KEYCODE_DPAD_DOWN: cat = Math.min(cats.length - 1, cat + 1); idx = 0; break;
            case KeyEvent.KEYCODE_DPAD_CENTER:
            case KeyEvent.KEYCODE_ENTER:
                if (n > 0) { Prefs.setWall(this, Wallpapers.key(cat, idx)); Toast.makeText(this, "Wallpaper applied", Toast.LENGTH_SHORT).show(); }
                break;
            default: return super.onKeyDown(code, e);
        }
        show();
        return true;
    }
}
