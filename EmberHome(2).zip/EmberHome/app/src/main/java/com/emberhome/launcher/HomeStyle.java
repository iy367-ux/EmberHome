package com.emberhome.launcher;

public enum HomeStyle {
    EMBER("ember", "Ember Dock", new int[]{0xFF1C1030, 0xFF7B2D3C, 0xFFF0873A}),
    CINEMA("cinema", "Cinema Rail", new int[]{0xFF0D0F14, 0xFF161922, 0xFFC4572A}),
    GLASS("glass", "Glass (tvOS)", new int[]{0xFF1B2A55, 0xFF6B4FA0, 0xFFF2B5A0}),
    GTV("gtv", "Google TV", new int[]{0xFF0B0C10, 0xFF1F2A44, 0xFF7F5AF0});

    public final String key, label;
    public final int[] preview;
    HomeStyle(String key, String label, int[] preview) { this.key = key; this.label = label; this.preview = preview; }

    public static HomeStyle fromKey(String k) {
        for (HomeStyle s : values()) if (s.key.equals(k)) return s;
        return EMBER;
    }
}
