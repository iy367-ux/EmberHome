package com.emberhome.launcher;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ColorFilter;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.RadialGradient;
import android.graphics.Rect;
import android.graphics.Shader;
import android.graphics.drawable.Drawable;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * Hand-built illustrated wallpaper (sky, sun/moon, stars, clouds, aurora, water, mountains, pines, snow caps,
 * city skylines with lit windows). Rendered once into a 1280x720 bitmap and reused.
 */
public class SceneDrawable extends Drawable {
    private static class Layer { boolean city, snow; int color, trees, fog, win; float base, amp, step, min, max, bot; }

    private final long seed;
    private final float hy;
    private final int[] sky;
    private float sunX, sunY, sunR, moonX, moonY, moonR;
    private int sunC, stars, clouds, cloudC = 0xFFFFFFFF, wc1, wc2;
    private boolean aurora, birds, water;
    private final List<Layer> layers = new ArrayList<Layer>();
    private Bitmap cache;
    private final Paint blit = new Paint(Paint.FILTER_BITMAP_FLAG);

    public SceneDrawable(long seed, float horizon, String... skyColors) {
        this.seed = seed; this.hy = horizon;
        sky = new int[skyColors.length];
        for (int i = 0; i < sky.length; i++) sky[i] = Color.parseColor(skyColors[i]);
    }
    public SceneDrawable sun(float x, float y, float r, String c) { sunX = x; sunY = y; sunR = r; sunC = Color.parseColor(c); return this; }
    public SceneDrawable moon(float x, float y, float r) { moonX = x; moonY = y; moonR = r; return this; }
    public SceneDrawable stars(int n) { stars = n; return this; }
    public SceneDrawable clouds(int n, String c) { clouds = n; cloudC = Color.parseColor(c); return this; }
    public SceneDrawable aurora() { aurora = true; return this; }
    public SceneDrawable birds() { birds = true; return this; }
    public SceneDrawable water(String top, String bottom) { water = true; wc1 = Color.parseColor(top); wc2 = Color.parseColor(bottom); return this; }
    public SceneDrawable hills(String c, float base, float amp, float step, int trees, boolean snow, String fog, float bot) {
        Layer l = new Layer(); l.color = Color.parseColor(c); l.base = base; l.amp = amp; l.step = step; l.trees = trees; l.snow = snow;
        l.fog = fog == null ? 0 : Color.parseColor(fog); l.bot = bot == 0 ? 720 : bot; layers.add(l); return this;
    }
    public SceneDrawable city(String c, float base, float min, float max, String win, float bot) {
        Layer l = new Layer(); l.city = true; l.color = Color.parseColor(c); l.base = base; l.min = min; l.max = max;
        l.win = win == null ? 0 : Color.parseColor(win); l.bot = bot == 0 ? 720 : bot; layers.add(l); return this;
    }

    private static int a(int color, float alpha) { return (color & 0xFFFFFF) | ((int) (alpha * 255) << 24); }

    private void render(Canvas c) {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        Random r = new Random(seed);
        p.setShader(new LinearGradient(0, 0, 0, 720, sky, null, Shader.TileMode.CLAMP));
        c.drawRect(0, 0, 1280, 720, p);
        p.setShader(null);
        for (int i = 0; i < stars; i++) {
            p.setColor(a(0xFFFFFFFF, .3f + r.nextFloat() * .6f));
            c.drawCircle(r.nextFloat() * 1280, r.nextFloat() * hy * .8f, .6f + r.nextFloat() * 1.3f, p);
        }
        if (aurora) { glowEllipse(c, p, 480, 170, 420, 36, 0x993DFFB0, -8); glowEllipse(c, p, 840, 140, 360, 30, 0x999B6BFF, 6); }
        if (sunR > 0) { glow(c, p, sunX, sunY, sunR * 5, sunC); p.setShader(null); p.setColor(sunC); c.drawCircle(sunX, sunY, sunR, p); }
        if (moonR > 0) { glow(c, p, moonX, moonY, moonR * 3, 0xFFF6F1DE); p.setShader(null); p.setColor(0xFFF6F1DE); c.drawCircle(moonX, moonY, moonR, p); }
        for (int i = 0; i < clouds; i++) {
            float x = r.nextFloat() * 1280, y = 60 + r.nextFloat() * hy * .45f, rx = 160 + r.nextFloat() * 160, ry = 14 + r.nextFloat() * 14;
            glowEllipse(c, p, x, y, rx, ry, a(cloudC, .12f + r.nextFloat() * .16f), 0);
        }
        if (water) {
            p.setShader(new LinearGradient(0, hy, 0, 720, wc1, wc2, Shader.TileMode.CLAMP));
            c.drawRect(0, hy, 1280, 720, p);
            p.setShader(null);
            if (sunR > 0) for (int i = 0; i < 6; i++) {
                p.setColor(a(sunC, .35f));
                float w = sunR * (1 - i * .12f);
                c.drawRoundRect(new android.graphics.RectF(sunX - w, hy + 8 + i * 22, sunX + w, hy + 13 + i * 22), 2.5f, 2.5f, p);
            }
        }
        int li = 0;
        for (Layer L : layers) { drawLayer(c, p, L, new Random(seed * 7 + li * 13 + 3)); li++; }
        if (birds) {
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(2); p.setColor(0xFF1A0F2A);
            for (int i = 0; i < 5; i++) {
                float x = 300 + r.nextFloat() * 600, y = 110 + r.nextFloat() * 120;
                Path b = new Path(); b.moveTo(x, y); b.quadTo(x + 8, y - 8, x + 16, y); b.quadTo(x + 24, y - 8, x + 32, y);
                c.drawPath(b, p);
            }
            p.setStyle(Paint.Style.FILL);
        }
    }

    private void glow(Canvas c, Paint p, float x, float y, float rad, int col) {
        p.setShader(new RadialGradient(x, y, rad, new int[]{a(col, .9f), a(col, .4f), a(col, 0f)}, new float[]{0, .3f, 1}, Shader.TileMode.CLAMP));
        c.drawCircle(x, y, rad, p);
        p.setShader(null);
    }

    private void glowEllipse(Canvas c, Paint p, float x, float y, float rx, float ry, int col, float rot) {
        c.save();
        c.rotate(rot, x, y);
        c.scale(1f, ry / rx, x, y);
        p.setShader(new RadialGradient(x, y, rx, new int[]{col, a(col, 0f)}, null, Shader.TileMode.CLAMP));
        c.drawCircle(x, y, rx, p);
        p.setShader(null);
        c.restore();
    }

    private void drawLayer(Canvas c, Paint p, Layer L, Random q) {
        p.setColor(L.color);
        if (L.city) {
            float x = -10;
            while (x < 1280) {
                float w = 34 + q.nextFloat() * 60, h = L.min + q.nextFloat() * (L.max - L.min), y = L.base - h;
                p.setColor(L.color);
                c.drawRect(x, y, x + w, L.bot, p);
                if (L.win != 0) for (float wy = y + 10; wy < L.base - 8; wy += 14) for (float wx = x + 6; wx < x + w - 8; wx += 11)
                    if (q.nextFloat() < .34f) { p.setColor(a(L.win, .5f + q.nextFloat() * .5f)); c.drawRect(wx, wy, wx + 5, wy + 7, p); }
                x += w + q.nextInt(4);
            }
            return;
        }
        int n = (int) (1280 / L.step) + 2;
        float[] px = new float[n], py = new float[n];
        for (int i = 0; i < n; i++) { px[i] = i * L.step; py[i] = L.base - q.nextFloat() * L.amp; }
        Path path = new Path();
        path.moveTo(0, L.bot);
        for (int i = 0; i < n; i++) path.lineTo(px[i], py[i]);
        path.lineTo(1280 + L.step, L.bot);
        path.close();
        c.drawPath(path, p);
        if (L.snow) {
            p.setColor(0xEBEEF3F8);
            for (int i = 0; i < n; i++) if (py[i] < L.base - L.amp * .55f) {
                Path s = new Path();
                s.moveTo(px[i] - 34, py[i] + 28); s.lineTo(px[i], py[i]); s.lineTo(px[i] + 34, py[i] + 28);
                s.lineTo(px[i] + 13, py[i] + 20); s.lineTo(px[i], py[i] + 32); s.lineTo(px[i] - 13, py[i] + 20);
                s.close(); c.drawPath(s, p);
            }
        }
        if (L.trees > 0) {
            p.setColor(L.color);
            for (float tx = 0; tx < 1280; tx += L.trees) {
                int i = Math.min(n - 2, (int) (tx / L.step));
                float f = (tx % L.step) / L.step, ty = py[i] + (py[i + 1] - py[i]) * f, th = 26 + q.nextFloat() * 34;
                Path t = new Path();
                t.moveTo(tx - th * .3f, ty + th); t.lineTo(tx, ty - th * .2f); t.lineTo(tx + th * .3f, ty + th);
                t.close(); c.drawPath(t, p);
            }
        }
        if (L.fog != 0) {
            p.setShader(new LinearGradient(0, L.base - 110, 0, L.base + 40, new int[]{a(L.fog, 0f), a(L.fog, .4f), a(L.fog, 0f)}, null, Shader.TileMode.CLAMP));
            c.drawRect(0, L.base - 110, 1280, L.base + 40, p);
            p.setShader(null);
        }
    }

    @Override public void draw(Canvas c) {
        if (cache == null) {
            cache = Bitmap.createBitmap(1280, 720, Bitmap.Config.ARGB_8888);
            render(new Canvas(cache));
        }
        c.drawBitmap(cache, null, getBounds(), blit);
    }

    @Override public void setAlpha(int a) {}
    @Override public void setColorFilter(ColorFilter f) {}
    @Override public int getOpacity() { return PixelFormat.OPAQUE; }
}
