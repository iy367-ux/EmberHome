package com.emberhome.launcher;

import android.content.Context;
import android.location.Location;
import android.location.LocationManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.InetAddress;
import java.net.Socket;
import java.net.URL;
import java.net.URLEncoder;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.SSLSocketFactory;

/**
 * Compact weather from Open-Meteo (https://open-meteo.com, data licensed CC BY 4.0, free API is for NON-COMMERCIAL use).
 * Only the fields the UI needs are requested. The last good response is cached; failures never invent readings.
 */
public final class Weather {
    private Weather() {}

    public static final int SUN = 0, MOON = 1, PARTLY = 2, PARTLY_NIGHT = 3, CLOUD = 4, RAIN = 5, STORM = 6, SNOW = 7, FOG = 8;
    private static final long[] INTERVALS = {30 * 60000L, 60 * 60000L, 3 * 3600000L};
    private static volatile boolean busy;
    public static volatile String status = "";

    public static class Now {
        public int code, temp, hum, wind;
        public boolean day, stale;
        public long time;
        public JSONObject raw;
    }

    private static boolean fahrenheit(Context c) { return Prefs.getb(c, "w_f", false); }
    private static String key(Context c, double[] ll) { return ll == null ? "" : ll[0] + "," + ll[1] + "," + fahrenheit(c); }

    // ---------- location ----------
    public static double[] location(Context c) {
        if (Prefs.geti(c, "w_mode", 0) == 0) {                         // automatic
            try {
                LocationManager lm = (LocationManager) c.getSystemService(Context.LOCATION_SERVICE);
                Location best = null;
                for (String pr : lm.getProviders(true)) {
                    Location l = lm.getLastKnownLocation(pr);
                    if (l != null && (best == null || l.getTime() > best.getTime())) best = l;
                }
                if (best != null) return new double[]{best.getLatitude(), best.getLongitude()};
            } catch (Throwable t) { /* no permission or no provider: fall back to the manual city */ }
        }
        String lat = Prefs.gets(c, "w_lat", ""), lon = Prefs.gets(c, "w_lon", "");
        try { if (lat.length() > 0 && lon.length() > 0) return new double[]{Double.parseDouble(lat), Double.parseDouble(lon)}; }
        catch (NumberFormatException e) { /* ignore */ }
        return null;
    }

    /** Blocking: resolve a city name with the Open-Meteo geocoding API. Call from a background thread. */
    public static String geocode(Context c, String name) throws Exception {
        String u = "https://geocoding-api.open-meteo.com/v1/search?count=1&language=en&format=json&name=" + URLEncoder.encode(name, "UTF-8");
        JSONObject o = new JSONObject(get(u));
        JSONArray r = o.optJSONArray("results");
        if (r == null || r.length() == 0) return null;
        JSONObject f = r.getJSONObject(0);
        String label = f.optString("name") + (f.optString("country").length() > 0 ? ", " + f.optString("country") : "");
        Prefs.puts(c, "w_lat", String.valueOf(f.getDouble("latitude")));
        Prefs.puts(c, "w_lon", String.valueOf(f.getDouble("longitude")));
        Prefs.puts(c, "w_city", label);
        Prefs.puts(c, "w_cache_key", "");
        return label;
    }

    // ---------- cache + refresh ----------
    public static Now cached(Context c) {
        String js = Prefs.gets(c, "w_json", "");
        if (js.length() == 0) return null;
        try {
            JSONObject o = new JSONObject(js), cur = o.getJSONObject("current");
            Now n = new Now();
            n.raw = o;
            n.code = cur.optInt("weather_code");
            n.day = cur.optInt("is_day", 1) == 1;
            n.temp = (int) Math.round(cur.optDouble("temperature_2m"));
            n.hum = (int) Math.round(cur.optDouble("relative_humidity_2m"));
            n.wind = (int) Math.round(cur.optDouble("wind_speed_10m"));
            n.time = Prefs.getl(c, "w_ts", 0);
            n.stale = System.currentTimeMillis() - n.time > 2 * INTERVALS[Math.max(0, Math.min(2, Prefs.geti(c, "w_int", 1)))];
            return n;
        } catch (Exception e) { return null; }
    }

    private static boolean due(Context c) {
        double[] ll = location(c);
        if (ll == null) return false;
        if (!key(c, ll).equals(Prefs.gets(c, "w_cache_key", ""))) return true;
        long age = System.currentTimeMillis() - Prefs.getl(c, "w_ts", 0);
        return age < 0 || age > INTERVALS[Math.max(0, Math.min(2, Prefs.geti(c, "w_int", 1)))];
    }

    /** Fetches only when needed (or when forced). Never blocks the UI; done runs on the main thread. */
    public static void refresh(final Context ctx, final boolean force, final Runnable done) {
        final Context c = ctx.getApplicationContext();
        if (busy || (!force && !due(c))) return;
        final double[] ll = location(c);
        if (ll == null) { status = "No location set"; return; }
        busy = true;
        new Thread(new Runnable() {
            @Override public void run() {
                try {
                    boolean f = fahrenheit(c);
                    String u = "https://api.open-meteo.com/v1/forecast?latitude=" + ll[0] + "&longitude=" + ll[1]
                            + "&current=temperature_2m,relative_humidity_2m,weather_code,wind_speed_10m,is_day"
                            + "&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max"
                            + "&forecast_days=3&timezone=auto&temperature_unit=" + (f ? "fahrenheit" : "celsius")
                            + "&wind_speed_unit=" + (f ? "mph" : "kmh");
                    String body = get(u);
                    new JSONObject(body).getJSONObject("current");      // validate before caching
                    Prefs.puts(c, "w_json", body);
                    Prefs.putl(c, "w_ts", System.currentTimeMillis());
                    Prefs.puts(c, "w_cache_key", key(c, ll));
                    status = "Updated";
                } catch (Throwable t) {
                    status = "Offline: showing last reading";
                } finally {
                    busy = false;
                    if (done != null) new Handler(Looper.getMainLooper()).post(done);
                }
            }
        }, "weather").start();
    }

    // ---------- presentation ----------
    public static int kind(int code, boolean day) {
        if (code == 0 || code == 1) return day ? SUN : MOON;
        if (code == 2) return day ? PARTLY : PARTLY_NIGHT;
        if (code == 3) return CLOUD;
        if (code == 45 || code == 48) return FOG;
        if (code >= 95) return STORM;
        if ((code >= 71 && code <= 77) || code == 85 || code == 86) return SNOW;
        if ((code >= 51 && code <= 67) || (code >= 80 && code <= 82)) return RAIN;
        return CLOUD;
    }

    public static String describe(int code) {
        switch (code) {
            case 0: return "Clear sky";
            case 1: return "Mainly clear";
            case 2: return "Partly cloudy";
            case 3: return "Overcast";
            case 45: case 48: return "Fog";
            case 51: case 53: case 55: return "Drizzle";
            case 56: case 57: return "Freezing drizzle";
            case 61: case 63: case 65: return "Rain";
            case 66: case 67: return "Freezing rain";
            case 71: case 73: case 75: case 77: return "Snow";
            case 80: case 81: case 82: return "Rain showers";
            case 85: case 86: return "Snow showers";
            case 95: return "Thunderstorm";
            case 96: case 99: return "Thunderstorm with hail";
            default: return "Unknown";
        }
    }

    public static String tempText(Context c, Now n) { return n.temp + (fahrenheit(c) ? "°F" : "°C"); }

    public static String details(Context c) {
        Now n = cached(c);
        if (n == null) return "No weather data yet.\n" + (status.length() > 0 ? status : "Set a city in Settings > Weather.");
        boolean f = fahrenheit(c);
        StringBuilder b = new StringBuilder();
        String city = Prefs.gets(c, "w_city", "");
        if (city.length() > 0 && Prefs.geti(c, "w_mode", 0) == 1) b.append(city).append("\n");
        b.append(tempText(c, n)).append("  ").append(describe(n.code)).append("\n");
        if (Prefs.getb(c, "w_wind", true)) b.append("Wind ").append(n.wind).append(f ? " mph" : " km/h").append("\n");
        if (Prefs.getb(c, "w_hum", true)) b.append("Humidity ").append(n.hum).append("%\n");
        try {
            JSONObject d = n.raw.getJSONObject("daily");
            int days = Prefs.geti(c, "w_days", 1) == 0 ? 1 : 3;
            String[] names = {"Today", "Tomorrow", "Day after"};
            for (int i = 0; i < days; i++) {
                b.append("\n").append(names[i]).append(": ").append(describe(d.getJSONArray("weather_code").getInt(i)))
                        .append(", ").append(Math.round(d.getJSONArray("temperature_2m_min").getDouble(i))).append("° to ")
                        .append(Math.round(d.getJSONArray("temperature_2m_max").getDouble(i))).append("°");
                if (Prefs.getb(c, "w_pre", true)) b.append(", rain chance ").append(d.getJSONArray("precipitation_probability_max").optInt(i)).append("%");
            }
        } catch (Exception e) { /* no forecast in cache */ }
        long age = (System.currentTimeMillis() - n.time) / 60000;
        b.append("\n\nUpdated ").append(age < 1 ? "just now" : age + " min ago").append(n.stale ? " (old data)" : "");
        if (status.length() > 0) b.append("\n").append(status);
        b.append("\nWeather data by Open-Meteo.com (CC BY 4.0)");
        return b.toString();
    }

    // ---------- network ----------
    /** 0 = none, 1 = Wi-Fi, 2 = Ethernet, 3 = other. */
    public static int netType(Context c) {
        try {
            NetworkInfo ni = ((ConnectivityManager) c.getSystemService(Context.CONNECTIVITY_SERVICE)).getActiveNetworkInfo();
            if (ni == null || !ni.isConnected()) return 0;
            int t = ni.getType();
            return t == ConnectivityManager.TYPE_WIFI ? 1 : t == 9 ? 2 : 3;
        } catch (Throwable t) { return 0; }
    }

    // ---------- HTTP (TLS 1.2 is switched off by default on Android 4.x, so enable it) ----------
    private static SSLSocketFactory tls;

    static String get(String u) throws Exception {
        HttpURLConnection h = (HttpURLConnection) new URL(u).openConnection();
        if (h instanceof HttpsURLConnection && Build.VERSION.SDK_INT < 21) {
            if (tls == null) { SSLContext ctx = SSLContext.getInstance("TLSv1.2"); ctx.init(null, null, null); tls = new Tls12(ctx.getSocketFactory()); }
            ((HttpsURLConnection) h).setSSLSocketFactory(tls);
        }
        h.setConnectTimeout(10000);
        h.setReadTimeout(10000);
        h.setRequestProperty("User-Agent", "EmberHome/1.1");
        if (h.getResponseCode() != 200) throw new IOException("HTTP " + h.getResponseCode());
        InputStream in = h.getInputStream();
        ByteArrayOutputStream o = new ByteArrayOutputStream();
        byte[] buf = new byte[4096];
        int n;
        while ((n = in.read(buf)) > 0) o.write(buf, 0, n);
        in.close();
        h.disconnect();
        return o.toString("UTF-8");
    }

    private static class Tls12 extends SSLSocketFactory {
        private final SSLSocketFactory d;
        Tls12(SSLSocketFactory d) { this.d = d; }
        private Socket fix(Socket s) {
            if (s instanceof SSLSocket) ((SSLSocket) s).setEnabledProtocols(new String[]{"TLSv1.1", "TLSv1.2"});
            return s;
        }
        @Override public String[] getDefaultCipherSuites() { return d.getDefaultCipherSuites(); }
        @Override public String[] getSupportedCipherSuites() { return d.getSupportedCipherSuites(); }
        @Override public Socket createSocket(Socket s, String h, int p, boolean a) throws IOException { return fix(d.createSocket(s, h, p, a)); }
        @Override public Socket createSocket(String h, int p) throws IOException { return fix(d.createSocket(h, p)); }
        @Override public Socket createSocket(String h, int p, InetAddress la, int lp) throws IOException { return fix(d.createSocket(h, p, la, lp)); }
        @Override public Socket createSocket(InetAddress h, int p) throws IOException { return fix(d.createSocket(h, p)); }
        @Override public Socket createSocket(InetAddress a, int p, InetAddress la, int lp) throws IOException { return fix(d.createSocket(a, p, la, lp)); }
    }
}
