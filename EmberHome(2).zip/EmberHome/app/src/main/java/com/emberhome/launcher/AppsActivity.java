package com.emberhome.launcher;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.util.List;

/** Show or hide apps on the home screen. Hidden apps stay installed. */
public class AppsActivity extends Activity {
    private float d;
    private int dp(int v) { return (int) (v * d + 0.5f); }

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        d = getResources().getDisplayMetrics().density;
        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(0xFF0D0F14);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(120), dp(32), dp(120), dp(32));
        sv.addView(root, new ViewGroup.LayoutParams(-1, -2));
        TextView title = new TextView(this);
        title.setText("Manage apps"); title.setTextSize(28); title.setTextColor(Color.WHITE); title.setTypeface(Typeface.DEFAULT_BOLD);
        root.addView(title);
        TextView sub = new TextView(this);
        sub.setText("OK cycles: On home screen, Favourite, Hidden. Hidden apps stay installed."); sub.setTextSize(15); sub.setTextColor(0xB3FFFFFF);
        root.addView(sub);
        List<AppEntry> all = AppRepo.all(this);
        View first = null;
        for (final AppEntry a : all) {
            final TextView t = new TextView(this);
            t.setTextSize(18); t.setTextColor(Color.WHITE); t.setTypeface(Typeface.DEFAULT_BOLD);
            t.setGravity(Gravity.CENTER_VERTICAL);
            t.setCompoundDrawablePadding(dp(16));
            t.setPadding(dp(16), dp(8), dp(16), dp(8));
            Drawable ic = a.icon;
            if (ic != null) { ic.setBounds(0, 0, dp(48), dp(48)); t.setCompoundDrawables(ic, null, null, null); }
            t.setFocusable(true); t.setClickable(true);
            label(t, a);
            focusBg(t, false);
            t.setOnFocusChangeListener(new View.OnFocusChangeListener() { @Override public void onFocusChange(View v, boolean f) { focusBg(t, f); } });
            t.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    boolean hid = Prefs.isHidden(AppsActivity.this, a.pkg), fav = Prefs.inList(AppsActivity.this, "fav", a.pkg);
                    // cycle: on home -> favourite -> hidden -> on home
                    if (hid) { Prefs.setHidden(AppsActivity.this, a.pkg, false); }
                    else if (fav) { Prefs.setInList(AppsActivity.this, "fav", a.pkg, false); Prefs.setHidden(AppsActivity.this, a.pkg, true); }
                    else Prefs.setInList(AppsActivity.this, "fav", a.pkg, true);
                    label(t, a);
                }
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
            lp.topMargin = dp(8);
            root.addView(t, lp);
            if (first == null) first = t;
        }
        setContentView(sv);
        if (first != null) first.requestFocus();
    }

    private void label(TextView t, AppEntry a) {
        boolean h = Prefs.isHidden(this, a.pkg);
        boolean fav = Prefs.inList(this, "fav", a.pkg);
        t.setText(a.label + "     " + (h ? "Hidden" : fav ? "★ Favourite" : "On home screen"));
        t.setAlpha(h ? 0.55f : 1f);
    }

    private void focusBg(View v, boolean f) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(f ? 0xFF222738 : 0xFF161922); g.setCornerRadius(dp(14));
        if (f) g.setStroke(dp(3), Color.WHITE);
        v.setBackgroundDrawable(g);
    }
}
