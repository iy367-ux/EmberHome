# Changelog (v1.1 final API 19 release)

## Added
- Settings: two-pane layout, 8 categories, 50+ working settings (all persisted in SharedPreferences), remembered position per category.
- Compact weather indicator (icon + temperature) opposite the clock, plus Wi-Fi/Ethernet icon. Open-Meteo geocoding + forecast, WMO code mapping,
  cache, interval refresh, offline fallback, Celsius/Fahrenheit, details dialog with wind/humidity/rain chance/3-day forecast.
- Screensaver Gallery (Clocks, Ambient, Cinematic, My Screensavers) with live thumbnails and preview.
- 7 native clocks (Minimal Digital, Classic Analog, Flip, World, Typography, Ambient Glow, Word), size/position/colour/date/seconds/12-24h, auto-rotation.
- 5 ambient scenes (Flowing Gradients, Ambient Glow, Floating Particles, Geometric Motion, Cosmic Journey) with intensity and frame-rate options.
- Photo/video slideshow player (fade/slide/none, random/sequential, optional slow zoom, clock/date/weather overlays), video via VideoView with error skipping.
- My Screensavers: document-picker import (persistable access) + folder scan, enable/disable, remove without deleting files.
- Cinematic Library framework: licence-tracked catalogue, user-initiated downloads (resume, cancel, retry, storage check, Wi-Fi/Ethernet only, duplicate guard).
- 50 built-in profile pictures (25 drawn symbols x 2 colour treatments), profile name, optional photo.
- Accessibility: text size, high contrast, stronger focus, reduce motion, larger controls (Settings rows), UI sounds.
- Applications: favourites, sort order (custom / A-Z / newest), favourites first, Android shortcut intents.
- Home: accent colour, background dimming, icon size, layout density, animation switch.
## Changed
- Idle timeout and screensaver switch now come from the new settings keys; screensaver stops after a chosen time so the TV can sleep.
- AppRepo no longer calls an API 20 method directly (found by compiling against the API 19 library).
## Not changed
- minSdk 19, targetSdk 28, compileSdk 33, Gradle/AGP versions, workflow. The legacy branch is not part of this project folder and was not touched.
## Not implemented (deliberately)
- Automatic update checking (no update mechanism exists). Idle "brightness" is implemented as window brightness only, which some TVs ignore.
- Pause/resume of downloads is implemented as cancel + resume-from-partial. Download quality levels exist only when a catalogue item defines them.
- Playlists beyond "all enabled items". EXIF rotation. Screensaver weather overlay uses the cached reading only.
