# Media licence record

Every bundled or downloadable cinematic item must be listed here AND in `assets/cinematic_catalog.json`.

| id | title | creator | licence (+ URL) | source URL | verified by / date | redistribution + commercial use confirmed |
|----|-------|---------|-----------------|------------|--------------------|-------------------------------------------|
| (none) | No media is bundled in this release | | | | | |

Checklist before adding an item: read the licence text for that single asset; confirm redistribution inside an app and commercial use are allowed;
confirm attribution requirements; for NASA material check for third-party credits and publicity restrictions; never rely on a whole website being "free".
