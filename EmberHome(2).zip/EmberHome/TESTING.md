# Testing record (honest)

Performed in the author's build environment (no TV, no emulator, no Gradle):
| Test | Result |
|------|--------|
| All Java sources compile against the **Android API 19 android.jar** (javac, -source 8) | PASS (0 errors); this also proves no API 20+ method is called directly |
| Static checks: WMO weather-code -> icon/description mapping; all 25 avatar glyph specs well-formed and in range; 50 distinct avatars | PASS |
| AndroidManifest.xml well-formed; every activity class exists; catalogue JSON valid | PASS |
| Every Settings key (51) is read by launcher code (the "Larger controls" key is read by Settings itself) | PASS |

NOT performed (so not claimed): Gradle build / APK, installation on any device, remote-control focus testing, preference persistence across reboot,
live Open-Meteo requests (and TLS/certificate behaviour on a real 4.4.4 TV), screensaver timeout on a TV, video decoding on the target hardware,
download manager runs (catalogue is empty), low-storage behaviour, memory profiling, TV-resolution layout checks, screenshots.
Please run these on the Wisdom Share TV and report anything that fails.
